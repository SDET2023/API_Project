package runner.yopmail;

import configuration.CommonValues;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import pages.ppi.yopEmailPages.MainEmailPage;
import runner.BaseStep;
import session.Session;
import utils.Level;
import utils.Logger;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainEmailSteps extends BaseStep {
    MainEmailPage mainEmailPage = new MainEmailPage();
    private String yopMailUrl="https://yopmail.com/en/";

    @Then("^Opening your email: \"(.*)\"$")
    public void openYourEmailInOrderToVerifyTheEmailFromPetpartners(String email) throws Exception {
        Session.getInstance().getDriver().get(yopMailUrl);
        mainEmailPage.emailNameTextBox.clearSetText(this.replaceConfigurationValues(email));
        mainEmailPage.goButton.controlIsDisplayed(10);
        mainEmailPage.goButton.click();

        if (mainEmailPage.captchaNotRobotCheckBox.controlIsDisplayed(3))
            mainEmailPage.captchaNotRobotCheckBox.click();

        mainEmailPage.refreshButton.click();
        mainEmailPage.refreshButton.controlIsDisplayed(5);
        mainEmailPage.refreshButton.click();
    }

    /**
     * this method is to compare text using regular expression in the comparation, use reg exp in the step
     * @param expectedResult
     * @throws Exception
     */
    @Then("Verify the subject email")
    public void verifyTheSubjectEmail(String expectedResult) throws Exception {
        Session.getInstance().getDriver().switchTo().frame("ifmail");
        mainEmailPage.emailSubjectDetailLabel.controlIsDisplayed(2);
        String actualResult=mainEmailPage.emailSubjectDetailLabel.getText();

        Pattern pattern = Pattern.compile(expectedResult);
        Matcher matcher = pattern.matcher(actualResult);
        boolean isMatch = matcher.matches();
        Assertions.assertTrue(isMatch,"ERROR! the subject the email is wrong, actual: "+actualResult+ " VS expected: "+expectedResult);
    }


    @And("I close the browser")
    public void iCloseTheBrowser() {
        Session.getInstance().closeSession();
    }

    @And("I wait {int} seconds")
    public void iWaitSeconds(int seconds) throws InterruptedException {
        Thread.sleep(seconds*1000);
    }

    @Then("I check the number of email is {int} with the subject")
    public void iCheckTheNumberOfEmailIsWithTheSubject(int expectedAmount, String subject) {
        Session.getInstance().getDriver().switchTo().defaultContent();
        Session.getInstance().getDriver().switchTo().frame("ifinbox");
        int actualAmountEmail=mainEmailPage.getNumberEmail(this.replaceConfigurationValues(subject));
        Logger.log(Level.INFO,this.getClass().getName()+"> current amount of email: "+actualAmountEmail);
        Assertions.assertEquals(expectedAmount,actualAmountEmail,"ERROR! the amount of email are not the correct");

    }

    @And("I get the Email Subject in {}")
    public void iGetTheEmailSubjectInEmail(String variable) throws Exception {
        mainEmailPage.emailSubjectDetailLabel.controlIsDisplayed(2);
        String currentLabel=mainEmailPage.emailSubjectDetailLabel.getText();
        CommonValues.variables.put(variable,currentLabel);
        Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(variable)+"] in ["+variable+"]");
    }

    @And("Verify the attachment file")
    public void verifyTheAttachmentFile(String fileNameAttached) {
        Assertions.assertTrue(mainEmailPage.verifyAttachmentFile(this.replaceConfigurationValues(fileNameAttached)),
                "The email does not have attachement file: "+this.replaceConfigurationValues(fileNameAttached));
    }
}
