package runner.stepsOrca;

import configuration.CommonValues;
import entities.orca.MedicalRecordEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orca.claim.ClaimDashboard;
import pages.orca.claim.ClaimDetails;
import pages.orca.claim.RequestMedicalRecord;
import pages.orca.common.AlertSection;
import pages.orca.loss.LossDetails;
import pages.orca.policy.PolicyDetailsPage;
import pages.orcaGroup.ClaimSections;
import pages.orcaGroup.GroupClaimDetailsPage;
import pages.orcaGroup.MenuSections;
import utils.Level;
import utils.Logger;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MenuSteps extends BaseSteps {
    ClaimDetails claimDetails = new ClaimDetails();

    ClaimSections claimSections = new ClaimSections();

    MenuSections menuSections = new MenuSections();

    PolicyDetailsPage policyDetailsPage = new PolicyDetailsPage();

    LossDetails lossDetails = new LossDetails();

    AlertSection alertSection = new AlertSection();

    ClaimDashboard claimDashboard = new ClaimDashboard();

    RequestMedicalRecord requestMedicalRecord = new RequestMedicalRecord();
    GroupClaimDetailsPage groupClaimDetailsPage = new GroupClaimDetailsPage();


    @When("I click on the [{}] tab in the menu")
    public void iClickOnTheTabInTheMenu(String menuOption) throws Exception {
        if (!menuSection.optionMenu.containsKey(menuOption))
            throw new Exception("Error!! the option [" + menuOption + "] does not exist in the menu");
        menuSection.optionMenu.get(menuOption).click();
    }

    @When("I set {string} in Search Policies")
    public void iSetInSearchPolicies(String value) throws Exception {
        menuSection.searchPoliciesTextBox.setText(this.replaceConfigurationValues(value));
    }

    @And("I click [Go] symbol button")
    public void iClickGoSymbolButton() throws Exception {
        menuSection.goButton.click();
    }

    @And("click on [{}] tab in the bottom menu")
    public void clickOnTabInTheBottomMenu(String menuTabOption) throws Exception {
        Thread.sleep(2000);
        claimDetails.controlLinks.get(menuTabOption).controlIsDisplayed(10);
        claimDetails.controlLinks.get(menuTabOption).click();
    }

    @Then("I verify {string} number display on claims table")
    public void iVerifyNumberDisplayOnClaimsTable(String value) throws Exception {
        Assertions.assertTrue(claimDetails.claimResultTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(value)),
                "ERROR! the value : [" + this.replaceConfigurationValues(value) + "] is not displayed in the policy search result section");
    }

    @And("I click {string} tab on menu Sections")
    public void iClickTabOnMenuSections(String value) throws Exception {
        menuSections.menuOption.get(value).click();
    }

    @And("I click  {string} on the Claims Sections")
    public void iClickOnTheClaimsSections(String value) throws Exception {
        if (value.contains("SearchForClaim")) {
            claimSections.searchForClaimsButton.click();
        } else if (value.contains("MyDashBoard")) {
            claimSections.myDashboardButton.click();
        } else if (value.contains("IssueClaims")) {
            claimSections.issueClaimsButton.click();
        }
    }

    @When("I Enter the claims number to textBox {string}")
    public void iEnterTheClaimsNumberToTextBox(String value) throws Exception {
        claimSections.claimsNoTextBox.clearSetText(this.replaceConfigurationValues(value));
    }

    @And("I Click [{string}] button on Claims Sections")
    public void iClickButtonOnClaimsSections(String value) throws Exception {
        claimSections.runSearchButton.click();
    }

    @Then("I Verify {string} display on claims search results Table")
    public void iVerifyDisplayOnClaimsSearchResultsTable(String value) throws Exception {
        Assertions.assertTrue(claimSections.searchResultTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(value)),
                "ERROR! the value : [" + this.replaceConfigurationValues(value) + "] is not displayed in the policy search result section");
    }

    @And("I click on link cell row: {int} column {int} in result table")
    public void iClickOnLinkCellRowColumnInResultTable(int row, int column) throws Exception {
        claimSections.searchResultTable.clickLink(column, row);
    }

    @Then("I Verify {string} display on group claim details table")
    public void iVerifyDisplayOnGroupClaimDetailsTable(String value) throws Exception {
        Assertions.assertTrue(claimSections.details.getText().contains(this
                        .replaceConfigurationValues(value)),
                "ERROR! the value : [" + this.replaceConfigurationValues(value) + "] is not displayed in the policy search result section");

    }

    @And("I enter the {string} to search box on orca Group wab page")
    public void iEnterTheToSearchBoxOnOrcaGroupWabPage(String value) throws Exception {
        menuSections.searchCertificateTextBox.setText(this.replaceConfigurationValues(value));
    }

    @And("I click on [Add New] button on claims tab")
    public void iClickOnAddNewButtonOnClaimsTab() throws Exception {

        policyDetailsPage.addNewClaimButton.click();
    }

    @And("create a claim with with today date, submit processing")
    public void createAClaimWithWithTodayDateSubmitProcessing() throws Exception {
        claimDetails.controlSelect.get("Assistant").firstValue();
        claimDetails.controlSelect.get("Adjuster").firstValue();
        claimDetails.controlSelect.get("Priority").firstValue();
        claimDetails.controlSelect.get("Auditor").firstValue();
        claimDetails.receivedOnTextBox.click();
        claimDetails.receivedOnTextBox.setText(new SimpleDateFormat("MM/dd/yyyy").format(new Date()));
        claimDetails.controlButtonClaimsDetail.get("Save").click();
        claimDetails.controlButtonClaimsDetail.get("Submit to Processing").click();
        Thread.sleep(3000);
    }

    @And("click on [Add Loss\\(es)] button in processing tab")
    public void clickOnAddLossEsButtonInProcessingTab() throws Exception {
        claimDetails.addLossesButton.click();
    }

    @And("find a vet to add to the option in Loss Detail section")
    public void findAVetToAddToTheOptionInLossDetailSection() throws Exception {
        lossDetails.findVetButton.click();
        lossDetails.vetSearchModal.stateProvinceSelect.firstValue();
        lossDetails.vetSearchModal.clickOnSelectButton(1, "c");
    }

    @And("fill the Overview in Loss Detail section")
    public void fillTheOverviewInLossDetailSection(Map<String, String> overViewDetailValues) throws Exception {

        if (overViewDetailValues.containsKey("Date of Service")) {
            Thread.sleep(2000);
            lossDetails.dateOfServiceTextBox.click();
            lossDetails.dateOfServiceTextBox.setTextAndTab(this.replaceConfigurationValues(overViewDetailValues.get("Date of Service")));
        }
        if (overViewDetailValues.containsKey("Pet")) {
            if (this.replaceConfigurationValues(overViewDetailValues.get("Pet")).equals("FIRST_VALUE")) {
                lossDetails.petSelect.firstValue();
            } else {
                lossDetails.petSelect.selectValue(this.replaceConfigurationValues(overViewDetailValues.get("Pet")));
            }

        }
        if (overViewDetailValues.containsKey("Vet")) {
            if (this.replaceConfigurationValues(overViewDetailValues.get("Vet")).equals("FIRST_VALUE")) {
                lossDetails.vetSelect.firstValue();
            } else {
                lossDetails.vetSelect.selectValue(this.replaceConfigurationValues(overViewDetailValues.get("Vet")));
            }
        }

    }

    @And("click on [{}] button in loss detail - overview page")
    public void clickOnSaveButtonInLossDetailOverviewPage(String nameControl) throws Exception {
        if (lossDetails.controlOverviewButton.containsKey(nameControl))
            lossDetails.controlOverviewButton.get(nameControl).click();
        else
            throw new Exception("the button " + nameControl + " does not exist in loss detail overview page");
    }

    @And("click on [{}] button on the claim detail page")
    public void clickOnButtonOnTheClaimDetailPage(String buttonName) throws Exception {
        Thread.sleep(3000);
        claimDetails.controlButtonClaimsDetail.get(buttonName).click();
        Thread.sleep(1500);
    }

    @And("I get the claim number displayed in the alert in {}")
    public void iGetTheClaimNumberDisplayedInTheAlertIn(String variableName) throws Exception {
        String actualResult = alertSection.successfullyAlertLabel.getText();
        Pattern pattern = Pattern.compile("Successfully assigned claim (.*) to (.*)");
        Matcher matcher = pattern.matcher(actualResult);
        if (matcher.find()) {
            CommonValues.variables.put(variableName, matcher.group(1));
            Logger.log(Level.INFO, this.getClass().getName() + "> save the value: [" + CommonValues.variables.get(variableName) + "] in [" + variableName + "]");
        } else {
            throw new Exception("The claim number is not displayed, actual: " + actualResult);
        }
    }

    @Then("verify the successfully alert is displayed")
    public void verifyTheSuccessfullyAlertIsDisplayed(String expectedResult) throws Exception {
        String actualResult = alertSection.successfullyAlertLabel.getText();
        expectedResult = this.replaceConfigurationValues(expectedResult);
        Assertions.assertTrue(actualResult.contains(expectedResult),
                "ERROR the message is not successfully, actual: [" + actualResult + "] vs expected: [" + expectedResult + "]");
    }

    @And("I click on [{}] Link on Claim Dashboard")
    public void iClickOnAssignedLinkOnClaimDashboard(String linkControl) throws Exception {
        claimDashboard.linksMap.get(linkControl).click();

    }
    @And("click on [{}] button in approved section")
    public void clickOnReturnToClaimButtonInApprovedSection(String buttonName) throws Exception {
        lossDetails.controlApprovedButton.get(buttonName).click();
    }

    @And("I click {string} button on medical Record Page")
    public void iClickButtonOnMedicalRecordPage(String value) throws Exception {
        requestMedicalRecord.medicalRecordPageButton.get(value).controlIsClickable();
        requestMedicalRecord.medicalRecordPageButton.get(value).controlIsDisplayed(5);
        requestMedicalRecord.medicalRecordPageButton.get(value).click();

    }

    @When("I fill out the application medical Record Page")
    public void iFillOutTheApplicationMedicalRecordPage(MedicalRecordEntity medicalRecordEntity) throws Exception {

        if (!medicalRecordEntity.getRequestTypeDropdown().isEmpty())
            requestMedicalRecord.requestTypeDropdown.selectValueContainsOption(this.replaceConfigurationValues(medicalRecordEntity.getRequestTypeDropdown()));
        if (!medicalRecordEntity.getPet().isEmpty())
            requestMedicalRecord.petDropdown.firstValue();
        if (!medicalRecordEntity.getVet().isEmpty())
            requestMedicalRecord.vetDropdown.firstValue();
        if (!medicalRecordEntity.getRequestSearch().isEmpty())
            requestMedicalRecord.requestSearch.setText(this.replaceConfigurationValues(medicalRecordEntity.getRequestSearch()));
        requestMedicalRecord.allMrsButton.click();
    }

    @DataTableType
    public MedicalRecordEntity getEntity(Map<String, String> entity) {
        MedicalRecordEntity tmpp = new MedicalRecordEntity();
        if (entity.containsKey("Request Type"))
            tmpp.setRequestTypeDropdown(entity.get("Request Type"));
        if (entity.containsKey("Pet"))
            tmpp.setPet(entity.get("Pet"));
        if (entity.containsKey("Vet"))
            tmpp.setVet(entity.get("Vet"));
        if (entity.containsKey("Request Search"))
            tmpp.setRequestSearch(entity.get("Request Search"));
        return tmpp;
    }

    @Then("I Verify {string} display on medical record Table")
    public void iVerifyDisplayOnMedicalRecordTable(String value) throws Exception {
        Assertions.assertTrue(requestMedicalRecord.medicalRecordTable.getText().contains(this
                        .replaceConfigurationValues(value)),
               "ERROR! the value : [" + this.replaceConfigurationValues(value) + "] is not displayed in the policy search result section");

    }

    @And("I click on {string} display on claims search results Table")
    public void iClickOnDisplayOnClaimsSearchResultsTable(String value) throws Exception {
        claimSections.claimNoLink.click();
    }

    @And("click on the [Claims] link")
    public void clickOnTheClaimsLink() throws Exception {
        claimDetails.claimsResultLink.click();
    }

    @Then("verify the invoice.pdf link is not empty")
    public void verifyTheInvoicePdfLinkIsNotEmpty() throws Exception {
        Assertions.assertFalse(claimDetails.getLinkForClaimPDF().isEmpty(), "ERROR, the link for the PDF is empty");
    }

    @And("I select {string} option on the Certificate or Claim dropdown")
    public void iSelectOptionOnTheCertificateOrClaimDropdown(String option) throws Exception {
        if (option.contains("Certificate")){
            menuSections.policyAndClaimDropdown.selectValueContainsOption(option);
        } else if (option.contains("Claim")) {
            menuSections.policyAndClaimDropdown.selectValueContainsOption(option);
        }
    }

    @Then("I verify {string} display on the group claim details page")
    public void iVerifyDisplayOnTheGroupClaimDetailsPage(String value) throws Exception {
        Assertions.assertTrue(groupClaimDetailsPage.claimDetailsLabel.getText().contains(this.replaceConfigurationValues(value)));
    }
}
