package runner.stepsOrca;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orca.policy.PolicyDetailsPage;

public class PolicyDetailsSteps extends BaseSteps {
    PolicyDetailsPage policyDetailsPage = new PolicyDetailsPage();

    @When("click on [{}] tab in policy details page bottom menu")
    public void clickOnTabInPolicyDetailsPageBottomMenu(String menuTabOption) throws Exception {
        policyDetailsPage.tabOptionLabelsMap.get(menuTabOption).controlIsDisplayed(10);
        policyDetailsPage.tabOptionLabelsMap.get(menuTabOption).click();

    }

    @And("I click on [{}] link in attachment tab")
    public void iClickOnLinkInAttachmentTab(String sLink)  throws Exception {
        policyDetailsPage.attachmentTabLinksMap.get(sLink).controlIsDisplayed(10);
        policyDetailsPage.attachmentTabLinksMap.get(sLink).click();
    }

    @Then("I verify [{}] document type label")
    public void iVerifyDocumentTypeLabel(String sDocType) {
        Assertions.assertTrue(policyDetailsPage.attachmentTabDocTypeLabelsMap.get(sDocType).controlIsDisplayed(10),
                "ERROR: " + sDocType + " is not displayed");
    }


    @And("I set the [Linked Policy] text box with {string} in Policy Details Page")
    public void iSetTheTextBoxWithInPolicyDetailsPage(String value) throws Exception {
        this.policyDetailsPage.linkedPolicyTextBox.controlIsDisplayed(20);
        this.policyDetailsPage.linkedPolicyTextBox.setText(this.replaceConfigurationValues(value));
    }

    @And("I click on [Save] button in Policy Detail Page")
    public void iClickOnSaveButtonInPolicyDetailPage() throws Exception {
        this.policyDetailsPage.saveButton.click();
    }

    @Then("I verify the message should be displayed")
    public void iVerifyTheMessageShouldBeDisplayed(String expectedResult) throws Exception {
        String actualResult = alertSection.successfullyAlertLabel.getText();
        expectedResult = this.replaceConfigurationValues(expectedResult);
        Assertions.assertTrue(actualResult.contains(expectedResult),
                "ERROR the message is not successfully, actual: [" + actualResult + "] vs expected: [" + expectedResult + "]");
    }

    @And("I click on [Linked group Certificate] link in Policy Detail Page")
    public void iClickOnLinkedGroupCertificateLinkInPolicyDetailPage() throws Exception {
        this.policyDetailsPage.linkedGroupCertificateLink.controlIsClickable();
        this.policyDetailsPage.linkedGroupCertificateLink.click();
    }
}
