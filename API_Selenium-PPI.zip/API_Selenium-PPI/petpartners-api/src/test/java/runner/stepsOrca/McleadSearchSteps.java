package runner.stepsOrca;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orca.mclead.McleadSearchPage;
import runner.BaseStep;

import java.util.Map;

public class McleadSearchSteps extends BaseStep {

    McleadSearchPage mcleadSearchPage = new McleadSearchPage();

    @And("Search using registration number")
    public void searchUsingRegistrationNumber(Map<String, String> controlsValue) throws Exception {
        mcleadSearchPage.petDetailsTab.click();
        mcleadSearchPage.registrationNoTextBox.setText(this.replaceConfigurationValues(controlsValue.get("Registration No")));
        mcleadSearchPage.runSearchButton.click();
    }

    @Then("Verify the search result table display")
    public void verifyTheSearchResultTableDisplay(String expectedResult) throws Exception {
        Assertions.assertTrue( mcleadSearchPage.searchResultTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(expectedResult)),
                "ERROR!  the value ["+this.replaceConfigurationValues(expectedResult)+"] is not displayed in the search result table");
    }

    @When("I click on pet details link")
    public void iClickOnPetDetailsLink() throws Exception {
        mcleadSearchPage.petDetailsLink.click();
    }
}