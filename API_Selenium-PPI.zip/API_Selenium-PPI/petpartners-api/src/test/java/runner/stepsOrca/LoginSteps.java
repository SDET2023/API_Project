package runner.stepsOrca;

import configuration.Configuration;
import helper.LoginHelper;
import helpers.GetProperties;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import org.openqa.selenium.Cookie;

import pages.orca.login.LoginPage;
import runner.BaseStep;
import session.Session;
import utils.Level;
import utils.Logger;

public class LoginSteps extends BaseStep {
    LoginPage loginPage = new LoginPage();


    @Given("open the ORCA web page")
    public void openTheORCAWebPage() throws InterruptedException {
        Session.getInstance().getDriver().get(GetProperties.getInstance().getUrlOrcaWeb());
    }

    @When("I am logged in Orca PetPartners")
    public void iAmLoggedInOrcaPetPartners() throws Exception {
        if (GetProperties.getInstance().isEnabledOrcaMfa()) {
            String cookie = new LoginHelper().buildCookieInfoUser(GetProperties.getInstance().getHost(),
                    GetProperties.getInstance().getUser(),
                    GetProperties.getInstance().getPassword());
            Logger.log(Level.INFO, this.getClass().getName() + "adding the cookie: [userInfo] : [" + cookie + "]");
            Session.getInstance().getDriver().manage().addCookie(new Cookie("userInfo", cookie));
            Session.getInstance().getDriver().navigate().refresh();
            Thread.sleep(3000);
        }else{
            loginPage.loginSubStep(Configuration.USER,Configuration.PASSWORD);
        }
    }

    @Given("open the OrcaGroup web page")
    public void openTheOrcaGroupWebPage() {
        Session.getInstance().getDriver().get(GetProperties.getInstance().getUrlOrcaGroupWeb());
    }

    @And("I scroll down")
    public void iScrollDown() {
        this.scrollDown();
    }

    @And("I refresh the web page")
    public void iRefreshTheWebPage() {
        Session.getInstance().getDriver().navigate().refresh();
    }
}
