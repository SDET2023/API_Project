package runner.stepsGroupOrca;

import io.cucumber.java.en.And;
import pages.orcaGroup.GroupClaimDetailsPage;
import runner.stepsOrca.BaseSteps;

public class GroupClaimDetailsSteps extends BaseSteps {
    GroupClaimDetailsPage groupClaimDetailsPage = new GroupClaimDetailsPage();

    @And("click on [Return to Claim]")
    public void clickOnReturnToClaim() throws Exception {
        groupClaimDetailsPage.returnToClaimButton.click();
    }
    @And("click on Finalize All Loss\\(es) button")
    public void clickOnFinalizeAllLossEsButton() throws Exception {
        groupClaimDetailsPage.finalizeAllLossesButton.click();
    }
    @And("click on SubmitToProcessing button on the group claim detail page")
    public void clickOnSubmitToProcessingButtonOnTheGroupClaimDetailPage() throws Exception {
        groupClaimDetailsPage.controlSelect.get("Assistant").firstValue();
        groupClaimDetailsPage.controlButtonClaimsDetail.get("Submit to Processing").click();

    }
    @And("click on [Add Loss\\(es)] button in group processing tab")
    public void clickOnAddLossEsButtonInGroupProcessingTab() throws Exception {
        groupClaimDetailsPage.groupAddLossesButton.click();
    }

    @And("I Click {} On Loss details page")
    public void iClickOnLossDetailsPage(String value) throws Exception {
        groupClaimDetailsPage.controlButtonClaimsDetail.get(this.replaceConfigurationValues(value)).click();
    }

    @And("I select {string} value in Adjuster combobox on Group Claim Detail")
    public void iSelectValueInAdjusterComboboxOnGroupClaimDetail(String adjusterValue) throws Exception {
        if (adjusterValue.contains("any"))
            groupClaimDetailsPage.controlSelect.get("Adjuster").firstValue();
        else
            groupClaimDetailsPage.controlSelect.get("Adjuster").selectContainsValueUsingXpath(this.replaceConfigurationValues(adjusterValue));

    }

    @And("I click on [{}] button on Group Claim Detail")
    public void iClickOnSaveButtonOnGroupClaimDetail(String buttonName) throws Exception {
        groupClaimDetailsPage.controlButtonClaimsDetail.get(buttonName).click();
    }


    @And("I click on [{}] tab on Group Claim Detail")
    public void iClickOnProcessingTabOnGroupClaimDetail(String tabName) throws Exception {
        groupClaimDetailsPage.controlLinks.get(tabName).click();
    }


    @And("I click on [{}] button on the group claim details page")
    public void iClickOnButtonOnTheGroupClaimDetailsPage(String value) throws Exception {
        groupClaimDetailsPage.controlButtonClaimsDetail.get(value).click();
    }
}
