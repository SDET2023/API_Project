package runner.stepsGroupOrca;

import entities.orca.followUp.FollowUpDetailEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import pages.orcaGroup.certificate.GroupFollowupDetailPage;
import runner.BaseStep;

import java.util.Map;

public class FollowUpDetailStep extends BaseStep {


    GroupFollowupDetailPage groupFolloupDetailPage = new GroupFollowupDetailPage();
    @And("fill the FollowUp Detail Page")
    public void fillTheFollowUpDetailPage(FollowUpDetailEntity entity) throws Exception {
        groupFolloupDetailPage.fillDetailPage(entity);
    }

    @DataTableType
    public FollowUpDetailEntity getEntity(Map<String, String> entity) {
        FollowUpDetailEntity tmp = new FollowUpDetailEntity();
        if (entity.containsKey("Assigned To"))
            tmp.setAssignedTo(this.replaceConfigurationValues(entity.get("Assigned To")));
        if (entity.containsKey("Followup Type"))
            tmp.setFollowUpType(this.replaceConfigurationValues(entity.get("Followup Type")));
        if (entity.containsKey("Complaint Type"))
            tmp.setComplaintType(this.replaceConfigurationValues(entity.get("Complaint Type")));
        if (entity.containsKey("Received On"))
            tmp.setReceivedOn(this.replaceConfigurationValues(entity.get("Received On")));
        if (entity.containsKey("Followup By"))
            tmp.setFollowUpBy(this.replaceConfigurationValues(entity.get("Followup By")));
        if (entity.containsKey("Closed On"))
            tmp.setClosedOn(this.replaceConfigurationValues(entity.get("Closed On")));
        if (entity.containsKey("Summary"))
            tmp.setSummary(this.replaceConfigurationValues(entity.get("Summary")));
        if (entity.containsKey("Resolution"))
            tmp.setResolution(this.replaceConfigurationValues(entity.get("Resolution")));
        return tmp;
    }
}
