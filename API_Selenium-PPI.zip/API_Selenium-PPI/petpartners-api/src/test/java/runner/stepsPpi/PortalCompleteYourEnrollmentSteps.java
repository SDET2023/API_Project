package runner.stepsPpi;

import entities.ppi.ChangeCovCompleteEnrollmentEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import pages.ppi.PortalCompleteYourEnrollmentPage;
import runner.stepsOrca.BaseSteps;

import java.util.Map;

public class PortalCompleteYourEnrollmentSteps extends BaseSteps {

    PortalCompleteYourEnrollmentPage portalCompleteYourEnrollment = new PortalCompleteYourEnrollmentPage();

    @And("I complete enrollment process for change coverage options")
    public void iCompleteEnrollmentProcessForChangeCoverageOptions(ChangeCovCompleteEnrollmentEntity completeEnrollmentEntity) throws Exception {
        portalCompleteYourEnrollment.fillChgCovCompleteYourEnrollment(completeEnrollmentEntity);
    }

    @DataTableType
    public ChangeCovCompleteEnrollmentEntity enrollmentEntityEntry(Map<String, String> entry) {
        ChangeCovCompleteEnrollmentEntity entity = new ChangeCovCompleteEnrollmentEntity();

        if (entry.containsKey("firstname on card"))
            entity.setFirstNameOnCard(this.replaceConfigurationValues(entry.get("firstname on card")));
        if (entry.containsKey("lastname on card"))
            entity.setLastNameOnCard(this.replaceConfigurationValues(entry.get("lastname on card")));
        if (entry.containsKey("card number"))
            entity.setCardNumber(this.replaceConfigurationValues(entry.get("card number")));
        if (entry.containsKey("expires mm"))
            entity.setExpiresMM(this.replaceConfigurationValues(entry.get("expires mm")));
        if (entry.containsKey("expires yyyy"))
            entity.setExpireYYYY(this.replaceConfigurationValues(entry.get("expires yyyy")));
        if (entry.containsKey("cvc"))
            entity.setCvc(this.replaceConfigurationValues(entry.get("cvc")));
        return entity;
    }
}
