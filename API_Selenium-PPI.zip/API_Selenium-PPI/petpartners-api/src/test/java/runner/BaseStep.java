package runner;

import configuration.CommonValues;
import configuration.Configuration;
import factoryRequest.RequestInformation;
import io.restassured.response.Response;
import org.openqa.selenium.JavascriptExecutor;
import pages.orca.common.LoadingSection;
import session.Session;
import utils.Level;
import utils.Logger;

import java.util.ArrayList;
import java.util.List;

public class BaseStep {
    protected Response response;
    public List<String> queryResult= new ArrayList<>();
    RequestInformation requestInformation;
    protected LoadingSection loadingSection = new LoadingSection();
    public BaseStep(){

    }
    public String replaceConfigurationValues(String value){
        for (String key: CommonValues.variables.keySet()
        ) {
            value=value.replace(key,CommonValues.variables.get(key));
        }
        return value.replace(CommonValues.DEFAULT_USER, Configuration.USER)
                    .replace(CommonValues.DEFAULT_PWD,Configuration.PASSWORD);
    }
    public void scrollDown(){
        Logger.log(Level.INFO,this.getClass().getName()+"> Scroll Down Action "+this.getClass().getSimpleName());
        JavascriptExecutor js = (JavascriptExecutor) Session.getInstance().getDriver();
        js.executeScript("window.scrollBy(0,500)");
    }

    public void scrollUp(){
        Logger.log(Level.INFO,this.getClass().getName()+"> scroll up");
        JavascriptExecutor js = (JavascriptExecutor) Session.getInstance().getDriver();
        js.executeScript("window.scrollBy(0,-400)");
    }
}
