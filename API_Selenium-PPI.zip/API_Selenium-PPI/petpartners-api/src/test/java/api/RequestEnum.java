package api;

public enum RequestEnum {

    POST("post"),
    GET("get"),
    DELETE("delete"),
    PATCH("patch"),
    PUT("put");

    private String method;

    private RequestEnum(String apiURL) {
        this.method = apiURL;
    }

    public String getMethod() {
        return method;
    }
}
