package api;

public enum ApiConfiguration {

    LOGIN("/customer/account/login"),
    REGISTRATION("/pet/v1/send-registration"),

    //public api

    SAVE_PUBLIC_QUOTE("/quote/v1"),
    QUOTE_CHECKOUT("/quote/v1/checkout"),
    GET_TRUST_COMMERCE_TOKEN("/quote/v1/trustcommerce/token"),
    GET_PRODUCT_QUOTE_PET("/quote/v1/quote-pet/{id}/products?continuingCoverage=false"),
    GET_LIMITS_PUBLIC("/quote/v1/limits/{id}"),
    GET_BREEDS_PUBLIC("/quote/v1/breeds/{id}"),
    // Trust api
    TRUST_PAYMENT_STEP4("/trusteeapi/payment.php"),
    CUSTOMER_UPDATE("/customer/v1/customer/update"),
    CUSTOMER_REGISTRATION("/customer/account/register-user"),
    ATTACHMENT("/attachment/v1/claim"),
    GET_ATTACHMENT("/attachment/v1/{id}"),
    CUSTOMER_GET_BY_EMAIL("/customer/v1/Customer/email/{id}"), // --> /customer/v1/Customer/email/{email}
    CUSTOMER_GET_POLICY("/policy/v1/customer/{id}"), //--> /policy/v1/customer/{id_customer}
    CREATE_NEW_ENROLLMENT("/policy/v1/group/enroll"),
    INACTIVE_PET_ENROLLMENT("/policy/v1/group/enroll"),
    CREATE_BILLING_REIMBURSEMENT("/billing/v1/group/reimbursement-option"),
    CERTIFICATE_PAYMENT_HISTORIES("/billing/v1/group/certificate-payment-histories"),
    CREATE_BILLING_COMMISSIONS("/billing/v1/group/commissions"),

    // Admin
    GET_ADMIN_MARKET_CHANNEL("/admin/v1/market-channels"),
    //Submit Claim
    Submit_Claim("/claim/v1"),

    SEARCH_CLAIMS("/claim/v1/claim-search"),
    UPDATE_CLAIM_STATUS("/claim/v1/claim-status"),
    //Get Pet
    GET_PET_BY_POLICYID("/pet/v1/policy/{id}"),
    //Get CustomerId
    GET_CUSTOMERID_BY_EMAIL("/customer/v1/customer/email/{emailid}"),
    //Get Customer
    GET_CUSTOMER_BY_CUSTOMERID("/customer/v1/customer/{id}"),
    //Get Attachment
    GET_ATTACHMENT_BY_POLICY_ID("/attachment/v1/policy/{id}"),
    //Get PolicyTerm attachment
    GET_ATTACHMENT_BY_POLICYTERM_ID("/attachment/v1/policyterm/{id}"),
    //Get ClaimAttachment
    GET_ATTACHMENT_BY_CLAIMID("/attachment/v1/claim/{id}?PortalRequest=false"),


    GET_QUOTE_PRIVATE ("/quote/v1/private/{id}"),
    GET_STATE_FILING_TRAIL_PRODUCT ("/quote/v1/statefiling/{id}/trialproduct"),

    GET_AVAILABLE_QUOTE_PRODUCT ("/quote/v1/quote-pet/{id}/full-products"),

    GET_STATE_CODE_BY_ZIPCODE("/quote/v1/postalcode/{id}/state"),

    GET_STATE_FILING_BY_STATE_CODE("/quote/v1/state-filing?stateCode={id}"),

    GET_QUOTE_PRODUCTS_PUBLIC("/quote/v1/quote-pet/{id}/products"),

    POST_STATE_FILING_PRODUCTS_PUBLIC("/quote/v1/preview/{id}"),

    //Get AKC Lookup Registration
    GET_AKC_LOOKUP_REGISTRATION("/quote/v1/akc-lookup-registration?regNo={regNo}&postalCode={postalCode}&effectiveOn={effectiveOn}"),

    GET_QUOTE_PRODUCTS_PUBLIC_V2("/quote/v2/quote-pet/{id}/products"),

    POST_STATE_FILING_PRODUCTS_PUBLIC_V2("/quote/v2/preview/{id}");

    private String apiUrl;

    private ApiConfiguration(String apiURL) {
        this.apiUrl = apiURL;
    }

    public String getApiUrl() {
        return apiUrl;
    }
}