package configuration;

import helpers.GetProperties;

public class Configuration {
    public static String host = GetProperties.getInstance().getHost();
    public static final String USER=GetProperties.getInstance().getUser();
    public static final String PASSWORD=GetProperties.getInstance().getPassword();

    public static final String ACCESS_TOKEN="accessToken";
    public static final String AUTHORIZATION="Authorization";
    public static final String BEARER="Bearer ";
    public static final String CONTENT_TYPE="Content-Type";
    public static final String APPLICATION_JSON="application/json";
    public static final String MULTIPART_FORM_DATA="multipart/form-data";

}