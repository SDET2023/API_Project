package helpers;

import utils.GenerateReport;

import java.io.File;

public class CucumberReport {
    public static void main (String []args) throws InterruptedException {
        String mainPath=new File("").getAbsolutePath()+"\\build\\reports\\cucumber\\";
        GenerateReport.generateReports(mainPath,"report.json","V001","Chrome","Staging");
    }
}
