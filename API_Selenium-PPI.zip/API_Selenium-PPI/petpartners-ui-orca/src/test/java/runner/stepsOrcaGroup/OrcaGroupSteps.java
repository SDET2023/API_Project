package runner.stepsOrcaGroup;

import configuration.Configuration;
import gifBuilder.ScreenShot;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import org.openqa.selenium.JavascriptExecutor;
import pages.orca.claim.ClaimDetails;
import pages.orcaGroup.ClaimSections;
import pages.orcaGroup.MenuSections;
import runner.BaseSteps;
import session.Session;
import utils.Level;
import utils.Logger;

import java.util.ArrayList;
import java.util.List;

public class OrcaGroupSteps extends BaseSteps {

    MenuSections menuSections= new MenuSections();
    ClaimSections claimSections = new ClaimSections();
    ClaimDetails claimDetails = new ClaimDetails();

    @And("I click {string} tab on menu Sections")
    public void iClickTabOnMenuSections(String value) throws Exception {
        menuSections.menuOption.get(value).click();
    }

    @And("I click on link cell row: {int} column {int} in result table")
    public void iClickOnLinkCellRowColumnInResultTable(int row, int column) throws Exception {
        claimSections.claimsResultTable.click();
    }

    @And("click on [SendToQuickClaims] button in claims details")
    public void clickOnSendToQuickClaimsButtonInClaimsDetails() throws Exception {
        claimDetails.sendToQuickClaims.click();
    }

    @And("I click view Button on group claims details page")
    public void iClickViewButtonOnGroupClaimsDetailsPage() throws Exception {
        claimSections.viewButton.click();
    }

    @Given("I open a new tab with OrcaGroup  PetPartners")
    public void iOpenANewTabWithOrcaGroupPetPartners() throws InterruptedException {
        Thread.sleep(2000);
        JavascriptExecutor jse = (JavascriptExecutor)Session.getInstance().getDriver();
        jse.executeScript("window.open()");
        List<String> tabList=new ArrayList<String>(Session.getInstance().getDriver().getWindowHandles());
        Session.getInstance().getDriver().switchTo().window(tabList.get(tabList.size()-1));
        ScreenShot.addScreen(this.getClass().getName()+"> Open a new tab with url: "+ Configuration.WEB_UI_ORCA_GROUP);
        Logger.log(Level.INFO,this.getClass().getName()+"> Open a new tab with url: "+Configuration.WEB_UI_ORCA_GROUP);
        Session.getInstance().getDriver().get(Configuration.WEB_UI_ORCA_GROUP);
        ScreenShot.addScreen(this.getClass().getName()+"> Open a new tab with url: "+Configuration.WEB_UI_ORCA_GROUP);
        Thread.sleep(2000);
    }
}
