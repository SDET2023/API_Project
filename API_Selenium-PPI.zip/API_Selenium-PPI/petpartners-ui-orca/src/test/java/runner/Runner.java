package runner;

import configuration.BrowserConfiguration;
import configuration.CommonValues;
import gifBuilder.ScreenShot;
import helpers.GetProperties;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.junit.Cucumber;
import org.junit.runner.RunWith;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import session.Session;
import utils.Level;
import utils.Logger;


import java.util.ArrayList;
import java.util.HashMap;


@RunWith(Cucumber.class)
public class Runner {
    @Before
    public void before(Scenario scenario){
       Logger.log(Level.INFO,this.getClass().getName()+"> Tags Cucumber > "+scenario.getSourceTagNames());
       Logger.log(Level.INFO,this.getClass().getName()+"> Scenario Cucumber > "+scenario.getName());
       BrowserConfiguration.browser= GetProperties.getInstance().getBrowser();
       CommonValues.variables= new HashMap<>();
    }

    @After
    public void after(Scenario scenario) {
        if (scenario.isFailed()) {
            Logger.log(Level.INFO,this.getClass().getName()+"> Scenario > Generate Gif Image: "+GetProperties.getInstance().getGenerateGifImage());
            if (GetProperties.getInstance().getGenerateGifImage()) {
                try {
                    byte[] animation = ScreenShot.gifAssembler.generate();
                    scenario.attach(animation, "image/gif", "Gif Image All Execution");
                } catch (Exception e) {
                    Logger.log(Level.ERROR, this.getClass().getName() + "> Error when generating GIF image");
                }
            }

            final byte[] screenShot= ((TakesScreenshot) Session.getInstance().getDriver()).getScreenshotAs(OutputType.BYTES);
            scenario.attach(screenShot,"image/png","ScreenShot when the test was failed");
            Logger.log(Level.INFO,this.getClass().getName()+"> Scenario Cucumber > Taking screen Shoot for the report html");
        }
        ArrayList<String> tabs = new ArrayList<String>(Session.getInstance().getDriver().getWindowHandles());
        Session.getInstance().getDriver().switchTo().window(tabs.get(0));
        Session.getInstance().closeSession();
        ScreenShot.gifAssembler.clearFrames();
    }
}