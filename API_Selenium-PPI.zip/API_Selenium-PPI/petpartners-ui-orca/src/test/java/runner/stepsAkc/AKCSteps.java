package runner.stepsAkc;


import configuration.CommonValues;
import configuration.Configuration;
import entities.akc.CompleteEnrollmentEntity;
import entities.akc.CoverageEntity;
import entities.akc.GetQuoteEntity;
import gifBuilder.ScreenShot;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.akc.*;
import runner.BaseSteps;
import session.Session;
import utils.Level;
import utils.Logger;

import java.util.Map;

public class AKCSteps extends BaseSteps {

    MainPage mainPage= new MainPage();
    CertificateOfferPage certificateOfferPage= new CertificateOfferPage();
    GetQuotePage getQuotePage =  new GetQuotePage();
    CoveragePage coveragePage= new CoveragePage();
    CompleteYourEnrollmentPage completeYourEnrollmentPage = new CompleteYourEnrollmentPage();
    CongratulationEnrollmentPage congratulationEnrollmentPage = new CongratulationEnrollmentPage();

    @Given("open the AKC web page")
    public void openTheAKCWebPage() {
        Logger.log(Level.INFO,this.getClass().getName()+"> Go to url: "+Configuration.WEB_UI_AKC);
        ScreenShot.addScreen(this.getClass().getName()+"> Go to url: "+Configuration.WEB_UI_AKC);
        Session.getInstance().getDriver().get(Configuration.WEB_UI_AKC);
        ScreenShot.addScreen(this.getClass().getName()+"> Go to url: "+Configuration.WEB_UI_AKC);
    }

    @And("click on GET QUOTE button")
    public void clickOnGETQUOTEButton() throws Exception {
        mainPage.getQuoteButton.click();
    }

    @And("fill the Get Quote Page")
    public void fillTheGetQuotePage(GetQuoteEntity quoteEntityEntry) throws Exception {
            this.getQuotePage.fillGetQuote(quoteEntityEntry);
    }

    @DataTableType
    public GetQuoteEntity quoteEntityEntry(Map<String,String> entry){
        GetQuoteEntity entity= new GetQuoteEntity();
        entity.setPetName(replaceConfigurationValues(entry.get("PET NAME"))).
                setPetType(this.replaceConfigurationValues(entry.get("PET TYPE"))).
                setPetBreed(this.replaceConfigurationValues(entry.get("PET BREED"))).
                setPetAge(this.replaceConfigurationValues(entry.get("PET AGE"))).
                setHasYourPetEverBeenDiagnosed(this.replaceConfigurationValues(entry.get("HAS YOUR PET EVER BEEN DIAGNOSED"))).
                setEmailAddress(this.replaceConfigurationValues(entry.get("EMAIL ADDRESS")));

        if (entry.containsKey("ZIP CODE")) {
            entity.setZipCode(this.replaceConfigurationValues(entry.get("ZIP CODE")));
        }
        return entity;
    }

    @And("choose coverage type and select options")
    public void fillCoverageDetails(CoverageEntity coverageEntity) throws Exception {
        this.coveragePage.fillCoverageOption(coverageEntity);
    }
    @DataTableType
    public CoverageEntity coverageEntity(Map<String, String> entry) {
        CoverageEntity entity = new CoverageEntity();
        entity.setPlanDetail(this.replaceConfigurationValues(entry.get("COVERAGE TYPE")))
                .setDeductible(this.replaceConfigurationValues(entry.get("DEDUCTIBLE")))
                .setCoinsurance(this.replaceConfigurationValues(entry.get("COINSURANCE")))
                .setAnnualLimit(this.replaceConfigurationValues(entry.get("ANNUAL LIMIT")));
        return entity;
    }

    @And("click on {string} option on available upgrades")
    public void clickOnOptionOnAvailableUpgrades(String availableUpgradeOption) throws Exception {
        coveragePage.radioButtonMap.get(availableUpgradeOption).click();
    }

    @And("scrollUp window")
    public void scrollUpWindow() {
        this.scrollUp();
    }

    @And("click ADD TO CART button in Coverage Page")
    public void clickADDTOCARTButtonInCoveragePage() throws Exception {
        coveragePage.addToCartButton.click();
    }

    @And("fill the Complete Your Enrollment Page")
    public void fillTheCompleteYourEnrollmentPage(CompleteEnrollmentEntity completeEnrollmentEntity) throws Exception {
        completeYourEnrollmentPage.fillCompleteYourEnrollmentComplete(completeEnrollmentEntity);
    }

    @DataTableType
    public CompleteEnrollmentEntity completeEnrollmentEntry(Map<String, String> entry) {
        CompleteEnrollmentEntity entity = new CompleteEnrollmentEntity();

        if (entry.containsKey("FIRST NAME"))
            entity.setFirstName(this.replaceConfigurationValues(entry.get("FIRST NAME")));
        if (entry.containsKey("LAST NAME"))
            entity.setLastName(this.replaceConfigurationValues(entry.get("LAST NAME")));
        if (entry.containsKey("ADDRESS"))
            entity.setAddress(this.replaceConfigurationValues(entry.get("ADDRESS")));
        if (entry.containsKey("APT, SUITE, ETC."))
            entity.setAptSuiteEtc(this.replaceConfigurationValues(entry.get("APT, SUITE, ETC.")));
        if (entry.containsKey("PHONE NUMBER"))
            entity.setPhoneNumber(this.replaceConfigurationValues(entry.get("PHONE NUMBER")));
        if (entry.containsKey("NAME ON CARD"))
            entity.setNameOnCard(this.replaceConfigurationValues(entry.get("NAME ON CARD")));
        if (entry.containsKey("CARD NUMBER"))
            entity.setCardNumber(this.replaceConfigurationValues(entry.get("CARD NUMBER")));
        if (entry.containsKey("EXPIRES MM"))
            entity.setExpiresMM(this.replaceConfigurationValues(entry.get("EXPIRES MM")));
        if (entry.containsKey("EXPIRES YYYY"))
            entity.setExpiresYYYY(this.replaceConfigurationValues(entry.get("EXPIRES YYYY")));
        if (entry.containsKey("EXPIRES CVC"))
            entity.setExpiresCVC(this.replaceConfigurationValues(entry.get("EXPIRES CVC")));

        if (entry.containsKey("CITY"))
            entity.setCity(this.replaceConfigurationValues(entry.get("CITY")));
        if (entry.containsKey("STATE"))
            entity.setState(this.replaceConfigurationValues(entry.get("STATE")));
        if (entry.containsKey("ZIP CODE"))
            entity.setZipCode(this.replaceConfigurationValues(entry.get("ZIP CODE")));
        if (entry.containsKey("EMAIL ADDRESS"))
            entity.setEmailAddress(this.replaceConfigurationValues(entry.get("EMAIL ADDRESS")));
        if (entry.containsKey("Group Code"))
            entity.setGroupCode(this.replaceConfigurationValues(entry.get("Group Code")));
        if (entry.containsKey("IS USING DIFFERENT BILLING"))
            entity.setUsingDifferentBilling(Boolean.parseBoolean(this.replaceConfigurationValues(entry.get("IS USING DIFFERENT BILLING"))));
        if (entry.containsKey("DIFFERENT ADDRESS"))
            entity.setDifferentAddress(this.replaceConfigurationValues(entry.get("DIFFERENT ADDRESS")));
        if (entry.containsKey("DIFFERENT APT SUITE"))
            entity.setDifferentAptSuiteEtc(this.replaceConfigurationValues(entry.get("DIFFERENT APT SUITE")));
        if (entry.containsKey("DIFFERENT CITY"))
            entity.setDifferentCity(this.replaceConfigurationValues(entry.get("DIFFERENT CITY")));
        if (entry.containsKey("DIFFERENT STATE"))
            entity.setDifferentState(this.replaceConfigurationValues(entry.get("DIFFERENT STATE")));
        if (entry.containsKey("DIFFERENT ZIPCODE"))
            entity.setDifferentZipCode(this.replaceConfigurationValues(entry.get("DIFFERENT ZIPCODE")));

        return entity;
    }

    @Then("verify the {string} is displayed")
    public void verifyTheIsDisplayed(String message) {
        Assertions.assertTrue(congratulationEnrollmentPage.congratulationEnrollmentLabel.controlIsDisplayed(),"ERROR> the "+message+" is not displayed in congratulation page");
    }

    @And("I get the policy number in AKC Congratulation page on {}")
    public void iGetThePolicyNumberInAKCCongratulationPage(String variableKey) throws Exception {
        CommonValues.variables.put(variableKey,congratulationEnrollmentPage.policyNumberLabel.getText().replace("Policy ",""));
        Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(variableKey)+"] in ["+variableKey+"]");
    }
    @Then("click Activate Coverage button")
    public void clickActivateCoverageButton() throws Exception {
        mainPage.activateCoverage.click();
    }
    @And("click on activate coverage button on certificate page")
    public void clickOnActivateCoverageButtonOnCertificatePage() throws Exception {
        certificateOfferPage.activateCoverageButton.click();
    }
    @When("filling the lookup - Your pet's quote section")
    public void fillingTheLookupYourPetSQuoteSection(Map<String,String> certificateValues) throws Exception {
        getQuotePage.registrationNumberTextBox.click();
        getQuotePage.registrationNumberTextBox.setText(this.replaceConfigurationValues(certificateValues.get("REGISTRATION NUMBER")));
        getQuotePage.zipCodeRegistrationTextBox.setText(this.replaceConfigurationValues(certificateValues.get("ZIP CODE")));
    }

    @And("click on the Look Up Pet button in quote page")
    public void clickOnTheLookUpPetButtonInQuotePage() throws Exception {
        getQuotePage.lookUpPetButton.click();
    }
    @And("click on {} option in HAS YOUR PET EVER BEEN DIAGNOSED WITH OR SHOWN SYMPTOMS OF DIABETES?")
    public void clickOnNOOptionInHASYOURPETEVERBEENDIAGNOSEDWITHORSHOWNSYMPTOMSOFDIABETES(String option) throws Exception {
        if (option.contains("NO")) {
            getQuotePage.noHasYourPetOption.click();
        }else {
            getQuotePage.yesHasYourPetOption.click();
        }
    }
    @And("click on the CHOOSE COVERAGE button in quote page")
    public void clickOnTheCHOOSECOVERAGEButtonInQuotePage() throws Exception {
        getQuotePage.chooseCoverageButton.click();
    }
    @Then("the Select Pet Coverage should be displayed")
    public void theSelectPetCoverageShouldBeDisplayed() {
        Assertions.assertTrue(coveragePage.customizeYourPlanLabel.controlIsDisplayed(),"ERROR! the Select Pet Coverage Page is not displayed");
    }
    @And("click on [Activate initial 30 day offer only] Button on Select Pet Coverage Page")
    public void clickOnActivateInitialDayOfferOnlyButtonOnSelectPetCoveragePage() throws Exception {
        coveragePage.activateInitial30DayOnlyButton.click();
    }
    @Then("the Complete your enrollment page should be open")
    public void theCompleteYourEnrollmentPageShouldBeOpen() {
        Assertions.assertTrue(completeYourEnrollmentPage.completeYourEnrollmentLabel.controlIsDisplayed(),"ERROR > The Complete Enrollment Page is not displayed");
    }
    @And("select the checkin option in Complete your enrollment page")
    public void selectTheCheckinOptionInCompleteYourEnrollmentPage() throws Exception {
        completeYourEnrollmentPage.iAgreeThatByCheckingOption.click();
        if (completeYourEnrollmentPage.byCheckingBoxOption.controlIsDisplayed(10))
            completeYourEnrollmentPage.byCheckingBoxOption.click();
    }
    @And("click on Enroll Now button")
    public void clickOnEnrollNowButton() throws Exception {
        completeYourEnrollmentPage.enrollNowButton.click();
    }

    @And("the policy overview total should be {}")
    public void thePolicyOverviewTotalShouldBe(String expectedResult) throws Exception {
        Assertions.assertTrue(completeYourEnrollmentPage.policyOverviewCostLabel.getText().contains(expectedResult),
                "ERROR the cost for the policy should be : "+expectedResult+ "but it is "+completeYourEnrollmentPage.policyOverviewCostLabel.getText());
    }
}
