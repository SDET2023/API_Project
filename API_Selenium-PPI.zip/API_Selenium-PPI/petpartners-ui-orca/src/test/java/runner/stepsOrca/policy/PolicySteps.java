package runner.stepsOrca.policy;

import control.Label;
import entities.orca.policy.*;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;

import pages.akc.CompleteYourEnrollmentPage;
import pages.akc.GetQuotePage;
import pages.orca.akcActivate.AkcActivatePage;
import pages.orca.followUps.FollowUpsPage;
import pages.orca.mclead.RegistrationMcleadPage;
import pages.orca.policy.*;
import pages.orca.policy.backdate.BackDateSection;
import pages.ppi.PortalPolicyDetailsPage;
import pages.ppi.SelectTestCoverage;
import runner.BaseSteps;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PolicySteps extends BaseSteps {
    PolicyDetailsPage policyDetailsPage = new PolicyDetailsPage();
    MoveClaimDialog moveClaimDialog = new MoveClaimDialog();
    PolicySearchSection policySearchSection = new PolicySearchSection();
    AkcActivatePage akcActivatePage = new AkcActivatePage();
    CompleteYourEnrollmentPage completeYourEnrollmentPage = new CompleteYourEnrollmentPage();
    PolicyMakeChangesPage policyMakeChangesPage = new PolicyMakeChangesPage();
    PolicyChangesForNewPet policyChangesForNewPet = new PolicyChangesForNewPet();
    PortalPolicyDetailsPage portalPolicyDetailsPage = new PortalPolicyDetailsPage();
    PolicyCancelPage policyCancelPage = new PolicyCancelPage();
    BackDateSection backDateSection = new BackDateSection();
    EditPaymentPage editPaymentPage = new EditPaymentPage();
    FollowUpsPage followUpsPage = new FollowUpsPage();

    TransferSaleDialog transferSaleDialog=new TransferSaleDialog();
    SelectTestCoverage selectTestCoverage= new SelectTestCoverage();


    @And("select {string} claim to move to {string}")
    public void selectClaimToMoveTo(String claimNumber, String policyNumertoMove) throws Exception {
        moveClaimDialog.moveClaim(this.replaceConfigurationValues(policyNumertoMove),
                this.replaceConfigurationValues(claimNumber));
    }

     @And("I select customer source value as {string}")
    public void iSelectCustomerSourceValue(String value) throws Exception {
        pages.akc.GetQuotePage getQuotePage = new GetQuotePage();
        getQuotePage.customerSource.selectValue(this.replaceConfigurationValues(value));
    }

    @Then("I click choose coverage button")
    public void iClickChooseCoverageButton() throws Exception {

        akcActivatePage.chooseCoverageButton.click();
        Thread.sleep(3000);
    }

    @And("I click application acknowledgments radio button")
    public void iClickApplicationAcknowledgmentsRadioButton() throws Exception {
        if (completeYourEnrollmentPage.iAgreeThatByCheckingOption.controlIsDisplayed(5)) {
            completeYourEnrollmentPage.iAgreeThatByCheckingOption.select();
        }
        if (completeYourEnrollmentPage.iAgreeToGoPaperlessOption.controlIsDisplayed(5)) {
            completeYourEnrollmentPage.iAgreeToGoPaperlessOption.select();
        }

        if (completeYourEnrollmentPage.byCheckingBoxOption.controlIsDisplayed(5)) {
            completeYourEnrollmentPage.byCheckingBoxOption.select();
        }
        completeYourEnrollmentPage.enrollNowButton.controlIsClickable();
        completeYourEnrollmentPage.enrollNowButton.click();

    }

    @Then("I select coverage for pet")
    public void iSelectCoverageForPet() throws Exception {
        akcActivatePage.initial30DaysOfPet.controlIsDisplayed(10);
        akcActivatePage.initial30DaysOfPet.click();
    }

    @Then("I click on {string} option in HAS YOUR PET EVER BEEN DIAGNOSED WITH OR SHOWN SYMPTOMS OF DIABETES?")
    public void iClickOnNoOptionInHASYOURPETEVERBEENDIAGNOSEDWITHORSHOWNSYMPTOMSOFDIABETES(String option) throws Exception {

        if (option.contains("No")) {
            akcActivatePage.noHasYourPetOption.click();
        } else if (option.contains("Yes")) {
            akcActivatePage.yesHasYourPetOption.click();
        }
    }

    @And("I click on get Quote button in McLead Details")
    public void clickOnGetQuoteInMcLeadDetails() throws Exception {
        RegistrationMcleadPage registrationMcleadPage = new RegistrationMcleadPage();
        registrationMcleadPage.getquoteMcLeadDetails.click();
    }

    @Then("I click {string} dropdown")
    public void iClickDropdown(String options) throws Exception {
        Thread.sleep(2500);
        policyMakeChangesPage.policyActionsButton.click();
    }

    @And("I select {string}")
    public void iSelect(String value) throws Exception {
        Thread.sleep(2500);
        policyMakeChangesPage.changeEffectiveDateButton.click();

    }

    @And("I set new effective date")
    public void iSetNewEffectiveDate(DataTable dataTable) throws Exception {

        List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);
        for (Map<String, String> dataa : data) {
            policyMakeChangesPage.newEffectiveDateButton.clear();
            policyMakeChangesPage.newEffectiveDateButton.setText(this.replaceConfigurationValues(dataa.get("New Effective Date")));
        }
    }

    @Then("I set the notes for changes")
    public void iSetTheNotesForChanges() throws Exception {
        policyMakeChangesPage.notesTextbox.setText("Test");

    }

    @And("click on [save] button on Change Effective page")
    public void clickOnSaveButtonOnChangeEffectivePage() throws Exception {
        policyMakeChangesPage.saveButton.click();
    }

    @Then("I click Make Changes button")
    public void iClickMakeChangesButton() throws Exception {
        Thread.sleep(3000);
        policyMakeChangesPage.makeChangeButton.click();
    }

    @Then("I select {string} option")
    public void iSelectMakeChangesOption(String option) throws Exception {
        Thread.sleep(2500);
        if (option.contains("Make Changes")) {
            Thread.sleep(2500);
            policyMakeChangesPage.makeChangeOption.click();
        } else if (option.contains("Transfer Sale")) {
            policyMakeChangesPage.transferSaleButton.click();
        }

    }

    @Then("I click Add Pet button")
    public void iClickAddPetButton() throws Exception {
        Thread.sleep(2500);
        policyMakeChangesPage.addPetButton.click();
    }

    @And("I select {string} option Under the Add pet")
    public void iSelectExistingPetOptionUnderTheAddPet(String value) throws Exception {
        if (value.contains("Existing Pet")) {
            Thread.sleep(3000);
            policyMakeChangesPage.existingPetButton.click();
        } else if (value.contains("New Pet")) {
            policyMakeChangesPage.newPetButton.click();
        }

    }

    @When("I Provide active {string} and click run search")
    public void iProvideActivePolicyNumberAndClickRunSearch(String value) throws Exception {

        policyMakeChangesPage.policynumberTextBox.setText(this.replaceConfigurationValues(value));
        policySearchSection.runSearchButton.click();

    }

    @Then("I click Make changes button with zero premiums amount")
    public void iClickMakeChangesButtonWithZeroPremiumsAmount() throws Exception {
        policyMakeChangesPage.makeChangeButton2.click();
    }

    @And("I click {string} button")
    public void iClickButton(String option) throws Exception {
        Thread.sleep(2500);
        if (option.contains("Active")) {
            Thread.sleep(2500);
            policyMakeChangesPage.activeButton.waitUntilControlIsDisplayed();
            policyMakeChangesPage.activeButton.click();
        } else if (option.contains("Upcoming")) {
            policyMakeChangesPage.upcomingButton.click();

        }
    }

    @Then("I click select button on pet search page")
    public void iClickSelectButtonOnPetSearchPage() throws Exception {
        policyMakeChangesPage.selectButton.click();
    }

    @And("I select {string} Coverage on Make Changes page")
    public void iSelectCoverageOnMakeChangesPage(String value) throws Exception {
        if (value.contains("AccidentCare")) {
            Thread.sleep(3000);
            policyMakeChangesPage.accidentCareRadiobutton.click();
        } else if (value.contains("CompanionCare")) {
            policyMakeChangesPage.companionCareRadiobutton.click();
        }
    }

    @When("I select The Coverage for  {string} on Make changes page")
    public void iSelectTheCoverageForOnMakeChangesPage(String value) throws Exception {
        if (value.contains("Support Plus")) {
            policyMakeChangesPage.supportPlusCheckbox.check();
        } else if (value.contains("DefenderPlus")) {
            policyMakeChangesPage.defenderPlusCheckbox.check();
        } else if (value.contains("Defender")) {
            policyMakeChangesPage.defenderCheckbox.check();
        } else if (value.contains("AlternativePlus")) {
            policyMakeChangesPage.alternativePlusCheckbox.check();
        } else if (value.contains("Exam Plus")) {
            policyMakeChangesPage.examPlusCheckbox.check();
        }

    }

    @And("I click [save] button Make changes page")
    public void iClickSaveButtonMakeChangesPage() throws Exception {
        policyMakeChangesPage.saveButtonMakeChangesPage.click();
    }

    @Then("I set the pet name {string} on Add coverage Page")
    public void iSetThePetNameTestOnAddCoveragePage(String value) throws Exception {
        policyChangesForNewPet.petNameTextBox.setText(this.replaceConfigurationValues(value));
    }

    @Then("I set the Year [{string}] of Brith Year for the pet")
    public void iSetTheYearOfBrithYearForThePet(String year) throws Exception {
        policyChangesForNewPet.petBrithYearSelect.selectValueContainsOption(year);
        policyChangesForNewPet.petBrithDate.click();

    }

    @And("I set the Month {string} of Brith Month for the pet")
    public void iSetTheMonthMarOfBrithMonthForThePet(String month) throws Exception {
        policyChangesForNewPet.petDateOfBrithTextBox.clear();
        policyChangesForNewPet.petBrithMonthSelect.selectValueContainsOption(month);
    }

    @And("I set the pet information on Add coverage page")
    public void iSetThePetInformationOnAddCoveragePage(PolicyMakechangeEntity policyMakechangeEntity) throws Exception {
        if (!policyMakechangeEntity.getGender().isEmpty())
            policyChangesForNewPet.genderOfthePet.selectValueContainsOption(this.replaceConfigurationValues(policyMakechangeEntity.getGender()));
        if (!policyMakechangeEntity.getPetName().isEmpty())
            policyChangesForNewPet.petNameTextBox.setText(this.replaceConfigurationValues(policyMakechangeEntity.getPetName()));
        if (!policyMakechangeEntity.getSpecies().isEmpty())
            policyChangesForNewPet.speciesOfThePet.selectValueContainsOption(this.replaceConfigurationValues(policyMakechangeEntity.getSpecies()));
        if (!policyMakechangeEntity.getBreed().isEmpty())
            Thread.sleep(2000);
        policyChangesForNewPet.breedOfThePet.selectValueContainsOption(this.replaceConfigurationValues(policyMakechangeEntity.getBreed()));
    }

    @DataTableType
    public PolicyMakechangeEntity getentity(Map<String, String> entity) {
        PolicyMakechangeEntity tmpp = new PolicyMakechangeEntity();
        if (entity.containsKey("Gender"))
            tmpp.setGender(entity.get("Gender"));
        if (entity.containsKey("Pet name"))
            tmpp.setPetName(entity.get("Pet name"));
        if (entity.containsKey("Species"))
            tmpp.setSpecies(entity.get("Species"));
        if (entity.containsKey("Breed"))
            tmpp.setBreed(entity.get("Breed"));
        return tmpp;
    }

    @Then("I select [{string}] for Coverage on Add coverage page")
    public void iSelectForCoverageOnAddCoveragePage(String option) throws Exception {
        if (option.contains("HereditaryPlus"))
            policyChangesForNewPet.hereDitaryPlusCheckBox.click();
        if (option.contains("SupportPlus"))
            policyChangesForNewPet.supportPlusCheckBox.check();
        if (option.contains("Alternative Plus"))
            policyChangesForNewPet.alternativePlusCheckBox.check();
        if (option.contains("Exam Plus"))
            policyChangesForNewPet.examPlusCheckBox.check();
        if (option.contains("Defender Plus"))
            policyChangesForNewPet.defenderPlusCheckBox.check();
        if (option.contains("Defender"))
            policyChangesForNewPet.defenderCheckBox.check();

    }

    @And("I click [Save] button on quote details page")
    public void iClickSaveButtonOnQuoteDetailsPage() throws Exception {
        policyChangesForNewPet.saveButtonButton.controlIsDisplayed(10);
        policyChangesForNewPet.saveButtonButton.click();
    }

    @And("click on Add Pet tab under Coverage header")
    public void clickOnAddPetTabUnderCoverageHeader() throws Exception {
        portalPolicyDetailsPage.addPetButton.controlIsDisplayed(5);
        portalPolicyDetailsPage.addPetButton.click();
    }

    @And("click on Continue button in Effective Date pop up window")
    public void clickOnContinueButtonInEffectiveDatePopUpWindow() throws Exception {
        portalPolicyDetailsPage.popupContinueButton.click();
    }


    @And("Set Cancel Coverage Details on Cancel Coverage Page")
    public void setCancelCoverageDetailsOnCancelCoveragePage(PolicyCancelEntity policyCancelEntity) throws Exception {
        if (!policyCancelEntity.getCancelRequestOnTextBox().isEmpty())
            policyCancelPage.cancelRequestOnTextBox.clear();
        policyCancelPage.cancelRequestOnTextBox.setText(this.replaceConfigurationValues(policyCancelEntity.getCancelRequestOnTextBox()));
        policyCancelPage.body.click();
        if (!policyCancelEntity.getCancelReasonDropdown().isEmpty())
            policyCancelPage.cancelReasonDropdown.selectValue(this.replaceConfigurationValues(policyCancelEntity.getCancelReasonDropdown()));
        if (!policyCancelEntity.getCancelTypeDropdown().isEmpty())
            policyCancelPage.cancelTypeDropdown.selectValue(this.replaceConfigurationValues(policyCancelEntity.getCancelTypeDropdown()));
        if (!policyCancelEntity.getCancelNotesTextBox().isEmpty())
            policyCancelPage.cancelNotesTextBox.setText(this.replaceConfigurationValues(policyCancelEntity.getCancelNotesTextBox()));
    }


    @Then("I click [Save] Button on Cancel Coverage Page")
    public void iClickSaveButtonOnCancelCoveragePage() throws Exception {
        policyCancelPage.saveButton.click();
    }

    @And("I click {string} Button On Cancel Coverage Page")
    public void iClickButtonOnCancelCoveragePage(String option) throws Exception {
        policyCancelPage.returnPolicyButton.controlIsDisplayed(5);
        policyCancelPage.returnPolicyButton.click();
    }

    @DataTableType
    public PolicyCancelEntity geeEntity(Map<String, String> entity) {
        PolicyCancelEntity tmp = new PolicyCancelEntity();
        if (entity.containsKey("Request on"))
            tmp.setCancelRequestOnTextBox(entity.get("Request on"));
        if (entity.containsKey("Cancel Reason"))
            tmp.setCancelReasonDropdown(entity.get("Cancel Reason"));
        if (entity.containsKey("Cancel Type"))
            tmp.setCancelTypeDropdown(entity.get("Cancel Type"));
        if (entity.containsKey("Notes"))
            tmp.setCancelNotesTextBox(entity.get("Notes"));
        return tmp;
    }

    @And("I click Cancel Coverage Button for pet name {string} on cancel coverage page")
    public void iClickCancelCoverageButtonForPetNameOnCancelCoveragePage(String value) throws Exception {
        if (policyCancelPage.cancelCoverage.getText().contains(value)) {
            policyCancelPage.cancelPolicyButton.click();
        }
    }

    @And("I set the pet name {string}")
    public void iSetThePetName(String name) throws Exception {
        policyCancelPage.petnameTextBox.setText(name);
    }

    @And("I click {string} Button on Policy details page")
    public void iClickButtonOnPolicyDetailsPage(String option) throws Exception {
        if (option.contains("Submit Approve")) {
            policyCancelPage.submitApprovalButton.click();
        }
        if (option.contains("Approve Cancellation")) {
            policyCancelPage.approveCancellationButton.click();
        } else if (option.contains("Approve Changes")) {
            policyCancelPage.approveChangesButton.controlIsDisplayed(5);
            policyCancelPage.approveChangesButton.click();
        }
    }

    @And("configure the Backdate Full Term Policy")
    public void configureTheBackdateFullTermPolicy(Map<String, String> data) throws Exception {
        if (data.containsKey("New Effective Date"))
            backDateSection.newEffectiveDateTextBox.clearSetText(this.replaceConfigurationValues(data.get("New Effective Date")));

        if (data.get("Coverage Period").equals("FirstValue"))
            backDateSection.coveragePeriodSelect.firstValue();
        else
            backDateSection.coveragePeriodSelect.selectValue(this.replaceConfigurationValues(data.get("Coverage Period")));

        if (data.containsKey("Notes"))
            backDateSection.notesTextBox.setText(this.replaceConfigurationValues(data.get("Notes")));

        backDateSection.saveButton.click();


    }
     @And("verify premium should be displayed as per {}")
    public void verifyPremiumShouldDisplayed(String value) throws Exception {
        Assertions.assertTrue(policyMakeChangesPage.premium.getText().contains(this.replaceConfigurationValues(value)), "ERROR! the Monthly Premium : [" + this.replaceConfigurationValues(value) + "] is not same after applied discount");
    }
    @And("I select {string} option under Cancel Reason on Cancel Policy Page")
    public void iSelectOptionUnderCancelReasononCancelPolicyPage(String option) throws Exception {
        policyCancelPage.cancelReasonDropdown.selectValueContainsOption(option);
    }
    @And("I select {string} option under Cancel Type on Cancel Policy Page")
    public void iSelectOptionUnderCancelTypeOnCancelPolicyPage(String option) throws Exception {
        policyCancelPage.cancelTypeDropdown.selectValueContainsOption(option);
    }
    @Then("^I click \\[(Preview|Submit)\\] Button on Cancel Policy Page$")
    public void iClickButtonOnCancelPolicyPage(String value) throws Exception {

        policyCancelPage.buttonsMap.get(value).controlIsDisplayed(5);
        policyCancelPage.buttonsMap.get(value).click();
    }
    @And("I Enter {string} to note section on Cancel Policy Page")
    public void iEnterToNoteSectionOnCancelPolicyPage(String value) throws Exception {
        policyCancelPage.notesTextBox.setText(this.replaceConfigurationValues(value));
    }
    @And("I click {string} button on the Edit payment information table")
    public void iClickButtonOnTheEditPaymentInformationTable(String option) throws Exception {
        editPaymentPage.editPaymentButtons.get(option).click();
    }
    @When("I fill out the Payment option details")
    public void iFillOutThePaymentOptionDetails(PolicyPaymentEntity paymentEntity) throws Exception {

        if ((!paymentEntity.getPaymentType().isEmpty()))
            editPaymentPage.paymentType.selectValueContainsOption(this.replaceConfigurationValues(this.replaceConfigurationValues(paymentEntity.getPaymentType())));
        if (!paymentEntity.getCreditCardType().isEmpty())
            editPaymentPage.cardType.selectValueContainsOption(this.replaceConfigurationValues(paymentEntity.getCreditCardType()));
        if (!paymentEntity.getCardNumber().isEmpty())
            editPaymentPage.cardNumberTextBox.setText(this.replaceConfigurationValues(paymentEntity.getCardNumber()));
        if (!paymentEntity.getExpirationDate().isEmpty())
            editPaymentPage.expirationDateTextBox.setTextAndEnter(this.replaceConfigurationValues(paymentEntity.getExpirationDate()));
        if (!paymentEntity.getCvv().isEmpty())
            editPaymentPage.cvvTextBox.setText(this.replaceConfigurationValues(paymentEntity.getCvv()));
    }

    @DataTableType
    public PolicyPaymentEntity getEnntity(Map<String, String> paymentEntity) {

        PolicyPaymentEntity payment = new PolicyPaymentEntity();
        if (paymentEntity.containsKey("Payment Type"))
            payment.setPaymentType(paymentEntity.get("Payment Type"));
        if (paymentEntity.containsKey("Credit Card Type"))
            payment.setCreditCardType(paymentEntity.get("Credit Card Type"));
        if (paymentEntity.containsKey("Card Number"))
            payment.setCardNumber(paymentEntity.get("Card Number"));
        if (paymentEntity.containsKey("Expiration Date"))
            payment.setExpirationDate(paymentEntity.get("Expiration Date"));
        if (paymentEntity.containsKey("Cvv"))
            payment.setCvv(paymentEntity.get("Cvv"));
        return payment;
    }

    @And("I click on [{}] button on the Edit Payment page")
    public void iClickOnButtonOnTheEditPaymentPage(String button) throws Exception {
        if (button.contains("Save")) {
            editPaymentPage.saveButton.click();
        } else if (button.contains("Cancel")) {
            editPaymentPage.cancelButton.click();

        }
    }

    @When("I select the value [{}] on Followup details page")
    public void iSelectTheValueOnFollowupDetailsPage(String value) throws Exception {
        followUpsPage.complainTypeDropDown.selectValueContainsOption(value);
    }

    @And("I click on [Add New] button on the Follow-Up\\(s) tab")
    public void iClickOnAddNewButtonOnTheFollowUpSTab() throws Exception {
        followUpsPage.addNewButtonFollowUps.click();
    }

    @When("I select the value [{}] on the follow up type dropdown")
    public void iSelectTheValueOnTheFollowUpTypeDropdown(String value) throws Exception {
        followUpsPage.followupTypeDropDown.selectValueContainsOption(value);
    }

    @And("I click on {string} button on the Follow ups page")
    public void iClickOnButtonOnTheFollowUpsPage(String button) throws Exception {
        if (button.contains("Save")) {
            followUpsPage.saveButtonFollowUpPage.click();
        } else if (button.contains("Cancel")) {
            followUpsPage.cancelButtonFollowUpPage.click();

        }
    }



    @And("check if the {string} note is displayed")
    public void checkIfTheNoteIsDisplayed(String word, String expectedResult) throws Exception {
        Label noteInLabel = new Label(By.xpath("//div[contains(text(),'" + word + "')]"));
        String actualResult = noteInLabel.getText();

        Pattern pattern = Pattern.compile(expectedResult);
        Matcher matcher = pattern.matcher(actualResult);
        boolean isMatch = matcher.matches();
        Assertions.assertTrue(isMatch, "ERROR! the note added is wrong, actual: " + actualResult + " VS expected: " + expectedResult);

    }

    @Then("I select {string} user in popup Transfer Sale")
    public void iSelectTestUserUser(String userName) throws Exception {
        transferSaleDialog.transferSale(userName);
    }

    @And("click on {string} button in pet coverage page")
    public void clickOnButtonInPetCoveragePage(String addCardButton) throws Exception {
        selectTestCoverage.addToCartButton.click();
    }

    @Then("I verify Premium amount display under the Coverage period [{}]")
    public void iVerifyPremiumAmountDisplayUnderTheCoveragePeriod(String expected) throws Exception {
        Assertions.assertTrue(policyDetailsPage.premiumAmountLabel.getText().replaceAll("\\d+"," ").contains(this.replaceConfigurationValues(expected)),
                "ERROR! the value : [" + this.replaceConfigurationValues(expected) + "] is not displayed under the coverage period");
    }
}
