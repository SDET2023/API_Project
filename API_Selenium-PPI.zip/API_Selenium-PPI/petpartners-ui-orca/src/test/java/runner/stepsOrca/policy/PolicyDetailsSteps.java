package runner.stepsOrca.policy;

import configuration.CommonValues;
import control.Table;
import entities.orca.policy.PremiumTrackerEntity;
import entities.orca.policy.TransactionTypeEntity;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orca.policy.PolicyDetailsPage;
import pages.orca.policy.noteTab.AddNoteSection;
import runner.BaseSteps;
import session.Session;
import utils.Level;
import utils.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class PolicyDetailsSteps extends BaseSteps {
    PolicyDetailsPage policyDetailsPage = new PolicyDetailsPage();
    AddNoteSection addNoteSection = new AddNoteSection();
    @And("I click on [{}] link in attachment tab")
    public void iClickOnLinkInAttachmentTab(String sLink)  throws Exception {
        policyDetailsPage.attachmentTabLinksMap.get(sLink).controlIsDisplayed(10);
        policyDetailsPage.attachmentTabLinksMap.get(sLink).click();
    }

    @Then("I verify [{}] document type label")
    public void iVerifyDocumentTypeLabel(String sDocType) {
        Assertions.assertTrue(policyDetailsPage.attachmentTabDocTypeLabelsMap.get(sDocType).controlIsDisplayed(10),
                "ERROR: " + sDocType + " is not displayed");
    }
    @Then("the policy detail form with labels should be displayed")
    public void thePolicyDetailFormWithLabelsShouldBeDisplayed(List<String> labels) throws Exception {
        List<String> isNotDisplayedList = new ArrayList<>();
        for (String label : labels) {
            if (!policyDetailsPage.labelMap.containsKey(label))
                throw new Exception("ERROR> Please add the label [" + label + "] in the mapping page");

            if (policyDetailsPage.labelMap.containsKey(label) && !policyDetailsPage.labelMap.get(label).controlIsDisplayed())
                isNotDisplayedList.add(label);
        }
        Assertions.assertTrue(isNotDisplayedList.size() == 0, "ERROR> Some labels are not displayed on Policy Details: \n " + isNotDisplayedList.toString());
    }



    @And("click on [{}] tab option on policy detail page")
    public void clickOnPolicyDetailTabOption(String tabOption) throws Exception {
        policyDetailsPage.tabOptionLabelsMap.get(tabOption).click();
        this.loadingSection.loadingSpinnerTableValueIcon.waitWhileControlDisappears(15);
    }

    @And("^click on (Active|Upcoming|Expired) on Policy Term on policy detail page$")
    public void clickOnActiveOnPolicyTerm(String value) throws Exception {
        Thread.sleep(2000);
        this.loadingSection.loadingSpinnerTableValueIcon.waitWhileControlDisappears(15);
        if (value.contains("Active")) {
            policyDetailsPage.activeLink.controlIsDisplayed();
            policyDetailsPage.activeLink.controlIsClickable();
            policyDetailsPage.activeLink.click();
        } else if (value.contains("Upcoming")) {
            policyDetailsPage.upcomingLink.controlIsDisplayed();
            policyDetailsPage.upcomingLink.controlIsClickable();
            policyDetailsPage.upcomingLink.click();
        } else {
            policyDetailsPage.expiredLink.controlIsDisplayed();
            policyDetailsPage.expiredLink.controlIsClickable();
            policyDetailsPage.expiredLink.click();
        }
        Thread.sleep(5000);
    }

    @And("click on Past on Policy Term on policy detail page")
    public void clickOnPastOnPolicyTermOnPolicyDetailPage() throws Exception {
        policyDetailsPage.pastCoverageLink.click();
    }

    @Then("^verify the (Active|Upcoming) pet detail should be displayed$")
    public void verifyTheActivePetDetailShouldBeDisplayed(String value) throws InterruptedException {
        Thread.sleep(2500);
        Assertions.assertTrue(policyDetailsPage.coveragePeriodLink.controlIsDisplayed(), "ERROR! the coverage on active link is not displayed on coverage tab");
    }

    @And("^click on \\[\\+\\] button on (active pet detail|under warning active pet detail|upcoming pet detail)$")
    public void clickOnButtonOnActivePetDetail(String site) throws Exception {
        policyDetailsPage = new PolicyDetailsPage();
        policyDetailsPage.plusPetDetailButton.controlIsDisplayed();
        policyDetailsPage.plusPetDetailButton.click();
    }

    @And("the status control should be {string} on Policy Detail Page")
    public void theControlShouldBeOnPolicyDetailPage(String expectedResult) throws Exception {
        policyDetailsPage.statusSelect.controlIsDisplayed(20);
        String actualResult = policyDetailsPage.statusSelect.getTextOptionSelected();
        Assertions.assertEquals(expectedResult, actualResult, "ERROR! the status values is  different, actual: " + actualResult + " vs expected: " + expectedResult);
    }



    @And("the status label should be {string} on Policy Detail Page")
    public void theStatusLabelShouldBeOnPolicyDetailPage(String expectedResult) throws Exception {
        String actualResult = policyDetailsPage.policyStatusLabel.getText();
        Assertions.assertEquals(expectedResult, actualResult, "ERROR! the status values is  different, actual: " + actualResult + " vs expected: " + expectedResult);
    }

    @And("select the {string} option on Status on Policy Detail Page")
    public void selectTheOptionOnStatusOnPolicyDetailPage(String option) throws Exception {
        policyDetailsPage.statusSelect.selectValue(option);
        Thread.sleep(3000);
    }

    @And("click on [save] button on Policy Detail Page")
    public void clickOnButtonOnPolicyDetailPage() throws Exception {
        policyDetailsPage.saveButton.click();
        Thread.sleep(3000);
    }

    @And("I click on [Add New] button on claims tab")
    public void iClickOnAddNewButtonOnClaimsTab() throws Exception {
        policyDetailsPage.addNewClaimButton.click();
    }

    @And("I click on [Move Claims] button on claims tab")
    public void iClickOnMoveClaimsButtonOnClaimsTab() throws Exception {
        policyDetailsPage.moveClaimButton.click();
    }

    @And("click on customer tab in bottom section")
    public void clickOnCustomerTabInBottomSection() throws Exception {
        policyDetailsPage.tabOptionLabelsMap.get("Customer(s)").click();
        Thread.sleep(3000);
    }

    @And("verify the customer {} is displayed")
    public void verifyTheCustomerDefaultUerIsDisplayed(String email) {
        Assertions.assertTrue(policyDetailsPage.emailCustomer(this.replaceConfigurationValues(email)), "ERROR ! email: " + this.replaceConfigurationValues(email) + "is not displayed in customer tab");
    }

    @And("select {string} in Policy Actions in Policy Detail Page")
    public void selectInPolicyActionsInPolicyDetailPage(String policyAction) throws Exception {
        policyDetailsPage.selectOptionPolicyActions(policyAction);
    }

    @And("^select on \\[(Make Changes|Transfer Sale)\\] option on Policy Term>Active>Policy detail page$")
    public void selectOnMakeChangesOptionOnPolicyTermActivePolicyDetailPage(String option) throws Exception {
        policyDetailsPage.makeChangesButton.controlIsDisplayed(5);
        policyDetailsPage.makeChangesButton.controlIsClickable();
        policyDetailsPage.makeChangesButton.click();

        if (option.contains("Make Changes")) {
            policyDetailsPage.makeChangesOption.controlIsDisplayed();
            policyDetailsPage.makeChangesOption.click();
        } else {
            policyDetailsPage.transferSaleOption.controlIsDisplayed();
            policyDetailsPage.transferSaleOption.click();
        }
    }


    @And("create a new Note using: {string} Policy Detail Page")
    public void createANewNoteUsingPolicyDetailPage(String noteData) throws Exception {
        policyDetailsPage.addNoteButton.click();
        //addNoteSection.detailTextBox.setText(this.replaceConfigurationValues(noteData));
        Session.getInstance().getDriver().switchTo().frame("noteTextBox_ifr");
        addNoteSection.typeHereTextBox.setText(this.replaceConfigurationValues(noteData));
        Thread.sleep(10000);
        Session.getInstance().getDriver().switchTo().defaultContent();
        addNoteSection.saveButton.controlIsClickable();
        addNoteSection.saveButton.click();

    }
    @Then("verify the {string} should be displayed on Policy Detail Page")
    public void verifyTheShouldBeDisplayedOnPolicyDetailPage(String expectedNote) {
        Assertions.assertTrue(policyDetailsPage.isNoteDisplayed(this.replaceConfigurationValues(expectedNote)), "ERROR> the note: [" + expectedNote + "] is not displayed");
    }


    @Then("verify the buttons are displayed in Policy Detail Page")
    public void verifyTheButtonsAreDisplayedInPolicyDetailPage(List<String> buttonNameList) {
        for (String buttonName : buttonNameList) {
            Assertions.assertTrue(policyDetailsPage.buttonsMap.get(buttonName).controlIsDisplayed(), "ERROR: the button: [" + buttonName + "] is not displayed");
        }
    }

    @And("select the {string} option on Hold Payment on Policy Detail Page")
    public void selectTheOptionOnHoldPaymentOnPolicyDetailPage(String option) throws Exception {
        policyDetailsPage.holdPaymentSelect.selectValue(this.replaceConfigurationValues(option));
    }

    @Then("^verify the headers should be displayed in the (Pet Detail Table|Upcoming Pet Detail Table)$")
    public void verifyTheHeadersShouldBeDisplayedInThePetDetailTable(String site, List<String> expectedHeaderList) throws Exception {
        Table assertTable = site.contains("Upcoming") ? policyDetailsPage.activeSecondPetDetailTable : policyDetailsPage.activePetDetailTable;
        Assertions.assertTrue(assertTable.verifyAllHeaderLabel(expectedHeaderList), "ERROR> the headers are not displayed: " + expectedHeaderList.toString());
    }

    @And("^click \\[(Submit for Approval|Discard Changes|Save|Approve Changes)\\] button on policy detail page$")
    public void clickSubmitForApprovalButtonOnPolicyDetailPage(String buttonName) throws Exception {
        policyDetailsPage.buttonsMap.get(buttonName).click();
    }

    @Then("^verify the \"(Active|Upcoming|Expired)\" link is displayed on policy detail$")
    public void verifyTheLinkIsDisplayedOnPolicyDetail(String linkName) {
        boolean isLinkDisplayed;
        if (linkName.contains("Active"))
            isLinkDisplayed = policyDetailsPage.activeLink.controlIsDisplayed();
        else if (linkName.contains("Upcoming"))
            isLinkDisplayed = policyDetailsPage.upcomingLink.controlIsDisplayed();
        else
            isLinkDisplayed = policyDetailsPage.expiredLink.controlIsDisplayed();

        Assertions.assertTrue(isLinkDisplayed, "ERROR> the [" + linkName + "] is not displayed, please review it.");
    }

    @And("^click on (Premium Tracker) link on policy detail$")
    public void clickOnLinkOnPolicyDetail(String linkName) throws Exception {
        policyDetailsPage.premiumTrackerLink.click();
    }

    @Then("verify the headers should be displayed in the Premium Tracker table")
    public void verifyTheHeadersShouldBeDisplayedInThePremiumTrackerTable(List<String> expectedHeaderList) throws Exception {
        Assertions.assertTrue(policyDetailsPage.premiumTrackerTable.verifyAllHeaderLabel(expectedHeaderList), "ERROR> the headers are not displayed: " + expectedHeaderList.toString());
    }

    @And("^verify if the next values (are|are not) displayed on (Pet Detail Table|Upcoming Pet Detail Table)$")
    public void verifyIfTheNextValuesAreDisplayedOnPetDetailTable(String verification, String site, List<String> expectedValuesTable) throws Exception {
        Table assertTable = site.contains("Upcoming") ? policyDetailsPage.activeSecondPetDetailTable : policyDetailsPage.activePetDetailTable;
        for (String value : expectedValuesTable) {
            if (verification.contains("are not")) {
                Assertions.assertFalse(assertTable.checkIfValueIsDisplayedInTable(value), "ERROR> the headers are displayed: " + value);
            } else {
                Assertions.assertTrue(assertTable.checkIfValueIsDisplayedInTable(value), "ERROR> the headers are not displayed: " + value);
            }
        }

    }


    @And("verify the Premium Tracker table in policy detail")
    public void verifyThePremiumTrackerTableInPolicyDetail(List<PremiumTrackerEntity> tableDataExpectedResult) throws Exception {
        int cpId = 0;
        int effectiveOn = 1;
        int endOn = 2;
        int netPremium = 3;
        int billedPremium = 4;
        String ignore = "IGNORE";
        boolean isTableEqual = true;
        String msgError = "";
        List<List<String>> tableActualResult = policyDetailsPage.premiumTrackerTable.getTableSpecialsValue();
        // we start from 1 because the posotion 0 is the name of columns
        for (int i = 0; i < tableDataExpectedResult.size(); i++) {
            PremiumTrackerEntity expected = tableDataExpectedResult.get(i);
            List<String> actual = tableActualResult.get(i);

            actual.set(cpId, expected.getCpId().contains(ignore) ? ignore : actual.get(cpId));
            actual.set(effectiveOn, expected.getEffectiveOn().contains(ignore) ? ignore : actual.get(effectiveOn));
            actual.set(endOn, expected.getEndOn().contains(ignore) ? ignore : actual.get(endOn));
            actual.set(netPremium, expected.getNetPremium().contains(ignore) ? ignore : actual.get(netPremium));
            actual.set(billedPremium, expected.getBilledPremium().contains(ignore) ? ignore : actual.get(billedPremium));

            if (!actual.get(cpId).contains(expected.getCpId()) ||
                    !actual.get(effectiveOn).contains(expected.getEffectiveOn()) ||
                    !actual.get(endOn).contains(expected.getEndOn()) ||
                    !actual.get(netPremium).contains(expected.getNetPremium()) ||
                    !actual.get(billedPremium).contains(expected.getBilledPremium())) {

                msgError = msgError + "\nERROR! the row [" + i + "] has different values: " +
                        "\nthe actual value: [ " + actual.get(cpId) + " | " + actual.get(effectiveOn) + " | " + actual.get(endOn) + " | " + actual.get(netPremium) + " | " + actual.get(billedPremium) + " ]" +
                        "\nthe expected value: [ " + expected.getCpId() + " | " + expected.getEffectiveOn() + " | " + expected.getEndOn() + " | " + expected.getNetPremium() + " | " + expected.getBilledPremium() + " ]";

                isTableEqual = false;
            }

        }
        Assertions.assertTrue(isTableEqual, "ERROR the values in product table are not the same: " + msgError);
    }

    @DataTableType
    public PremiumTrackerEntity getPremiumTrackerEntity(Map<String, String> data) {
        PremiumTrackerEntity entity = new PremiumTrackerEntity();
        entity.setCpId(this.replaceConfigurationValues(data.get("CP Id")))
                .setEffectiveOn(this.replaceConfigurationValues(data.get("Effective On")))
                .setEndOn(this.replaceConfigurationValues(data.get("End on")))
                .setNetPremium(this.replaceConfigurationValues(data.get("Net Premium")))
                .setBilledPremium(this.replaceConfigurationValues(data.get("Billed Premium")));

        return entity;
    }

    @DataTableType
    public TransactionTypeEntity getTransactionTypeEntity(Map<String, String> data) {
        TransactionTypeEntity entity = new TransactionTypeEntity();
        entity.setTransactionType(this.replaceConfigurationValues(data.get("Transaction Type")))
                .setPaymentType(this.replaceConfigurationValues(data.get("Payment Type")))
                .setDescription(this.replaceConfigurationValues(data.get("Description")))
                .setCreatedOn(this.replaceConfigurationValues(data.get("Created On")))
                .setAmount(this.replaceConfigurationValues(data.get("Amount")))
                .setBalance(this.replaceConfigurationValues(data.get("Balance")));

        return entity;
    }

    @And("^get the CP ID from (Active|Upcoming|Expired) to (.*) on policy detail page$")
    public void getTheCPIDFromActiveToVariablePolicyDetailPage(String type, String variableName) throws Exception {
        CommonValues.variables.put(variableName, policyDetailsPage.getTheCpId(type));
        Logger.log(Level.INFO, this.getClass().getName() + "> save the value: [" + CommonValues.variables.get(variableName) + "] in [" + variableName + "]");
    }


    @And("verify the Cancellation Detail row with Pet Name: {string} in policy detail page")
    public void verifyTheCancellationDetailRowWithPetNameInPolicyDetailPage(String petName, String expectedMessage) throws Exception {
        petName = this.replaceConfigurationValues(petName);
        String actualResult = policyDetailsPage.getCancelDetailMessageInTable(petName);
        expectedMessage = this.replaceConfigurationValues(expectedMessage);
        Assertions.assertTrue(actualResult.contains(expectedMessage), "ERROR the expected: [" + expectedMessage + "] vs actual [" + actualResult + "]");
    }

    @And("verify the values for next controls in policy detail")
    public void verifyTheValuesForNextControlsInPolicyDetail(Map<String, String> expectedData) throws Exception {
        for (String expectedControl : expectedData.keySet()
        ) {
            String actualResult = policyDetailsPage.getValueFromControl(expectedControl);
            Assertions.assertTrue(actualResult.contains(this.replaceConfigurationValues(expectedData.get(expectedControl))),
                    "ERROR> control: [" + expectedControl + "] actual result: [" + actualResult + "] vs expected result: [" + this.replaceConfigurationValues(expectedData.get(expectedControl)) + "]");
        }
    }

    @When("Click on Certificate Invoice link on Transactions table")
    public void clickOnCertificateInvoiceLinkOnTransactionsTable() throws Exception {
        policyDetailsPage.certificateInvoiceLink.click();
    }

    @And("verify the Transactions Table in policy detail page")
    public void verifyTheTransactionsTableInPolicyDetail(List<TransactionTypeEntity> tableDataExpectedResult) throws Exception {
        int transactionType = 0;
        int paymentType = 1;
        int description = 2;
        int createdOn = 3;
        int amount = 4;
        int balance = 5;
        String ignore = "IGNORE";
        boolean isTableEqual = true;
        String msgError = "";
        List<List<String>> tableActualResult = policyDetailsPage.transactionTypeTable.getTableSpecialsValue();

        // we start from 1 because the posotion 0 is the name of columns
        for (int i = 1; i < tableDataExpectedResult.size(); i++) {
            TransactionTypeEntity expected = tableDataExpectedResult.get(i);
            List<String> actual = tableActualResult.get(i);

            actual.set(transactionType, expected.getTransactionType().contains(ignore) ? ignore : actual.get(transactionType));
            actual.set(paymentType, expected.getPaymentType().contains(ignore) ? ignore : actual.get(paymentType));
            actual.set(description, expected.getDescription().contains(ignore) ? ignore : actual.get(description));
            actual.set(createdOn, expected.getCreatedOn().contains(ignore) ? ignore : actual.get(createdOn));
            actual.set(amount, expected.getAmount().contains(ignore) ? ignore : actual.get(amount));
            actual.set(balance, expected.getBalance().contains(ignore) ? ignore : actual.get(balance));

            if (!actual.get(transactionType).contains(expected.getTransactionType()) ||
                    !actual.get(paymentType).contains(expected.getPaymentType()) ||
                    !actual.get(description).contains(expected.getDescription()) ||
                    !actual.get(createdOn).contains(expected.getCreatedOn()) ||
                    !actual.get(amount).contains(expected.getAmount()) ||
                    !actual.get(balance).contains(expected.getBalance())) {

                msgError = msgError + "\nERROR! the row [" + i + "] has different values: " +
                        "\nthe actual value: [ " + actual.get(transactionType) + " | " + actual.get(paymentType) + " | " + actual.get(description) + " | " + actual.get(createdOn) + " | " + actual.get(amount) + " | " + actual.get(balance) + " ]" +
                        "\nthe expected value: [ " + expected.getTransactionType() + " | " + expected.getPaymentType() + " | " + expected.getDescription() + " | " + expected.getCreatedOn() + " | " + expected.getAmount() + " | " + expected.getBalance() + " ]";

                isTableEqual = false;
            }

        }
        Assertions.assertTrue(isTableEqual, "ERROR the values in product table are not the same: " + msgError);
    }

    @And("verify the message is displayed in Upcoming Section")
    public void verifyTheMessageIsDisplayedInUpcomingSection(String message) throws Exception {
        String actualResult = policyDetailsPage.changesUpcomingLabel.getText();
        Assertions.assertTrue(actualResult.contains(message), "ERROR!  the actual result: [ " + actualResult + "] does not contain expected result: [" + message + "]");
    }

    @Then("I verify  {string} display on the  policy term")
    public void iVerifyDisplayOnThePolicyTerm(String expectedResult) throws Exception {
        if (policyDetailsPage.resultLabels.containsKey(expectedResult)) {
            Assertions.assertTrue(policyDetailsPage.resultLabels.get(expectedResult).getText().contains(this.replaceConfigurationValues(expectedResult)),
                    "ERROR! the value : [" + this.replaceConfigurationValues(expectedResult) + "] is not displayed in the notes Activated by label");
        }

    }

    @And("I select {string} under Policy Actions drop down")
    public void iSelectUnderPolicyActionsDropDown(String option) throws Exception {
        policyDetailsPage.policyCancelButton.click();
    }

    @And("I verify {string} is displayed on Policy Details Page")
    public void iVerifyIsDisplayedOnPolicyDetailsPage(String value) throws Exception {
        Assertions.assertTrue(policyDetailsPage.partnerLabel.getText().contains(this.replaceConfigurationValues(value)), "ERROR! the PetPartners : [" + this.replaceConfigurationValues(value) + "] is not displayed on Policy Details Page");
    }

    @And("click on view customer icon under Action")
    public void clickOnViewCustomerIconUnderAction() throws Exception {
        policyDetailsPage.viewCustomerIconInActionsLink.click();
    }

    @And("I get the value of {string} in the variable: {}")
    public void iGetTheValueOfInTheVariableSoldBy(String control, String variableName) throws Exception {
        String actualResult = policyDetailsPage.getValueFromControl(control);
        CommonValues.variables.put(variableName, actualResult);
        Logger.log(Level.INFO, this.getClass().getName() + "> save the value: [" + CommonValues.variables.get(variableName) + "] in [" + variableName + "]");

    }

    @And("I click on [Edit Payment] button on the policy details page")
    public void iClickOnEditPaymentButtonOnThePolicyDetailsPage() throws Exception {
        policyDetailsPage.editPaymentButton.click();
    }
    @Then("I verify hold payment status should be {string}")
    public void iVerifyHoldPaymentStatusShouldBe(String expectedResult) throws Exception {
        policyDetailsPage.holdPaymentSelect.controlIsDisplayed(20);
        String actualResult = policyDetailsPage.holdPaymentSelect.getTextOptionSelected();
        Assertions.assertEquals(expectedResult, actualResult, "ERROR! the status values is  different, actual: " + actualResult + " vs expected: " + expectedResult);
    }

    @And("click on Pet Name: {string} on Upcoming Period Table")
    public void clickOnPetNameOnUpcomingPeriodTable(String petName) throws Exception {
        policyDetailsPage.clickPetNameLinkTable(this.replaceConfigurationValues(petName));
    }

    @And("click on Pet Name: {string} on Active Period Table")
    public void clickOnPetNameOnActivePeriodTable(String petName) throws Exception {
        policyDetailsPage.clickPetNameLinkTable(this.replaceConfigurationValues(petName));
    }

    @And("click on [+Add New] button in Follow-up\\(s) tab section")
    public void clickOnAddNewButtonInFollowUpSTabSection() throws Exception {
        policyDetailsPage.addNewFollowUpButton.controlIsDisplayed(5);
        policyDetailsPage.addNewFollowUpButton.click();
    }

    @And("I click on [{}] Button in Row {int} of FollowUp Table")
    public void iClickOnTakeOwnershipButtonInRowOfFollowUpTable(String buttonName, int row) throws Exception {
        policyDetailsPage.followUpTable.clickLinkJoinXpath("Actions", row, "//a[@title='" + buttonName + "']");
    }

    @And("verify the column {string} should be contains {string} in FollowUp Table")
    public void verifyTheColumnShouldBeContainsInFollowUpTable(String columnName, String expectedValue) throws Exception {
        Assertions.assertTrue(policyDetailsPage.followUpTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(expectedValue)), "" +
                "ERROR> the value: [" + this.replaceConfigurationValues(expectedValue) + "] is not disdplayed in the follow up table");

    }

    @And("click on the petname {string} label in the pet table")
    public void clickOnThePetnameLabelInThePetTable(String petName) throws Exception {
        policyDetailsPage.petsTable.controlIsDisplayed(5);
        policyDetailsPage.petsTable.clickOnLinkCell(this.replaceConfigurationValues(petName));
    }
    @Then("verify the transfer sale note of {string} displayed on Policy Detail Page")
    public void verifyTheTransferSaleNoteDisplayedOnPolicyDetailPage(String variableName) throws Exception {
        String cpId = CommonValues.variables.get(variableName);
        String expectedNote = "Automtion Testing transferred the sale of CP ID:" + cpId + " from web server to Test User";
        Assertions.assertTrue(policyDetailsPage.isNoteDisplayed(this.replaceConfigurationValues(expectedNote)), "ERROR> the note: [" + expectedNote + "] is not displayed");
    }
    @And("I select {string} under Policy Actions dropdown")
    public void iSelectUnderPolicyActionsDropdown(String option) throws Exception {
        policyDetailsPage.policyActionsDropdownLink(this.replaceConfigurationValues(option));
    }

    @And("I click {string} on reinstate popup")
    public void iClickOnReinstatePopup(String option) throws Exception {
        policyDetailsPage.clickOnReinstatePopup(this.replaceConfigurationValues(option));
    }

    @And("I save Pets Names in the variable: {}")
    public void iSaveValueOnNAME(String nameVariable) throws Exception {
        List<String> petsNames = new ArrayList<>();
        for (int i = 1; i <= policyDetailsPage.petsTable.getRowCount(); i++) {
            System.out.println(policyDetailsPage.petsTable.getValueCell(1, i));
            petsNames.add(policyDetailsPage.petsTable.getValueCell(1, i));
        }
        CommonValues.variables.put(nameVariable, petsNames.toString());
        Logger.log(Level.INFO, this.getClass().getName() + " save the variable [" + nameVariable + "] value: " + CommonValues.variables.get(nameVariable));
    }
    @Then("I verify the a new note should be displayed with message under Policy Details - Notes tab")
    public void iVerifyNewNoteIsDisplayedUnderPolicyDetailsNotes(String expectedResult) throws Exception {
        Thread.sleep(3000);
        policyDetailsPage.checkReissueNotesLabel.waitUntilControlIsDisplayed();
        String actualResult = policyDetailsPage.checkReissueNotesLabel.getText().trim();
        expectedResult = this.replaceConfigurationValues(expectedResult);
        Assertions.assertTrue(actualResult.contains(expectedResult),
                "ERROR the check reissued message is not displayed successfully, actual: [" + actualResult + "] vs expected: [" + expectedResult + "]");
    }

    @And("validate Dnoc on date with {string} and cancel on with {string} are displayed")
    public void verifyDnocOnDateAndCancelOnDateAreDisplayed(String dnocDate, String cancelOnDate) throws Exception {
        Assertions.assertTrue(policyDetailsPage.historyColumnsDisplayed(), "Error : DNOC on and Cancel On date are not displayed");
        String expectedDnocDate = CommonValues.variables.get(dnocDate);
        String expectedCancelOnDate = CommonValues.variables.get(cancelOnDate);
        int dnocColumn = policyDetailsPage.policyStatusHistoryTable.getPositionColumn("DNOC On");
        int cancelOnColumn = policyDetailsPage.policyStatusHistoryTable.getPositionColumn("Cancel On");
        Assertions.assertEquals(policyDetailsPage.policyStatusHistoryTable.getValueCell(dnocColumn, 1), expectedDnocDate, "ERROR: The expected date " + expectedDnocDate + " is not matching with the actual date");
        Assertions.assertEquals(policyDetailsPage.policyStatusHistoryTable.getValueCell(cancelOnColumn, 1), expectedCancelOnDate, "ERROR: The expected date " + expectedCancelOnDate + " is not matching with the actual date");
    }

    @And("verify the pet status is Active or Upcoming on Policy Detail Page")
    public void verifyThePetStatusIsActiveOrUpcomingOnPolicyDetailPage() throws Exception {
        String petStatus = policyDetailsPage.petStatus.getText();
        Logger.log(Level.INFO, this.getClass().getName() + "> pet status is " + petStatus);
    }

    @And("I verify the Finance and Cancellation document names are displayed")
    public void iVerifyTheFinanceAndCancellationDocumentNamesAreDisplayed(DataTable dataTable) throws Exception {
        List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);
        for (Map<String, String> dataa : data) {
            String fileName = policyDetailsPage.getNameByFileText(dataa.get("File Name"));
            Assertions.assertNotNull(fileName, "File name " + dataa.get("File Name") + " is not found ");
            Logger.log(Level.INFO, this.getClass().getName() + "> the file name for " + dataa.get("File Name") + " is " + fileName);
        }
    }

    @And("I click on {string} tab under Term")
    public void iClickOnTabUnderTerm(String tabName) throws Exception {
        policyDetailsPage.financeAndCancellationLink.click();

    }

}
