package runner.stepsOrca.policy;
import control.Checkbox;
import entities.orca.makeChanges.MakeChangesProductEntity;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import org.openqa.selenium.interactions.Actions;
import pages.orca.policy.PolicyMakeChangesPage;
import entities.orca.makeChanges.MakeChangesPetDetailsEntity;
import io.cucumber.java.DataTableType;
import pages.orca.quote.QuoteDetailsPage;
import runner.BaseSteps;
import session.Session;

import java.util.Map;

public class MakeChangesSteps extends BaseSteps {
    PolicyMakeChangesPage makeChangesPage = new PolicyMakeChangesPage();
    QuoteDetailsPage quoteDetailsPage = new QuoteDetailsPage();

    @And("change pet details in make changes page")
    public void changePetDetailsInMakeChangesPage(MakeChangesPetDetailsEntity makeChangesPetEntity) throws Exception {
        this.makeChangesPage.fillPetDetailsInMakeChangesScreen(makeChangesPetEntity);
    }

    @DataTableType
    public MakeChangesPetDetailsEntity makeChangesPetDetailsEntity(Map<String, String> entry) {
        MakeChangesPetDetailsEntity entity = new MakeChangesPetDetailsEntity();
        entity.setMakeChangesPetName(this.replaceConfigurationValues(entry.get("CHG PETNAME")))
                .setMakeChangesPetDOB(this.replaceConfigurationValues(entry.get("CHG DOB")))
                .setMakeChangesPetGender(this.replaceConfigurationValues(entry.get("CHG GENDER")))
                .setMakeChangesPetSpecies(this.replaceConfigurationValues(entry.get("CHG SPECIES")))
                .setMakeChangesPetBreed(this.replaceConfigurationValues(entry.get("CHG BREED")));

        return entity;
    }

    @DataTableType
    public MakeChangesProductEntity makeChangesProductEntity(Map<String, String> entry) {
        MakeChangesProductEntity entity = new MakeChangesProductEntity();
        entity.setCovProdType(this.replaceConfigurationValues(entry.get("PRODUCTTYPE")))
                .setCovHereditaryPlus(this.replaceConfigurationValues(entry.get("HEREDITARYPLUS")))
                .setCovSupportPlus(this.replaceConfigurationValues(entry.get("SUPPORTPLUS")))
                .setCovBreedingCoverage(this.replaceConfigurationValues(entry.get("BREEDINGCOVERAGE")))
                .setCovAlternativePlus(this.replaceConfigurationValues(entry.get("ALTERNATIVEPLUS")))
                .setCovExamPlus(this.replaceConfigurationValues(entry.get("EXAMPLUS")))
                .setCovDefenderPlus(this.replaceConfigurationValues(entry.get("DEFENDERPLUS")))
                .setCovDefender(this.replaceConfigurationValues(entry.get("DEFENDER")));

        return entity;
    }

    @And("change coverage limits in make changes page in row {string}")
    public void changeCoverageLimitsInMakeChangesPage(String rowNum, Map<String, String> approvedSectionValues) throws Exception {
        for (String key : approvedSectionValues.keySet()) {
            if (makeChangesPage.coverageDetailsTableCell.containsKey(key) && makeChangesPage.coverageDetailsTableCell.get(key).getTypeCell().equals("select")) {
                makeChangesPage.coverageDetailsTable.select(makeChangesPage.coverageDetailsTableCell.get(key).getPosition(), Integer.parseInt(rowNum), this.replaceConfigurationValues(approvedSectionValues.get(key)));
            }
        }
    }

    @When("click Save button in make changes page")
    public void clickSaveButtonInMakeChangesPage() throws Exception {
        makeChangesPage.saveButtonMakeChangesPage.controlIsDisplayed(5);
        makeChangesPage.saveButtonMakeChangesPage.click();
        makeChangesPage.saveButtonMakeChangesPage.controlIsNotDisplayed(10);
        new Actions(Session.getInstance().getDriver()).moveByOffset(10, 200).click().perform();
        if (quoteDetailsPage.plusButton.controlIsDisplayed(5))
            quoteDetailsPage.plusButton.click();
    }

    @And("select product name")
    public void selectProductName() throws Exception {
        makeChangesPage.accidentCareCheckbox.check();
    }

    @And("^I update the \\[(CompanionCare|AccidentCare)\\] checkboxes in MakeChanges Modal$")
    public void unselectTheCompanionCareCheckboxesInMakeChangesModal(String checkboxesType, Map<String, String> checkBoxesNames) throws Exception {
        Map<String, Checkbox> checkboxMap = checkboxesType.contains("CompanionCare") ?
                makeChangesPage.companionCareCheckBoxesMap :
                makeChangesPage.accidentCareCheckBoxesMap;

        for (String checkBoxName : checkBoxesNames.keySet()) {
            if (!checkboxMap.containsKey(checkBoxName))
                throw new Exception("ERROR: the checkbox: [" + checkBoxName + "] does not exist in MakeChanges Modal, please review it");
            checkboxMap.get(checkBoxName).actionCheckBox(checkBoxesNames.get(checkBoxName));
        }
    }

    @And("I click refresh button in MakeChanges Modal")
    public void iClickRefreshButtonInMakeChangesModal() throws Exception {
        Thread.sleep(2000);
        makeChangesPage.refreshPremiumsButton.click();
        Thread.sleep(2000);
    }
}