package runner.stepsOrca.claim;

import entities.orca.MedicalRecordEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orca.claim.*;
import pages.orca.common.MenuSection;
import pages.orca.loss.LossDetails;
import runner.BaseSteps;
import java.util.*;

public class ClaimSteps extends BaseSteps {
    ClaimDashboard claimDashboard = new ClaimDashboard();
    ClaimSearch claimSearch = new ClaimSearch();
    MenuSection menuSection = new MenuSection();
    LossDetails lossDetails = new LossDetails();
    ClaimAdjusterProfile claimAdjusterProfile = new ClaimAdjusterProfile();
    RequestMedicalRecord requestMedicalRecord = new RequestMedicalRecord();

    @And("I click [{}] button")
    public void iClickStartPreppingClaimButton(String buttonName) throws Exception {
        if (!claimDashboard.buttonMap.containsKey(buttonName))
            throw new Exception("Error!! the button [" + buttonName + "] does not exist");
        claimDashboard.buttonMap.get(buttonName).click();
    }

    @And("I click on [{}] Link on Claim Dashboard")
    public void iClickOnAssignedLinkOnClaimDashboard(String linkControl) throws Exception {
        claimDashboard.linksMap.get((linkControl)).click();
    }

    @And("The Assigned table should be displayed with the columns")
    public void theAssignedTableShouldBeDisplayedWithTheColumns(List<String> expectedLabelsTable) throws Exception {
        Assertions.assertTrue(claimDashboard.assignedTable.verifyAllHeaderLabel(expectedLabelsTable),
                "Some labels in the table is missing, actual [" + claimDashboard.assignedTable.getAllHeaderLabel().toString() + " vs expected [" + expectedLabelsTable.toString() + "]");
    }






    @And("click in the first claim number in the assigned table")
    public void clickInTheFirstClaimNumberInTheAssignedTable() throws Exception {
        claimDashboard.assignedTable.clickLinkXpath(1, 1);
    }

      @And("verify the {} is displayed in Assigned table")
    public void verifyTheClaimNumberIsDisplayedInAssignedTable(String nameVariable) throws Exception {
        boolean isDisplayed = claimDashboard.assignedTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(nameVariable));
        Assertions.assertTrue(isDisplayed, "ERROR! The value [" + this.replaceConfigurationValues(nameVariable) + "] is not displayed in the Assigned table");
    }

    @And("click in the {} in the assigned table")
    public void clickInTheClaimNumberInTheAssignedTable(String nameVariable) throws Exception {
        claimDashboard.assignedTable.clickOnLinkCell(this.replaceConfigurationValues(nameVariable));
    }

    @And("Go to the last items of the Assigned table")
    public void clickOnLastItemsButtonToSeeMostRecentItems() throws Exception {
        claimDashboard.lastItemsButton.click();
    }

    @When("I search the claim: {}")
    public void iSearchTheClaimClaimNumber(String claimNumber) throws Exception {
        menuSection.optionMenu.get("Claims").click();
        subMenuSection.optionSubMenu.get("Search for a Claim").click();
        claimSearch.claimNoTxtBox.clearSetText(this.replaceConfigurationValues(claimNumber));
        claimSearch.runSearchButton.click();

    }

    @And("I click on Claim No: {} link")
    public void iClickOnClaimNoClaimNumberLink(String claimNumber) throws Exception {
        claimSearch.clickClaimResult(this.replaceConfigurationValues(claimNumber));
    }

    @And("I click on [CheckMark] on the approve Section")
    public void iClickOnCheckMarkOnTheApproveSection() throws Exception {
        lossDetails.checkMarkButton.click();
    }

    @When("I click on [{}] button on the Deny section")
    public void iClickOnButtonOnTheDenySection(String buttonName) throws Exception {
        lossDetails.denySection.get(buttonName).click();
    }

    @And("I enter {string} to denial code text box and select {string}")
    public void iEnterToDenialCodeTextBoxAndSelect(String code, String option) throws Exception {
        lossDetails.denialCodeTextBox.selectTextOption(code, option);
    }

    @And("I click on [{}] button under the claim dashboard")
    public void iClickOnButtonUnderTheClaimDashboard(String button) throws Exception {
        claimDashboard.dashBoardMap.get(button).click();
    }

    @And("I click on link cell column:{int} row:{int}  in Adjuster Table")
    public void iClickOnLinkCellColumnIntRowIntInAdjusterTable(int row, int column) throws Exception {
        claimAdjusterProfile.adjusterTable.clickLink(row, column);
    }

    @When("I select [{}] amount claim Total Submitted level dropdown")
    public void iSelectAmountClaimTotalSubmittedLevelDropdown(String value) throws Exception {
        claimAdjusterProfile.totalSubmittedLevel.selectValueContainsOption(value);
    }
    @And("I click on [{}] Button on the Adjuster Profile Page")
    public void iClickOnButtonOnTheAdjusterProfilePage(String button) throws Exception {
        if (button.contains("Save")){
            claimAdjusterProfile.saveButton.controlIsDisplayed(5);
            claimAdjusterProfile.saveButton.click();
        } else if (button.contains("Cancel")) {
            claimAdjusterProfile.cancelButton.controlIsDisplayed(5);
            claimAdjusterProfile.cancelButton.click();

        }
    }

    @And("I click {string} button on medical Record Page")
    public void iClickButtonOnMedicalRecordPage(String value) throws Exception {
        requestMedicalRecord.medicalRecordPageButton.get(value).controlIsClickable();
        requestMedicalRecord.medicalRecordPageButton.get(value).controlIsDisplayed(5);
        requestMedicalRecord.medicalRecordPageButton.get(value).click();
    }
    @DataTableType
    public MedicalRecordEntity getEntity(Map<String, String> entity) {
        MedicalRecordEntity tmpp = new MedicalRecordEntity();
        if (entity.containsKey("Request Type"))
            tmpp.setRequestTypeDropdown(entity.get("Request Type"));
        if (entity.containsKey("Pet"))
            tmpp.setPet(entity.get("Pet"));
        if (entity.containsKey("Vet"))
            tmpp.setVet(entity.get("Vet"));
        if (entity.containsKey("Request Search"))
            tmpp.setRequestSearch(entity.get("Request Search"));
        return tmpp;
    }
    @When("I fill out the application medical Record Page")
    public void iFillOutTheApplicationMedicalRecordPage(MedicalRecordEntity medicalRecordEntity) throws Exception {

        if (!medicalRecordEntity.getRequestTypeDropdown().isEmpty())
            requestMedicalRecord.requestTypeDropdown.selectValueContainsOption(this.replaceConfigurationValues(medicalRecordEntity.getRequestTypeDropdown()));
        if (!medicalRecordEntity.getPet().isEmpty())
            requestMedicalRecord.petDropdown.firstValue();
        if (!medicalRecordEntity.getVet().isEmpty())
            requestMedicalRecord.vetDropdown.firstValue();
        if (!medicalRecordEntity.getRequestSearch().isEmpty())
            requestMedicalRecord.requestSearch.setText(this.replaceConfigurationValues(medicalRecordEntity.getRequestSearch()));
        requestMedicalRecord.allMrsButton.click();
    }

    @When("I click on [Reset] icon on the medical records page")
    public void iClickOnResetIconOnTheMedicalRecordsPage() throws Exception {
        requestMedicalRecord.resetButton.controlIsDisplayed(5);
        requestMedicalRecord.resetButton.click();
    }

}