package runner.stepsOrca.vet;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orca.vet.VetDashboardPage;
import runner.BaseSteps;

import java.util.List;
import java.util.Map;

public class VetSteps extends BaseSteps {

    VetDashboardPage vetDashboardPage = new VetDashboardPage();

    @And("I have entered below FieldValue corresponding to following FieldName on Vet Dashboard page")
    public void iHaveEnteredBelowCorrespondingToFollowingOnVetDashboardPage(DataTable table) throws Exception {
        List<Map<String, String>> data = table.asMaps(String.class, String.class);
        for (Map<String, String> mData : data) {
            vetDashboardPage.fillDetailsOnVetDashboard(mData.get("FieldName"), mData.get("FieldValue"));
        }
    }

    @When("I clicks on {string} button")
    public void iClicksOnButton(String buttonName) throws Throwable {
        vetDashboardPage.buttonMap.get(buttonName).click();
    }

    @Then("all the below field should be empty")
    public void allTheBelowFieldShouldBeEmpty(List<String> fieldName) throws Throwable {
        for (String sFieldName : fieldName) {
            Assertions.assertTrue(vetDashboardPage.verifyIsFieldEmpty(sFieldName), "Error: " + sFieldName + " is not empty");
        }
    }
}