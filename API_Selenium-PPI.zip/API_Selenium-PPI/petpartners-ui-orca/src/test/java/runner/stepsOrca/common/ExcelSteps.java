package runner.stepsOrca.common;

import configuration.CommonValues;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import runner.BaseSteps;
import utils.ExcelReader;
import utils.Level;
import utils.Logger;

import java.io.File;

public class ExcelSteps extends BaseSteps {
    protected ExcelReader excelReader;
    @Then("I read the excel file {string}")
    public void readTheExcelFile(String file) {
        String path= new File("").getAbsolutePath()+"/src/test/resources/";
        excelReader= new ExcelReader(path+file);
        excelReader.readBuildMap();
    }


    @And("I save the read value from column: {string}, row: {int} on {}")
    public void iSaveTheReadValueFromColumnRowOnPetBreedValue(String columnName, int rowNumber,String variableName) throws Exception {
        String value=excelReader.getValue(this.replaceConfigurationValues(columnName),rowNumber);
        CommonValues.variables.put(variableName,value);
        Logger.log(Level.INFO,this.getClass().getName()+"> getting the value:["+value+"] and saving on "+variableName);
    }
}
