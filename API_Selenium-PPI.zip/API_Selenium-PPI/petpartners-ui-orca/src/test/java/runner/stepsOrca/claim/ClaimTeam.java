package runner.stepsOrca.claim;

import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import pages.orca.claim.ClaimTeamInbox;
import runner.BaseSteps;

import java.util.List;

public class ClaimTeam extends BaseSteps {
    ClaimTeamInbox claimTeamInbox= new ClaimTeamInbox();
    @Then("verify the received date claim count table should display")
    public void verifyTheReceivedDateClaimCountTableShouldDisplay(List<String> expectedLabelTable) throws Exception {
        String actualResult=claimTeamInbox.receivedDateClaimLabel.getText();
        Assertions.assertEquals("Received Date Claim Counts",actualResult,"ERROR the label is wrong");
        Boolean areDisplayedLabel= claimTeamInbox.receivedDateClaimTable.verifyAllHeaderLabel(expectedLabelTable);
        Assertions.assertTrue(areDisplayedLabel,"The labels in the table are not correct, expected: "+
                expectedLabelTable.toString()+" vs actual: "+claimTeamInbox.receivedDateClaimTable.getAllHeaderLabel().toString());

    }
}
