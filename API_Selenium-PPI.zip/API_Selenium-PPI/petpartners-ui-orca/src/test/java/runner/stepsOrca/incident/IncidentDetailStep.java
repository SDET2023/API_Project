package runner.stepsOrca.incident;

import io.cucumber.java.en.And;
import org.junit.jupiter.api.Assertions;
import pages.orca.loss.IncidentDetailPage;
import runner.BaseSteps;

import java.util.List;

public class IncidentDetailStep extends BaseSteps {
    IncidentDetailPage incidentDetailPage = new IncidentDetailPage();

    @And("I verify the next control are displayed on Incident Detail Page")
    public void iVerifyTheNextControlAreDisplayedOnIncidentDetailPage(List<String> controlList) {
        for (String control: controlList) {
            Assertions.assertTrue(incidentDetailPage.allControls.get(control).controlIsDisplayed(),"ERROR> the control ["+control+"] is not displayed on  Incident Detail Page");
        }
    }

    @And("hover the mouse on {string} on Incident Detail Page")
    public void hoverTheMouseOnOnIncidentDetailPage(String control) throws Exception {
        incidentDetailPage.allControls.get(control).hoverMouse();
    }

    @And("verify the tooltip displayed should be")
    public void verifyTheTooltipDisplayedShouldBe(String expectedResult) throws Exception {
        incidentDetailPage.dateOfEligibilityToolTip.controlIsDisplayed();
        String actualResult = incidentDetailPage.dateOfEligibilityToolTip.getText();
        Assertions.assertEquals(expectedResult,actualResult,"ERROR! the tooltip message are different");
    }
}
