package runner.stepsOrca.admin;

import configuration.CommonValues;
import control.Select;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import pages.orca.admin.productManagement.AddNewFilingPage;
import pages.orca.admin.productManagement.FilingDetailPage;
import pages.orca.admin.productManagement.FilingPage;
import runner.BaseSteps;
import utils.Level;
import utils.Logger;

import java.util.List;
import java.util.Map;

public class AddNewFilingSteps extends BaseSteps {
    AddNewFilingPage addNewFilingPage = new AddNewFilingPage();
    FilingPage filingPage = new FilingPage();
    FilingDetailPage filingDetailPage = new FilingDetailPage();

    @And("Get all values from Target Version drop down in Add New Filing page on {}")
    public void getAllValuesFromTargetVersionDropDownInAddNewFilingPageOnUIValues(String variableName) throws Exception {
        CommonValues.variables.put(variableName,String.valueOf(addNewFilingPage.stateFilingInformationSection.targetVersionDropDown.getAllValuesCommaSeparated()).replace("Select Target Version ...,",""));
        Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(variableName)+"] in ["+variableName+"]");
    }

    @Then("compare expected and actual values")
    public void compareUITargetVersionValuesAndDBDisplayValues(Map<String, String> valuesToCompare) {
        Assertions.assertTrue(this.replaceConfigurationValues(valuesToCompare.get("expected")).contains(this.replaceConfigurationValues(valuesToCompare.get("actual"))),
                "ERROR! the values are different, expected: [" + this.replaceConfigurationValues(valuesToCompare.get("expected")) + "] vs actual: [" + this.replaceConfigurationValues(valuesToCompare.get("actual"))+"]");
    }

    @And("I select {string} in [Select Product Package] DropDown in Choose Product - Add New Filing")
    public void iSelectInSelectProductPackageDropDownInChooseProductAddNewFiling(String value) throws Exception {
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(15);
        addNewFilingPage.chooseProductSection.selectProductPackageSelect.selectValueWithJavaScriptOptionSpan(this.replaceConfigurationValues(value));
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(15);
    }

    @And("I select {string} in [{}] DropDown in Set Rates - Add New Filing")
    public void iSelectInSelectRatingSpreadsheetDropDownInSetRatesAddNewFiling(String value,String control) throws Exception {
        if (!addNewFilingPage.setRatesSection.mapSelectControl.containsKey(control))
            throw new Exception("ERROR!! the select control: ["+control+"] is not added in the map, please review the map");
        if (value.contains("Any Value")) {
            this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(8);
            addNewFilingPage.setRatesSection.mapSelectControl.get(control).firstValue();
        }
        else
            addNewFilingPage.setRatesSection.mapSelectControl.get(control).selectValueContainsOption(this.replaceConfigurationValues(value));
    }

    @And("I select {string} in [State Type] DropDown in Select Documents - Add New Filing")
    public void iSelectInStateTypeDropDownInSelectDocumentsAddNewFiling(String value) throws Exception {
        addNewFilingPage.selectDocumentsSection.stateTypeSelect.selectValueContainsOption(this.replaceConfigurationValues(value));

    }

    @Then("I verify the {string} is displayed in Select Document Table - Add New Filing")
    public void iVerifyTheIsDisplayedInSelectDocumentTableAddNewFiling(String expectedResult) throws Exception {
        boolean isDisplayed=addNewFilingPage.selectDocumentsSection.resultStateTypeTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(expectedResult));
        Assertions.assertTrue(isDisplayed,"ERROR!  the value: ["+this.replaceConfigurationValues(expectedResult)+"] is not displayed in Select Document table, please see screenshot");
    }

    @Then("I verify the {string} section is displayed on Add New Filing page")
    public void iVerifyTheSectionIsDisplayedOnAddNewFiling(String expectedResult) throws Exception {
        boolean isDisplayed=addNewFilingPage.selectDocumentsSection.sectionDocumentLabel.getText().contains(this.replaceConfigurationValues(expectedResult));
        Assertions.assertTrue(isDisplayed,"ERROR!  the value: ["+this.replaceConfigurationValues(expectedResult)+"] is not displayed on Select Document section, please see screenshot");
    }

    @When("I click on {string} button on Select Documents - Add New Filing")
    public void iClickOnButtonOnSelectDocumentsAddNewFiling(String buttonName) throws Exception {
        addNewFilingPage.selectDocumentsSection.previousButton.click();
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(15);
    }

    @Then("I verify the its navigated back to {string} section")
    public void iVerifyTheItsNavigatedBackToSection(String expectedResult) throws Exception {
        boolean isDisplayed=addNewFilingPage.setRatesSection.setRateLabel.getText().contains(this.replaceConfigurationValues(expectedResult));
        Assertions.assertTrue(isDisplayed,"ERROR!  the value: ["+this.replaceConfigurationValues(expectedResult)+"] is not displayed on Set Rates section, please see screenshot");
    }

    @Then("I verify the below added filing wizard is displayed under Summary on Select Documents - Add New Filing")
    public void iVerifyTheBelowAddedFilingWizardIsDisplayedUnderSummaryOnSelectDocumentsAddNewFiling(List<String> fieldName) throws Exception {
        Assertions.assertTrue(addNewFilingPage.selectDocumentsSection.summaryLabel.controlIsDisplayed(),"ERROR!  the value: ["+addNewFilingPage.selectDocumentsSection.summaryLabel.getText()+"] is not displayed on Select Document section, please see screenshot");
        for (String sFieldName : fieldName) {
            if ( sFieldName.equals("State Filing Information"))
                Assertions.assertTrue( addNewFilingPage.selectDocumentsSection.labelMap.get(sFieldName).controlIsDisplayed(),"Error: "+sFieldName+" is not displayed under Summery header, please see screenshot");
            else
                Assertions.assertTrue( addNewFilingPage.selectDocumentsSection.buttonMap.get(sFieldName).controlIsDisplayed() ,"Error: "+sFieldName+" is not displayed under Summery header, please see screenshot");
        }
    }

    @When("I click on Complete button on Select Documents - Add New Filing")
    public void iClickOnCompleteButtonOnSelectDocumentsAddNewFiling() throws Exception {
        addNewFilingPage.selectDocumentsSection.completeButton.click();
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(15);
    }

    @Then("I verify the {string} section is displayed on wizard")
    public void iVerifyTheSectionIsDisplayedOnWizard(String expectedResult) throws Exception {
        boolean isDisplayed=addNewFilingPage.summaryReviewSection.summaryReviewLabel.getText().contains(this.replaceConfigurationValues(expectedResult));
        Assertions.assertTrue(isDisplayed,"ERROR!  the value: ["+this.replaceConfigurationValues(expectedResult)+"] label is not displayed on Summary Review section, please see screenshot");
        CommonValues.variables.put("State Filing ID",this.replaceConfigurationValues(addNewFilingPage.summaryReviewSection.iDLabel.getText().trim()));
    }

    @When("I click on {string} button on Summary Review - Add New Filing")
    public void iClickOnButtonOnSummaryReviewAddNewFiling(String buttonName) throws Exception {
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(15);
        if(buttonName.contains("Exit")) {
            addNewFilingPage.summaryReviewSection.exitButton.click();
        } else if (buttonName.contains("Submit")) {
            addNewFilingPage.summaryReviewSection.submitButton.click();
            addNewFilingPage.summaryReviewSection.stateFilingSubmittedLabel.controlIsDisplayed(10);
            addNewFilingPage.summaryReviewSection.takeMeBackToListingButton.click();
        }else if (buttonName.contains("Approve")) {
            addNewFilingPage.summaryReviewSection.approveButton.click();
        }
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(10);
    }

    @When("I click on {string} button on Exit Filing popup")
    public void iClickOnButtonOnExitFilingPopup(String buttonName) throws Exception {
        Assertions.assertTrue( addNewFilingPage.summaryReviewSection.exitFilingLabel.controlIsDisplayed(),"Error: "+ addNewFilingPage.summaryReviewSection.exitFilingLabel.getText()+" is not displayed on popup, please see screenshot");
        addNewFilingPage.summaryReviewSection.yesWantToExitButton.click();
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(15);
    }

    @Then("I navigated to {string} page")
    public void iNavigatedToPage(String expectedResult) throws Exception {
        boolean isDisplayed= this.filingPage.filingsLabel.getText().contains(this.replaceConfigurationValues(expectedResult));
        Assertions.assertTrue(isDisplayed,"ERROR!  the value: ["+this.replaceConfigurationValues(expectedResult)+"] label is not displayed on Filings page, please see screenshot");
    }

    @Then("I verify the filing is saved as {string} status")
    public void iVerifyTheFilingIsSavedAsStatus(String expectedResult) throws Exception {
        this.filingPage.stateFilingIdTextbox.clearSetText(CommonValues.variables.get("State Filing ID"));
        this.filingPage.searchButton.click();
        Assertions.assertTrue(filingPage.rowsInFilingTable.controlIsDisplayed(10));
        boolean isDisplayed= this.filingPage.statusLabel.getText().contains(this.replaceConfigurationValues(expectedResult));
        Assertions.assertTrue(isDisplayed,"ERROR!  the value: ["+this.replaceConfigurationValues(expectedResult)+"] Status is not displayed under Filings table page, please see screenshot");
    }

    @Then("I update the next checkboxes - [{}] in Choose Section Modal")
    public void iUpdateTheNextCheckboxesCompanionCareInChooseSectionModal(String section, Map<String,String>data) throws Exception {

        for (String nameCheckBox:data.keySet()) {
            this.addNewFilingPage.chooseProductSection.updateCheckBox(section, nameCheckBox,  data.get(nameCheckBox) );
        }
    }


    @Then("I verify the next checkboxes - [{}] in Choose Section Modal is unchecked")
    public void iVerifyTheNextCheckboxesCompanionCareChooseSectionModalIsUnchecked(String section, Map<String,String>data) throws Exception{

        Assertions.assertTrue(this.addNewFilingPage.chooseProductSection.verifyCheckBoxIsChecked(section,data), "I verify the next checkboxes - ["+ data +"] in Choose Section Modal is unchecked");
    }

   @And("I select below Template Override dropdown value against {string} Template Name on Select Documents - Add New Filing")
    public void iSelectTemplateOverrideDropdownValueAgainstTemplateName(String value,List<String> templateName) throws Exception{
       for (String sTemplateName : templateName) {
           addNewFilingPage.selectDocumentsSection.resultStateTypeTable.selectDropdownValueIfValueIsDisplayedInTable(value,sTemplateName);
       }
    }

    @And("I click on the State Filing ID on Filing page")
    public void iClickOnStateFilingIDOnFilingPage() throws Exception {
            filingPage.stateFilingIDLink.click();
      }

    @And("I verify the below buttons is displayed on the Summary Review - Add New Filing")
    public void iVerifyButtonIsDisplayedSummaryReviewPage(List<String> buttonName) throws Exception{
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(30);
        addNewFilingPage.summaryReviewSection.summaryReviewLabel.controlIsDisplayed(10);
        scrollDownTillPageEnd();
        for (String sButtonName : buttonName) {
            if(addNewFilingPage.summaryReviewSection.approveButton.getText().contains(sButtonName)) {
                addNewFilingPage.summaryReviewSection.approveButton.controlIsDisplayed(5);
                Assertions.assertTrue(addNewFilingPage.summaryReviewSection.approveButton.controlIsDisplayed(2), "ERROR! button: [" + sButtonName + "] is not displayed on Summary Review - Add New Filing page");
            }else if(addNewFilingPage.summaryReviewSection.denyButton.getText().contains(sButtonName)) {
                Assertions.assertTrue(addNewFilingPage.summaryReviewSection.denyButton.controlIsDisplayed(2), "ERROR! button: [" + sButtonName + "] is not displayed on Summary Review - Add New Filing page");
            }
        }
    }
    @And("I click on {string} button on Overview - State Filing Detail page")
    public void iClickOnButtonOnStateFilingDetailPage(String buttonName) throws Exception {
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(10);
        filingDetailPage.overviewLabel.controlIsDisplayed(5);
        if(buttonName.contains("Edit")) {
            filingDetailPage.editIcon.click();
        }else if(buttonName.contains("Save")) {
            filingDetailPage.saveButton.click();
        }
    }

    @And("I click on {string} checkbox on Overview - State Filing Detail page")
    public void iClickOnCheckboxOnStateFilingDetailPage(String checkboxName) throws Exception {
        if(checkboxName.contains("Active"))
            filingDetailPage.activeCheckbox.click();
    }

    @Then("I verify the {string} popup is displayed with below table column")
    public void iVerifyPopUpIsDisplayedWithTableColumn(String value,List<String> expectedResult) throws Exception {
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(40);
        filingDetailPage.activateFilingConfirmationLabel.controlIsDisplayed(5);
        Assertions.assertTrue(filingDetailPage.warningLabel.controlIsDisplayed(),"ERROR the Warning Message: ["+filingDetailPage.warningLabel.getText()+"] is not displayed");
        Assertions.assertTrue(filingDetailPage.activateFilingConfirmationTable.verifyAllHeaderLabel(expectedResult),
                "Some labels in the table are missing, actual [" + filingDetailPage.activateFilingConfirmationTable.getAllHeaderLabel().toString() + " vs expected [" + expectedResult.toString() + "]");
    }

    @And("I click on {string} button on Activate Filing Confirmation popup")
    public void iClickOnButtonOnActivateFilingConfirmationPopup(String buttonName) throws Exception {
        if(buttonName.contains("Proceed and Deactivate")) {
            filingDetailPage.proceedNDeactivateButton.click();
            filingDetailPage.overviewLabel.controlIsDisplayed(15);
        }
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(20);
    }

    @And("I verify State Filing is active with the {string} checkbox is checked")
    public void iVerifyStateFilingIsActiveWithCheckboxIsChecked(String checkboxName) throws Exception {
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(20);
        this.filingPage.stateFilingIdTextbox.clearSetText(CommonValues.variables.get("State Filing ID"));
        this.filingPage.searchButton.click();
        Assertions.assertTrue(filingPage.rowsInFilingTable.controlIsDisplayed(5));
        Assertions.assertTrue(filingPage.activeCheckbox.getTextAttribute("class").contains("check"),"ERROR!  the checkbox: ["+checkboxName+"] is not checked and State Filings is not active, please see screenshot");
    }

    @Then("Verify {string} displaying in UnderWriter dropdown")
    public void verifyTextDisplayingInUnderWriterDropdown(String sExpected) throws Exception {
        String sIndex = addNewFilingPage.selectUnderwriter.getTextAttribute("value");
        Select selectUnderwriterOption = new Select(By.xpath(addNewFilingPage.selectUnderwriter.getLocatorXpathString() + "/option[@value='" + sIndex + "']"));
        Assertions.assertTrue(selectUnderwriterOption.getText().equals(sExpected),
               "Error: "+sExpected+" is not displayed");
    }
}