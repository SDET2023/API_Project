package runner.stepsOrca.policy;

import configuration.CommonValues;
import control.Label;
import entities.orca.policy.PolicySearchEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import pages.orca.policy.PolicyDetailsPage;
import pages.orca.policy.PolicySearchSection;
import runner.BaseSteps;
import utils.Level;
import utils.Logger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class PolicySearchSteps extends BaseSteps {
    PolicyDetailsPage policyDetailsPage = new PolicyDetailsPage();
    PolicySearchSection policySearchSection = new PolicySearchSection();
    @And("I search Policy with the next value")
    public void iSearchPolicyWithTheNextValue(PolicySearchEntity policySearchEntity) throws Exception {
        policySearchSection.clearButton.click();
        policySearchSection.searchPolicySection(policySearchEntity);
    }

    @And("verify the value {string} is displayed in the result search")
    public void verifyTheValueIsDisplayedInTheResultSearch(String expectedResult) throws Exception {
        Assertions.assertTrue(policySearchSection.searchResultTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(expectedResult)),
                "ERROR! the value : [" + this.replaceConfigurationValues(expectedResult) + "] is not displayed in the policy search result section");
    }

    @And("click on {string} in the result search")
    public void clickOnInTheResultSearch(String value) throws Exception {
        policySearchSection.searchResultTable.clickOnLinkCellContains(this.replaceConfigurationValues(value));
    }

    @And("I click Show Pets button in the first result of the search")
    public void showPetsNameResult() throws Exception {
        policySearchSection.showPetsResultButton.click();
    }

    @Then("I verify Pet name result matches the pet name searched")
    public void verifyPetsNameResultMatchesSearch(String name) throws Exception {
        Label petNameResult = policySearchSection.setPetNameResultLabel(this.replaceConfigurationValues(name));
        Assertions.assertTrue(petNameResult.getText().contains(this.replaceConfigurationValues(name)), "ERROR> Pet name searched does not match the result one");
    }

    @And("I search the policy with {string} alternate phone number")
    public void iSearchThePolicyWithAlternatePhoneNumber(String number) throws Exception {
        policySearchSection.phoneNumberTextBox.setText(number);
    }

    @And("I click on {string} button on the policy dashboard")
    public void iClickOnButtonOnThePolicyDashboard(String button) throws Exception {
        if (button.contains("Run search")) {
            policySearchSection.runSearchButton.click();
        } else if (button.contains("Clear")) {
            policySearchSection.clearButton.click();
        }
    }

    @And("^I save the Amount of Pets displayed on (Policy|Search Result) in (.*)$")
    public void iSaveTheAmountOfPetsIn(String displayedPlace, String nameVariable) throws Exception {
        switch (displayedPlace.toLowerCase()) {
            case "policy":
                CommonValues.variables.put(nameVariable, String.valueOf(policyDetailsPage.petsTable.getRowCount()));
                Logger.log(Level.INFO, this.getClass().getName() + " save the variable [" + nameVariable + "] value: " + CommonValues.variables.get(nameVariable));
                break;
            case "search result":
                CommonValues.variables.put(nameVariable, policySearchSection.petsResult.getTextAttribute("childElementCount"));
                Logger.log(Level.INFO, this.getClass().getName() + " save the variable [" + nameVariable + "] value: " + CommonValues.variables.get(nameVariable));
                break;
        }

    }


    @And("I search on Policy Search Page using")
    public void searchingOnPolicySearchPageUsing(Map<String, String> controlsValue) throws Exception {
        for (String control : controlsValue.keySet()
        ) {
            if (!policySearchSection.textBoxMap.containsKey(control))
                throw new Exception("The control: " + control + " is not present. There is no field related.");
            policySearchSection.textBoxMap.get(control).setText(this.replaceConfigurationValues(controlsValue.get(control)));
        }
        policySearchSection.runSearchButton.controlIsClickable();
        policySearchSection.runSearchButton.click();
    }



    @And("I verify all Pet\\(s) Names in: {} are displayed")
    public void iVerifyAllPetSNamesInAreDisplayed(String variableName) {
        String petsNamesArray = CommonValues.variables.get(variableName).substring(1, CommonValues.variables.get(variableName).length() - 1);
        String[] elements = petsNamesArray.split(",");
        List<String> petNames = new ArrayList<>();
        petNames.addAll(Arrays.asList(elements));
        for (String petName : petNames) {
            Assertions.assertTrue(policySearchSection.setPetNameResultLabel(petName).controlIsDisplayed(), "ERROR> Pet:" + petName + " is not dispayed.");
        }
    }

    @DataTableType
    public PolicySearchEntity getEntity(Map<String, String> entity) {

        for (Map.Entry<String, String> entry : entity.entrySet()) {
            if (entry.getValue() == null) {
                entry.setValue("");
            }
        }
        PolicySearchEntity tmp = new PolicySearchEntity();

        if (entity.containsKey("Market Channel"))
            tmp.setMarketChannel(this.replaceConfigurationValues(entity.get("Market Channel")));

        if (entity.containsKey("Policy No"))
            tmp.setPolicyNumber(this.replaceConfigurationValues(entity.get("Policy No")));

        if (entity.containsKey("Postal Code"))
            tmp.setPostalCode(this.replaceConfigurationValues(entity.get("Postal Code")));

        if (entity.containsKey("Last Name"))
            tmp.setLastName(this.replaceConfigurationValues(entity.get("Last Name")));

        if (entity.containsKey("Email address"))
            tmp.setEmailAddress(this.replaceConfigurationValues(entity.get("Email address")));

        if (entity.containsKey("Phone No"))
            tmp.setPhoneNum(this.replaceConfigurationValues(entity.get("Phone No")));

        if (entity.containsKey("Billing Id"))
            tmp.setBillingId(this.replaceConfigurationValues(entity.get("Billing Id")));

        if (entity.containsKey("Registration No"))
            tmp.setRegistrationNumber(this.replaceConfigurationValues(entity.get("Registration No")));

        if (entity.containsKey("Linked Policy"))
            tmp.setLinkedPolicy(this.replaceConfigurationValues(entity.get("Linked Policy")));

        if (entity.containsKey("Pet Name"))
            tmp.setPetName(this.replaceConfigurationValues(entity.get("Pet Name")));

        return tmp;

    }

}
