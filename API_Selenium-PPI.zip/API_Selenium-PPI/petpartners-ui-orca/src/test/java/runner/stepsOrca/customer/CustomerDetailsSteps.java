package runner.stepsOrca.customer;



import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orca.customer.CustomerDetailsPage;
import runner.BaseSteps;
import utils.Logger;
import utils.Level;

import java.util.Map;


public class CustomerDetailsSteps extends BaseSteps {
    CustomerDetailsPage customerDetailsPage = new CustomerDetailsPage();

    @And("modify customer firstname on customer details page")
    public void modifyCustomerFirstnameOnCustomerDetailsPage() throws Exception {
        customerDetailsPage.firstNameTextBox.clearSetText("automation Test");
    }

    @And("click on [save] button on customer details Page")
    public void clickOnSaveButtonOnCustomerDetailsPage() throws Exception {
        customerDetailsPage.saveButton.click();
    }

    @When("click on [Note\\(s)] tab on customer detail page")
    public void clickOnNoteSTabOnCustomerDetailPage() throws Exception {
        customerDetailsPage.notesLink.click();
    }

    @Then("verify modified Customer Name {string} in customer detail page")
    public void verifyModifiedCustomerNameInCustomerDetailPage(String expectedResult) throws Exception {
        String sText = "FirstName: changed from " + this.replaceConfigurationValues(expectedResult) + " to " +
                this.replaceConfigurationValues(expectedResult) + " Test";
        Assertions.assertTrue(customerDetailsPage.notesTab.getText().contains(sText),
                "ERROR!  the value: [" + this.replaceConfigurationValues(sText) + "] is not displayed in Notes tab");
    }

    @And("enter {string} in Alternate phone number text box on Customer Details Page")
    public void enterInAlternatePhoneNumberTextBoxOnCustomerDetailsPage(String altPhone) throws Exception {
        customerDetailsPage.altPhoneNumberTextBox.controlIsClickable();
        customerDetailsPage.altPhoneNumberTextBox.click();
        customerDetailsPage.altPhoneNumberTextBox.setText(altPhone);

    }

    @Then("verify Alternate phone number {string} in customer detail page")
    public void verifyAlternatePhoneNumberInCustomerDetailPage(String alternatePhone) throws Exception {
        Assertions.assertTrue(customerDetailsPage.notesTab.getText().contains(alternatePhone), "ERROR!  the value: [" + this.replaceConfigurationValues(alternatePhone) + "] is not displayed in Notes tab");
    }

    @And("enter {string} in Phone number text box on Customer Details Page")
    public void enterInPhoneNumberTextBoxOnCustomerDetailsPage(String phoneNumber) throws Exception {
        customerDetailsPage.phoneNumberTextBox.setText(phoneNumber);
    }

    @And("I click on [Add New] button on customers tab")
    public void iClickOnAddNewButtonOnCustomersTab() throws Exception {
        customerDetailsPage.addNewCustomersButton.click();
    }

    @And("I click on [Create a New Customer] button on the Customer Search popup")
    public void iClickOnCreateANewCustomerButtonOnTheCustomerSearchPopup() throws Exception {
        customerDetailsPage.createANewCustomerButton.click();
    }

    @And("I click on [Same address as primary] check box on Customer Details popup")
    public void iClickOnSameAddressAsPrimaryCheckBoxOnCustomerDetailsPopup() throws Exception {
        customerDetailsPage.sameAddressAsPrimaryCheckBox.click();
    }

    @Then("I verify the below field values on Customer Details popup are auto populated")
    public void iVerifyTheBelowFieldValuesOnCustomerDetailsPopupAreAutoPopulated(Map<String, String> expectedValues) throws Exception {
        for (String controlName : expectedValues.keySet()) {
            String actualResult = customerDetailsPage.textBoxMap.get(controlName).getTextAttribute("value");
            String expectedResult = this.replaceConfigurationValues(expectedValues.get(controlName));
            Logger.log(Level.INFO, this.getClass().getName() + "Assert> the actual[" + actualResult + "] vs expected [" + expectedResult + "] in the control: " + controlName + this.getClass().getSimpleName());
            Assertions.assertEquals(expectedResult, actualResult, "ERROR! the actual[" + actualResult + "] vs expected [" + expectedResult + "] are not equal in the control: " + controlName);
        }

    }

}



