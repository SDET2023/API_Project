package runner.stepsOrca.admin;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import pages.orca.admin.claims.ProcedureCodePage;
import runner.BaseSteps;

public class ClaimProcessingSteps extends BaseSteps {
    ProcedureCodePage procedureCodePage = new ProcedureCodePage();

    @And("click on Create New Procedure Code button available on Claims Processing page")
    public void clickonCreateNewProcedureCodebuttonavailableonClaimsProcessingpage() throws Exception {
        procedureCodePage.createNewProcedureCodeButton.click();
    }

    @And("click on Denial Code Creation button available on Claims Processing page")
    public void clickonDenialCodeCreationbuttonavailableonClaimsProcessingpage() throws Exception {
        procedureCodePage.denialCodeCreationButton.click();
    }

    @And("click the row [{int}] Edit button in procedureCodeTable")
    public void clickTheRowButtonInEditColumnProcedureCodeTableEditSection(int positionRow) throws Exception {
        int positionColumn = procedureCodePage.procedureCodeTable.getPositionColumn("Actions");
        procedureCodePage.procedureCodeTable.clickButton(positionColumn, positionRow);
    }

    @And("I verify that the tab name is Version History on Procedure Detail Page")
    public void iVerifyThatTheTabNameIsVersionHistoryOnProcedureDetailPage(String expectedtabname) throws Exception {
        String actualtabname = procedureCodePage.statusHistoryLink.getText();
        expectedtabname = this.replaceConfigurationValues(expectedtabname);
        Assertions.assertTrue(actualtabname.contains(expectedtabname),
                "Wrong denial reason, actual: [" + actualtabname + "] vs expected: [" + expectedtabname + "]");
    }

    @And("I click on Searchbar and enter denial code.")
    public void iClickOnSearchbarAndEnterDenialCode(String denial) throws Exception {
        procedureCodePage.searchBarTextBox.click();
        procedureCodePage.searchBarTextBox.setText(denial);

    }

    @Then("I verify that the denial code is available under Code with details")
    public void iVerifyThatTheDenialCodeIsAvailableUnderCodeWithDetails(String expectedvalue) throws Exception {
        String actualvalue = procedureCodePage.denialCodeTable.getText();
        expectedvalue = this.replaceConfigurationValues(expectedvalue);
        Assertions.assertTrue(actualvalue.contains(expectedvalue),
                "Wrong denial reason, actual: [" + actualvalue + "] vs expected: [" + expectedvalue + "]");
    }
}
