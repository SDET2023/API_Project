package runner.stepsOrca.common;

import io.cucumber.java.en.And;
import pages.orca.quote.dialog.CancelCoverageDialog;
import runner.BaseSteps;

import java.util.Map;

public class CancelCoverageStep extends BaseSteps {

    CancelCoverageDialog cancelCoverageDialog = new CancelCoverageDialog();

    @And("fill the CANCEL COVERAGE dialog with the next values:")
    public void fillTheCANCELCOVERAGEDialogWithTheNextValues(Map<String, String> data) throws Exception {
        Thread.sleep(2000);
        if (data.containsKey("Requested On")) {
            cancelCoverageDialog.requestOnTextBox.controlIsDisplayed(5);
            cancelCoverageDialog.requestOnTextBox.setTextAndTab(this.replaceConfigurationValues(data.get("Requested On")));
        }
        if (data.containsKey("Cancel Reason"))
            cancelCoverageDialog.cancelReasonSelect.selectValue(this.replaceConfigurationValues(data.get("Cancel Reason")));
        if (data.containsKey("Cancel Type"))
            cancelCoverageDialog.cancelTypeSelect.selectValue(this.replaceConfigurationValues(data.get("Cancel Type")));
        if (data.containsKey("Notes"))
            cancelCoverageDialog.notesTextBox.setText(this.replaceConfigurationValues(data.get("Notes")));
        cancelCoverageDialog.saveButton.click();
    }
}
