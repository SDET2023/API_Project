package runner.stepsOrca.common;
import io.cucumber.java.en.When;
import runner.BaseSteps;

public class MenuSteps extends BaseSteps {

    @When("I click on the [{}] tab in the menu")
    public void iClickOnTheClaimsTabInTheMenu(String menuOption) throws Exception {
        if (!menuSection.optionMenu.containsKey(menuOption))
            throw new Exception("Error!! the option ["+menuOption+"] does not exist in the menu");
        menuSection.optionMenu.get(menuOption).click();
    }
}
