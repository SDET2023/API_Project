package runner.stepsOrca.mclead;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orca.mclead.McleadSearchPage;
import runner.BaseSteps;

import java.util.Map;

public class McleadSearchSteps extends BaseSteps {

    McleadSearchPage mcleadSearchPage = new McleadSearchPage();

    @And("^Searching by (Pet Detail|Customer Details) on Mclead search page using$")
    public void searchingByPetDetailOnMcleadSearchPageUsing(String search,Map<String, String> controlsValue) throws Exception {

        if (controlsValue.containsKey("Market Channel"))
            mcleadSearchPage.marketChannelSelect.selectValue(this.replaceConfigurationValues(controlsValue.get("Market Channel")));

        if (search.equals("Pet Detail")){
            mcleadSearchPage.petDetailsTab.click();
            mcleadSearchPage.registrationNoTextBox.setText(this.replaceConfigurationValues(controlsValue.get("Registration No")));
        } else {
            mcleadSearchPage.customerDetailsTab.click();
            if (controlsValue.containsKey("Last Name"))
                mcleadSearchPage.lastNameTextBox.setText(this.replaceConfigurationValues(controlsValue.get("Last Name")));
            if (controlsValue.containsKey("Email Address"))
                mcleadSearchPage.emailAddressTextBox.setText(this.replaceConfigurationValues(controlsValue.get("Email Address")));
            if (controlsValue.containsKey("Phone Number"))
                mcleadSearchPage.phoneNumberTextbox.setText(this.replaceConfigurationValues(controlsValue.get("Phone Number")));
            if (controlsValue.containsKey("Location"))
                mcleadSearchPage.locationTextBox.setText(this.replaceConfigurationValues(controlsValue.get("Location")));
        }
        mcleadSearchPage.runSearchButton.controlIsClickable();
        mcleadSearchPage.runSearchButton.click();
    }

    @Then("Verify the search result table display")
    public void verifyTheSearchResultTableDisplay(String expectedResult) throws Exception {
        Assertions.assertTrue( mcleadSearchPage.searchResultTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(expectedResult)),
                "ERROR!  the value ["+this.replaceConfigurationValues(expectedResult)+"] is not displayed in the search result table");
    }

    @And("I click on {string} button on the Mclead details page")
    public void iClickOnButtonOnTheMcleadDetailsPage(String value) throws Exception {

        mcleadSearchPage.mcleadDetailsMap.get(value).click();
        }

    @When("I Enter {string} to note section")
    public void iEnterToNoteSection(String value) throws Exception {
        mcleadSearchPage.noteTextBox.setText(this.replaceConfigurationValues(value));
    }

   @Then("I verify {string} on the Mclead details page")
    public void iVerifyOnTheMcleadDetailsPage(String expectedResult) throws Exception {

       Assertions.assertTrue(mcleadSearchPage.searchTable.getText().contains(this.replaceConfigurationValues(expectedResult)),"ERROR! the value : [" + this.replaceConfigurationValues(expectedResult) + "] is not displayed in the notes search table");



    }
    @Then("I verify the McLead Registration {string} is displayed on search's results table")
    public void iVerifyTheMcLeadRegistrationIsDisplayedOnSearchSResultsTable(String mcleadRegNumber) {
        Assertions.assertTrue(mcleadSearchPage.getMcLeadResultLink(this.replaceConfigurationValues(mcleadRegNumber)).controlIsDisplayed(),
                "ERROR> McLead Registration: "+this.replaceConfigurationValues(mcleadRegNumber)+" is not displayed in search results");
    }
}

