package runner.stepsOrca.policy;

import configuration.CommonValues;

import entities.orca.IncidentEntity;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

import org.junit.jupiter.api.Assertions;
import pages.orca.loss.AddNewVetModal;
import pages.orca.loss.LossDetails;
import pages.orca.loss.VetSearchModal;
import pages.orca.vet.VetDetailsPage;
import runner.BaseSteps;

import java.text.SimpleDateFormat;
import java.util.*;

public class LossSteps extends BaseSteps {

    LossDetails lossDetails = new LossDetails();
    AddNewVetModal addNewVetModal = new AddNewVetModal();
    VetSearchModal vetSearchModal = new VetSearchModal();
    VetDetailsPage vetDetailsPage = new VetDetailsPage();


    @And("fill the Overview in Loss Detail section")
    public void fillTheOverviewInLossDetailSection(Map<String, String> overViewDetailValues) throws Exception {

        if (overViewDetailValues.containsKey("Date of Service")) {
            Thread.sleep(2000);
            lossDetails.dateOfServiceTextBox.click();
            lossDetails.dateOfServiceTextBox.setTextAndTab(this.replaceConfigurationValues(overViewDetailValues.get("Date of Service")));
        }
        if (overViewDetailValues.containsKey("Pet")) {
            if (this.replaceConfigurationValues(overViewDetailValues.get("Pet")).equals("FIRST_VALUE")) {
                lossDetails.petSelect.firstValue();
            } else {
                lossDetails.petSelect.selectValue(this.replaceConfigurationValues(overViewDetailValues.get("Pet")));
            }

        }
        if (overViewDetailValues.containsKey("Vet")) {
            if (this.replaceConfigurationValues(overViewDetailValues.get("Vet")).equals("FIRST_VALUE")) {
                lossDetails.vetSelect.firstValue();
            } else {
                lossDetails.vetSelect.selectValue(this.replaceConfigurationValues(overViewDetailValues.get("Vet")));
            }
        }

    }

    @And("fill the Approved section")
    public void fillTheApprovedSection(Map<String, String> approvedSetionValues) throws Exception {
        for (String key : approvedSetionValues.keySet()) {
            if (lossDetails.approvedTableCell.containsKey(key) && lossDetails.approvedTableCell.get(key).getTypeCell().equals("input")) {
                if (key.equals("Procedure")) {
                    lossDetails.approvedTable.setTextSelect(lossDetails.approvedTableCell.get(key).getPosition(), 1, this.replaceConfigurationValues(approvedSetionValues.get(key)).split(" ")[0], this.replaceConfigurationValues(approvedSetionValues.get(key)));
                } else {
                    lossDetails.approvedTable.setText(lossDetails.approvedTableCell.get(key).getPosition(), 1, this.replaceConfigurationValues(approvedSetionValues.get(key)));
                }
            } else if (lossDetails.approvedTableCell.containsKey(key) && lossDetails.approvedTableCell.get(key).getTypeCell().equals("select")) {
                lossDetails.approvedTable.select(lossDetails.approvedTableCell.get(key).getPosition(), 1, this.replaceConfigurationValues(approvedSetionValues.get(key)));
            }
        }
    }

    @And("fill procedure in the Approved section")
    public void fillProcedureInTheApprovedSection(Map<String, String> approvedSetionValues) throws Exception {
        int iTotalRows = 0;
        iTotalRows = lossDetails.approvedTable.getRowCount();

        for (String key : approvedSetionValues.keySet()) {
            if (lossDetails.approvedTableCell.containsKey(key) && lossDetails.approvedTableCell.get(key).getTypeCell().equals("input")) {
                if (key.equals("Procedure")) {
                    lossDetails.approvedTable.setTextSelect(lossDetails.approvedTableCell.get(key).getPosition(), iTotalRows, this.replaceConfigurationValues(approvedSetionValues.get(key)).split(" ")[0], this.replaceConfigurationValues(approvedSetionValues.get(key)));
                } else {
                    lossDetails.approvedTable.setText(lossDetails.approvedTableCell.get(key).getPosition(), iTotalRows, this.replaceConfigurationValues(approvedSetionValues.get(key)));
                }
            }
        }
        lossDetails.approvedTable.selectFirstValue(lossDetails.approvedTableCell.get("Incident").getPosition(), iTotalRows);
    }


    @And("click on [{}] button in approved section")
    public void clickOnSendToInvestigatorButton(String buttonName) throws Exception {
        lossDetails.controlApprovedButton.get(buttonName).click();
    }


    @And("click on [Find Vet] button in loss detail page")
    public void clickOnFindVetButtonInLossDetailPage() throws Exception {
        lossDetails.findVetButton.click();
    }

    @And("click on [{}] button in loss detail - overview page")
    public void clickOnSaveButtonInLossDetailOverviewPage(String nameControl) throws Exception {
        if (lossDetails.controlOverviewButton.containsKey(nameControl)){
            lossDetails.controlOverviewButton.get(nameControl).controlIsClickable();
            lossDetails.controlOverviewButton.get(nameControl).click();
        }
        else
            throw new Exception("the button " + nameControl + " does not exist in loss detail overview page");
    }


    @And("create a incident in loss details")
    public void createAIncidentInLossDetails() throws Exception {
        lossDetails.incidentsPlusButton.click();
        lossDetails.incidentModal.addIncident(1);
        Thread.sleep(5000);
        lossDetails.approvedTable.selectFirstValue(lossDetails.approvedTableCell.get("Incident").getPosition(), 1);
        Thread.sleep(2000);
        lossDetails.controlApprovedButton.get("Save").click();
        lossDetails.controlOverviewButton.get("Save").click();
    }

    @And("find a vet to add to the option in Loss Detail section")
    public void findAVetToAddToTheOptionInLostDetailSection() throws Exception {
        lossDetails.findVetButton.click();
        lossDetails.vetSearchModal.stateProvinceSelect.firstValue();
        lossDetails.vetSearchModal.clickOnSelectButton(1, "c");
    }

    @And("create a new incident in loss details and added it")
    public void createANewIncidentInLossDetailsAndAddedIt() throws Exception {
        lossDetails.incidentsPlusButton.click();
        lossDetails.incidentModal.createANewIncidentButton.click();
        IncidentEntity incidentEntity = new IncidentEntity();
        incidentEntity.setOnSetDate(new SimpleDateFormat("MM/dd/yyyy").format(new Date()))
                .setIncidentType("170 - Staph Infection")
                .setIncidentTypeInitial("170");
        lossDetails.incidentModal.createIncident(incidentEntity);
        Thread.sleep(5000);
        lossDetails.approvedTable.selectFirstValue(lossDetails.approvedTableCell.get("Incident").getPosition(), 1);
        Thread.sleep(2000);
        lossDetails.controlApprovedButton.get("Save").click();
        lossDetails.controlOverviewButton.get("Save").click();
    }

    @And("create a new incident in loss details with")
    public void createANewIncidentInLossDetailsWith(Map<String, String> values) throws Exception {
        lossDetails.incidentsPlusButton.click();
        lossDetails.incidentModal.createANewIncidentButton.click();
        IncidentEntity incidentEntity = new IncidentEntity();
        String temporal = this.replaceConfigurationValues(values.get("date"));
        incidentEntity.setOnSetDate(temporal)
                .setIncidentType(values.get("incidentType"))
                .setIncidentTypeInitial(values.get("initialCode"));
        Thread.sleep(5000);
        lossDetails.incidentModal.createIncident(incidentEntity);
        Thread.sleep(5000);
        lossDetails.approvedTable.selectFirstValue(lossDetails.approvedTableCell.get("Incident").getPosition(), 1);
        Thread.sleep(2000);
        lossDetails.controlApprovedButton.get("Save").click();
    }
    @And("create a new incident in loss details")
    public void createANewIncidentInLossDetails(Map<String, String> values) throws Exception {
        lossDetails.incidentsPlusButton.click();
        lossDetails.incidentModal.createANewIncidentButton.click();
        IncidentEntity incidentEntity = new IncidentEntity();
        String temporal = this.replaceConfigurationValues(values.get("date"));

        incidentEntity.setOnSetDate(temporal)
                .setIncidentType(values.get("incidentType"))
                .setIncidentTypeInitial(values.get("initialCode"));

        if (values.containsKey("details"))
           incidentEntity.setDetails(values.get("details"));

        for (String controls:lossDetails.incidentModal.allControls.keySet()) {
            Assertions.assertTrue(lossDetails.incidentModal.allControls.get(controls).controlIsDisplayed(),"ERROR> the control ["+controls+"] is not displayed on Add New Incident Modal");
        }
        lossDetails.incidentModal.createIncident(incidentEntity);
        Thread.sleep(2000);
        lossDetails.controlApprovedButton.get("Save").click();
    }

    @And("I click on a link view loss details")
    public void iClickOnALinkViewLossDetails() throws Exception {
        lossDetails.viewlossdetailsLink.click();
    }

    @Then("verify the Reason")
    public void verifyTheReason(String expectedreason) throws Exception {
        String actualreason = lossDetails.denialreason1Label.getText();
        expectedreason = this.replaceConfigurationValues(expectedreason);
        Assertions.assertTrue(actualreason.contains(expectedreason),
                "Wrong denial reason, actual: [" + actualreason + "] vs expected: [" + expectedreason + "]");

    }

    @Then("verify the denialReason2")
    public void verifyThedenialReason2(String expectedreason) throws Exception {
        String actualreason = lossDetails.denialreason2Label.getText();
        expectedreason = this.replaceConfigurationValues(expectedreason);
        Assertions.assertTrue(actualreason.contains(expectedreason),
                "Wrong denial reason, actual: [" + actualreason + "] vs expected: [" + expectedreason + "]");

    }

    @Then("verify the denialReason3")
    public void verifyThedenialReason3(String expectedreason) throws Exception {
        String actualreason = lossDetails.denialreason3Label.getText();
        expectedreason = this.replaceConfigurationValues(expectedreason);
        Assertions.assertTrue(actualreason.contains(expectedreason),
                "Wrong denial reason, actual: [" + actualreason + "] vs expected: [" + expectedreason + "]");
    }

    @Then("verify the denialReason on loss details page")
    public void verifyTheDenialReasonOnLossDetailsPage(String expectedResult) throws Exception {

        String actualResult = lossDetails.denialReason4Label.getText();
        expectedResult = this.replaceConfigurationValues(expectedResult);
        Assertions.assertTrue(actualResult.contains(expectedResult),
                "Wrong denial reason, actual: [" + actualResult + "] vs expected: [" + expectedResult + "]");
    }

    @Then("verify the denialReason")
    public void verifyTheDenialReason(String expectedResults) throws Exception {
        String actualResult = lossDetails.denialReason4Label.getText();
        expectedResults = this.replaceConfigurationValues(expectedResults);
        Assertions.assertTrue(actualResult.contains(expectedResults),
                "Wrong denial reason, actual: [" + actualResult + "] vs expected: [" + expectedResults + "]");
    }

    @Then("verify the denialReason on loss details pages")
    public void verifyTheDenialReasonOnLossDetailsPages(String expectedResult) throws Exception {
        String actualResult = lossDetails.denialReason6Label.getText();
        expectedResult = this.replaceConfigurationValues(expectedResult);
        Assertions.assertTrue(actualResult.contains(expectedResult),
                "Wrong denial reason, actual: [" + actualResult + "] vs expected: [" + expectedResult + "]");
    }

    @Then("verify the denial Reasons")
    public void verifyTheDenialReasons(String expectedReason) throws Exception {
        String actualreason = lossDetails.denialReasonHeader.getText();
        expectedReason = this.replaceConfigurationValues(expectedReason);
        Assertions.assertTrue(actualreason.contains(expectedReason),
                "Wrong denial reason, actual: [" + actualreason + "] vs expected: [" + expectedReason + "]");
    }

    @And("click [+Add New] button in approved section")
    public void clickAddNewButtonInApprovedSection() throws Exception {
        lossDetails.addNewButton.click();
    }

    @And("I fill Vet Details on the New Vet Modal")
    public void iFillVetDetailsOnTheNewVetModal(DataTable table) throws Exception {
        lossDetails.findVetButton.click();
        vetSearchModal.createNewVetButton.waitUntilControlIsDisplayed();
        vetSearchModal.createNewVetButton.click();
        List<Map<String, String>> data = table.asMaps(String.class, String.class);
        for (Map<String, String> mData : data) {
            CommonValues.variables.put(mData.get("FieldName"),this.replaceConfigurationValues(mData.get("FieldValue")).trim());
            addNewVetModal.fillDetailsOnNewVetModal(mData.get("FieldName"),CommonValues.variables.get(mData.get("FieldName")));
        }
        addNewVetModal.saveButton.controlIsDisplayed(2);
        addNewVetModal.saveButton.click();
        addNewVetModal.saveButton.controlIsNotDisplayed(3);
        lossDetails.findVetButton.waitUntilControlIsDisplayed();
    }

    @Then("below alert message should be displayed on the 'Add Loss' page")
    public void belowAlertMessageShouldBeDisplayedOnTheAddLossPage(List<String> message) throws Exception {
        for (String alertMessage : message) {
            Assertions.assertTrue(lossDetails.alertMessage.controlIsDisplayed() && lossDetails.alertMessage.getText().trim().contains(alertMessage),"Error: "+alertMessage+" is not displayed");
        }
    }

    @Then("I verify the Warning alert massage")
    public void iVerifyTheWarningAlertMassage(String expectedResult) throws Exception {
        String actualResult = lossDetails.warningAlertLabel.getText();
        expectedResult = this.replaceConfigurationValues(expectedResult);
        Assertions.assertTrue(actualResult.contains(expectedResult),
                "ERROR the message is not successfully, actual: [" + actualResult + "] vs expected: [" + expectedResult + "]");
    }

    @And("I click on [Edit Vet] button on the loss details page")
    public void iClickOnEditVetButtonOnTheLossDetailsPage() throws Exception {
        vetDetailsPage.editVetButton.click();
    }

    @And("I click on [Edit] button on the loss details page")
    public void iClickOnEditButtonOnTheLossDetailsPage() throws Exception {
        vetDetailsPage.editButton.click();


    }

    @And("I click on [view] button for [{}] on incident table - loss detail page")
    public void iClickOnViewButtonForStaphInfectionOnIncidentTableLossDetailPage(String nameIncident) throws Exception {
        int row = lossDetails.incidentTable.getPositionRow(nameIncident);
        lossDetails.incidentTable.clickLink("Actions",row);
    }
}
