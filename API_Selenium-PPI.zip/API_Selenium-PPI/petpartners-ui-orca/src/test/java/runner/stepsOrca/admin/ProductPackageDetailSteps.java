package runner.stepsOrca.admin;

import entities.orca.admin.AddNewProductEntity;
import entities.orca.admin.ProductPackagesDetailEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orca.admin.productManagement.ProductPackageDetailPage;
import runner.BaseSteps;

import java.util.Map;

public class ProductPackageDetailSteps extends BaseSteps {
    ProductPackageDetailPage productPackageDetailPage = new ProductPackageDetailPage();

    @And("filling details in the product package detail page")
    public void fillingDetailsInTheProductPackageDetailPage(ProductPackagesDetailEntity productPackagesDetailEntity) throws Exception {
        this.productPackageDetailPage.fillProductPackageDetails(productPackagesDetailEntity);
    }

    @DataTableType
    public ProductPackagesDetailEntity productPackagesDetailEntity(Map<String,String> entry){
        ProductPackagesDetailEntity productPackagesDetailEntity = new ProductPackagesDetailEntity();
        productPackagesDetailEntity.setCode(this.replaceConfigurationValues(entry.get("Code")))
                .setDisplay(this.replaceConfigurationValues(entry.get("Display")));
        return productPackagesDetailEntity;
    }


    @When("I click on Product Package save button on product package detail Page")
    public void iClickOnProductPackageSaveButtonOnProductPackageDetailPage() throws Exception {
        productPackageDetailPage.productPackageDetailSaveButton.click();
    }

    @Then("I verify newly added package details in product package detail page")
    public void iVerifyNewlyAddedPackageDetailsInProductPackageDetailsPage() throws Exception {
        Assertions.assertTrue(productPackageDetailPage.codeTextBox.getTextAttribute("value").length() > 0,
                "ERROR: Product package Id text box is blank");

        Assertions.assertTrue(productPackageDetailPage.displayTextBox.getTextAttribute("value").length() > 0,
                "ERROR: Product package CreatedOn text box is blank");
    }

    @And("I click on {string} Button on product package detail Page")
    public void iClickOnButtonOnProductPackageDetailPage(String arg0) throws Exception {
        productPackageDetailPage.addParentProductButton.controlIsDisplayed(3);
        productPackageDetailPage.addParentProductButton.controlIsClickable();
        productPackageDetailPage.addParentProductButton.click();
    }

    @And("filling {string} product details in the product package detail page")
    public void fillingProductDetailsInTheProductPackageDetailPage(String sType, AddNewProductEntity addNewProductEntity)throws Exception {
        productPackageDetailPage.fillAddNewProductDetails(sType, addNewProductEntity);
    }

    @DataTableType
    public AddNewProductEntity addNewProductEntity(Map<String,String> entry){
        AddNewProductEntity addNewProductEntity = new AddNewProductEntity();
        addNewProductEntity.setProducts(this.replaceConfigurationValues(entry.get("Products")))
                           .setRatingType(this.replaceConfigurationValues(entry.get("RatingType")))
                           .setTermDays(this.replaceConfigurationValues(entry.get("TermDays")))
                           .setMaxAge(this.replaceConfigurationValues(entry.get("MaxAge")))
                           .setMinAge(this.replaceConfigurationValues(entry.get("MinAge")));

        return addNewProductEntity;
    }

    @Then("I verify newly added product details in product package details page")
    public void iVerifyNewlyAddedProductDetailsInProductPackageDetailsPage(Map<String, String> controlsValue) throws Exception {

        Assertions.assertEquals(productPackageDetailPage.productDisabledText.getText(),
                this.replaceConfigurationValues(controlsValue.get("Products")),
                "ERROR: Products value " + this.replaceConfigurationValues(controlsValue.get("Products")) + " not displayed");

        Assertions.assertEquals(productPackageDetailPage.ratingTypeDisabledText.getText(),
                this.replaceConfigurationValues(controlsValue.get("RatingType")),
                "ERROR: Rating Type value " + this.replaceConfigurationValues(controlsValue.get("RatingType")) + " not displayed");

        Assertions.assertEquals(productPackageDetailPage.termDaysTextBox.getTextAttribute("value"),
                this.replaceConfigurationValues(controlsValue.get("TermDays")),
                "ERROR: Term Days value " + this.replaceConfigurationValues(controlsValue.get("TermDays")) + " not displayed");

        Assertions.assertEquals(productPackageDetailPage.maxAgeTextBox.getTextAttribute("value"),
                this.replaceConfigurationValues(controlsValue.get("MaxAge")),
                "ERROR: Max Age value " + this.replaceConfigurationValues(controlsValue.get("MaxAge")) + " not displayed");

        Assertions.assertEquals(productPackageDetailPage.minAgeTextBox.getTextAttribute("value"),
                this.replaceConfigurationValues(controlsValue.get("MinAge")),
                "ERROR: Min Age value " + this.replaceConfigurationValues(controlsValue.get("MinAge")) + " not displayed");
    }

    @When("I click on edit icon in product package details page")
    public void iClickOnEditIconInProductPackageDetailsPage() throws Exception {
        productPackageDetailPage.packageEditButton.click();
    }

    @Then("I change display value in product package details page")
    public void iChangeDisplayValueInProductPackageDetailsPage(Map<String, String> controlsValue) throws Exception {
        productPackageDetailPage.displayTextBox.clearSetText(this.replaceConfigurationValues(controlsValue.get("Display")));
    }

    @When("I click on edit icon in product details section")
    public void iClickOnEditIconInProductDetailsSection() throws Exception {
        productPackageDetailPage.productsEditButton.click();
    }

    @And("I unselect active checkbox in product package details page")
    public void iUnselectActiveCheckboxInProductPackageDetailsPage() throws Exception {
        productPackageDetailPage.packageActive.uncheck();
    }

    @Then("I verify active checkbox value in product package details page")
    public void iVerifyActiveCheckboxValueInProductPackageDetailsPage() throws Exception {
       // Assertions.assertTrue(productPackageDetailPage.packageActive.getText());
        //        "ERROR! the value : [" + this.replaceConfigurationValues(value) + "] is not displayed in the policy search result section");
    }

    @And("I click on Add Child Product button in product details section")
    public void iClickOnAddChildProductButtonInProductDetailsSection() throws Exception {
        productPackageDetailPage.addChildProductButton.click();
    }

    @Then("I click on product package name link and verify newly added child product details in product package details page")
    public void iClickOnProductPackageNameLinkAndVerifyNewlyAddedChildProductDetailsInProductPackageDetailsPage(Map<String, String> controlsValue) throws Exception {
        Assertions.assertEquals(productPackageDetailPage.childProductDisabledText.getText(),
                this.replaceConfigurationValues(controlsValue.get("Products")),
                "ERROR: Products value " + this.replaceConfigurationValues(controlsValue.get("Products")) + " not displayed");

        Assertions.assertEquals(productPackageDetailPage.childRatingTypeDisabledText.getText(),
                this.replaceConfigurationValues(controlsValue.get("RatingType")),
                "ERROR: Rating Type value " + this.replaceConfigurationValues(controlsValue.get("RatingType")) + " not displayed");

        Assertions.assertEquals(productPackageDetailPage.childMaxAgeTextBox.getTextAttribute("value"),
                this.replaceConfigurationValues(controlsValue.get("MaxAge")),
                "ERROR: Max Age value " + this.replaceConfigurationValues(controlsValue.get("MaxAge")) + " not displayed");

        Assertions.assertEquals(productPackageDetailPage.childMinAgeTextBox.getTextAttribute("value"),
                this.replaceConfigurationValues(controlsValue.get("MinAge")),
                "ERROR: Min Age value " + this.replaceConfigurationValues(controlsValue.get("MinAge")) + " not displayed");

    }
}