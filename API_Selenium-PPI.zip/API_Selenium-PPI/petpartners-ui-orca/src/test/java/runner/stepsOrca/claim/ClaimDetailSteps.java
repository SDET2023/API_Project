package runner.stepsOrca.claim;

import configuration.CommonValues;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orca.claim.*;
import runner.BaseSteps;
import session.Session;
import utils.Level;
import utils.Logger;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ClaimDetailSteps extends BaseSteps {
    ClaimDetails claimDetails = new ClaimDetails();


    @Then("the Claim Detail page should be displayed")
    public void theClaimDetailPageShouldBeDisplayed() {
        Assertions.assertTrue(Session.getInstance().getDriver().getCurrentUrl().contains("ClaimDetail"),
                "The current page is not claim detail, actual: " + Session.getInstance().getDriver().getCurrentUrl());
    }

    @And("click on [{}] tab in the bottom menu")
    public void clickOnAttachmentSTabInTheBottomMenu(String menuTabOption) throws Exception {
        Thread.sleep(2000);
        claimDetails.controlLinks.get(menuTabOption).controlIsDisplayed(5);
        claimDetails.controlLinks.get(menuTabOption).click();
    }

    @And("click on the [Claims] link")
    public void clickOnTheClaimsLink() throws Exception {
        claimDetails.claimsResultLink.click();
    }

    @Then("verify the invoice.pdf link is not empty")
    public void verifyTheInvoicePdfLinkIsNotEmpty() throws Exception {
        Assertions.assertFalse(claimDetails.getLinkForClaimPDF().isEmpty(), "ERROR, the link for the PDF is empty");
    }

    @And("click on [{}] button on the claim detail page")
    public void clickOnSubmitToProcessingButtonOnTheClaimDetailPage(String buttonName) throws Exception {
        claimDetails.controlButtonClaimsDetail.get(buttonName).click();
    }

    @Then("verify the successfully alert is displayed")
    public void verifyTheSuccessfullyAlertIsDisplayed(String expectedResult) throws Exception {
        String actualResult = alertSection.successfullyAlertLabel.getText();
        expectedResult = this.replaceConfigurationValues(expectedResult);
        Assertions.assertTrue(actualResult.contains(expectedResult),
                "ERROR the message is not successfully, actual: [" + actualResult + "] vs expected: [" + expectedResult + "]");
    }

    @And("click on [Add Loss\\(es)] button in processing tab")
    public void clickOnAddLossEsButtonInProcessingTab() throws Exception {
        claimDetails.addLossesButton.click();
    }



    @And("click on [Send to Investigator] button in claims details")
    public void clickOnSendToInvestigatorButton() throws Exception {
        claimDetails.sendToInvestigatorButton.click();
    }


    @And("I get the claim number displayed in the alert in {}")
    public void iGetTheClaimNumberDisplayedInTheAlertInClaimNumber(String variableName) throws Exception {
        String actualResult = alertSection.successfullyAlertLabel.getText();
        Pattern pattern = Pattern.compile("Successfully assigned claim (.*) to (.*)");
        Matcher matcher = pattern.matcher(actualResult);
        if (matcher.find()) {
            CommonValues.variables.put(variableName, matcher.group(1));
            Logger.log(Level.INFO, this.getClass().getName() + "> save the value: [" + CommonValues.variables.get(variableName) + "] in [" + variableName + "]");
        } else {
            throw new Exception("The claim number is not displayed, actual: " + actualResult);
        }
    }

    @And("I select {string} in the Page Size Table")
    public void iSelectAllRowsInThePageSizeTable(String value) throws Exception {
        if (claimDetails.controlSelect.get("Page Size Table").controlIsDisplayed())
            claimDetails.controlSelect.get("Page Size Table").selectValue(value);
        claimDetails = new ClaimDetails();
    }

    @And("click on Policy Number in claims details")
    public void clickOnPolicyNumberInClaimsDetails() throws Exception {
        claimDetails.policyNumber.click();
    }

    @And("I get the Policy Number displayed in claims details in {}")
    public void iGetThePolicyNumberDisplayedInClaimsDetailsInPolicyNumber(String variable) throws Exception {
        CommonValues.variables.put(variable, claimDetails.policyNumber.getText());
        Logger.log(Level.INFO, this.getClass().getName() + "> save the value: [" + CommonValues.variables.get(variable) + "] in [" + variable + "]");
    }

    @And("click on view button for petname: {string} in the losses table")
    public void clickOnViewButtonForPetnameInTheLossesTable(String petnameValue) throws Exception {
        claimDetails.clickOnViewDeleteCellForPet(this.replaceConfigurationValues(petnameValue), false);
    }

    @And("fill the adjuster note using the value {string}")
    public void fillTheAdjusterNoteUsingTheValue(String value) throws Exception {
        Session.getInstance().getDriver().switchTo().frame("adjuster-note_ifr");
        claimDetails.adjusterNoteTextBoxFrame.setText(this.replaceConfigurationValues(value));
        Thread.sleep(10000);
        Session.getInstance().getDriver().switchTo().defaultContent();
    }

    @Then("the href attribute for [{}] should be")
    public void theHrefAttributeForPreviewEOBShouldBe(String buttonName, String expectedResult) throws Exception {
        String actualResult = claimDetails.controlButtonClaimsDetail.get(buttonName).getTextAttribute("href");
        Assertions.assertTrue(this.replaceConfigurationValues(actualResult).contains(this.replaceConfigurationValues(expectedResult)), "ERROR comparing the links: actualResult: " + this.replaceConfigurationValues(actualResult) + " VS expectedResult: " + this.replaceConfigurationValues(expectedResult));
    }

    @And("create a claim with random values on Claim Detail page")
    public void createAClaimWithRandomValuesOnClaimDetailPage() throws Exception {
        claimDetails.controlSelect.get("Assistant").firstValue();
        claimDetails.controlSelect.get("Adjuster").firstValue();
        claimDetails.controlSelect.get("Priority").firstValue();
        claimDetails.controlSelect.get("Auditor").firstValue();
        claimDetails.controlButtonClaimsDetail.get("Save").click();
        Thread.sleep(3000);
        claimDetails.controlButtonClaimsDetail.get("Return to Policy").click();
    }

    @And("create a claim with with today date, submit processing")
    public void createAClaimWithWithTodayDateSubmitProcessing() throws Exception {
        claimDetails.controlSelect.get("Assistant").firstValue();
        claimDetails.controlSelect.get("Adjuster").firstValue();
        claimDetails.controlSelect.get("Priority").firstValue();
        claimDetails.controlSelect.get("Auditor").firstValue();
        claimDetails.receivedOnTextBox.click();
        claimDetails.receivedOnTextBox.setText(new SimpleDateFormat("MM/dd/yyyy").format(new Date()));
        claimDetails.controlButtonClaimsDetail.get("Save").click();
        claimDetails.controlButtonClaimsDetail.get("Submit to Processing").click();
        Thread.sleep(3000);
    }

    @And("verify the {} ComboBox is {} in claim detail")
    public void verifyTheAssistantComboBoxIsNotEmpty(String nameControl, String expected) throws Exception {
        String currentValue = claimDetails.controlSelect.get(nameControl).getTextOptionSelected();
        expected = this.replaceConfigurationValues(expected);
        Assertions.assertTrue(currentValue.contains(expected), "the value is not correct in user assigned\n current: " + currentValue + " vs expected:" + expected);
    }

    @And("verify the Status value is {} in claim detail")
    public void verifyTheStatusValueIsAssigned(String expectedReuslt) throws Exception {
        String actualValue = claimDetails.statusLabel.getText();
        expectedReuslt = this.replaceConfigurationValues(expectedReuslt);
        Assertions.assertTrue(actualValue.contains(expectedReuslt), "ERROR the status is not correct, actual: " + actualValue + "vs expected:" + expectedReuslt);
    }

    @And("verify the Underwriter has the value")
    public void verifyTheUnderwriterHasTheValue(String expectedValue) throws Exception {
        String actualValue = claimDetails.underwriterLabel.getText();
        expectedValue = this.replaceConfigurationValues(expectedValue);
        Assertions.assertTrue(actualValue.contains(expectedValue), "ERROR the Underwriter is not correct, actual: " + actualValue + "vs expected: " + expectedValue);
    }

    @And("get the {} ComboBox value on {} in claim detail")
    public void getTheAssistantComboBoxValueOnUserInClaimDetail(String nameControl, String variable) throws Exception {
        String value = claimDetails.controlSelect.get(nameControl).getTextOptionSelected();
        CommonValues.variables.put(variable, value);
        Logger.log(Level.INFO, this.getClass().getName() + "> save the value: [" + CommonValues.variables.get(variable) + "] in [" + variable + "]");
    }

    @And("I select the {} in the {} ComboBox on Claim Detail")
    public void iSelectTheLoggerUserInTheAuditorComboBoxOnClaimDetail(String option, String control) throws Exception {
        claimDetails.controlSelect.get(control).selectContainsValueUsingXpath(this.replaceConfigurationValues(option));
    }

    @And("click on [Return to Claim]")
    public void clickOnReturnToClaim() throws Exception {
        claimDetails.returnToClaimButton.click();
    }

    @And("I click on a link view claim details")
    public void iClickOnALinkViewClaimDetails() throws Exception {
        claimDetails.viewClaimDetailsLink.click();
        Thread.sleep(1000);
    }

    @And("click on Finalize All Loss\\(es) button")
    public void clickOnFinalizeAllLossEsButton() throws Exception {
        Thread.sleep(1000);
        claimDetails.finalizeAllLossesButton.click();
    }

    @And("I click on {string} tab under attachment")
    public void iClickOnTabUnderAttachment(String value) throws Exception {
        if(value.contains("Other")){
            claimDetails.otherLink.click();
        } else if(value.contains("Term")){
            claimDetails.termLink.click();
        }
    }

    @Then("I verify Finance and Cancellation document is not empty")
    public void iVerifyFinanceAndCancellationDocumentIsNotEmpty() throws Exception {
        Assertions.assertFalse(claimDetails.getLinkForCancellationPDF().isEmpty(), "ERROR, the link for the PDF is empty");
    }
    @And("I click on [Regenerate docs] button on claim detail page")
    public void iClickOnRegenerateDocsButtonOnClaimDetailPage() throws Exception {
        claimDetails.regenerateDocs.click();
    }

    @And("Choose {string} on Regenerate Documents By Claim Id section")
    public void chooseOnRegenerateDocumentsByClaimIdSection(String option) throws Exception {
        option =  this.replaceConfigurationValues(option);
        claimDetails.regenerateComboBox.controlIsDisplayed(15);
        claimDetails.regenerateComboBox.selectValueContainsOption(option);
        claimDetails.regenerateButton.click();
    }

    @And("verify {string} document are displayed {int} times")
    public void verifyDocumentAreDisplayedTimes(String value, int repeatExpected) {
     int actualResult = claimDetails.getNumberOfElementsOnAttachmentTable(this.replaceConfigurationValues(value));
     Assertions.assertEquals(repeatExpected,actualResult,"ERROR!! the value: "+this.replaceConfigurationValues(value)+" is displayed ["+actualResult+"] instead of ["+repeatExpected+"]");
    }

    @When("I click on document checkbox under claims attachment tab")
    public void iClickOnDocumentCheckboxUnderClaimsAttachmentTab()  throws Exception {
        claimDetails.claimsDocumentCheckbox.controlIsClickable();
        claimDetails.claimsDocumentCheckbox.controlIsDisplayed(10);
        claimDetails.claimsDocumentCheckbox.check();
    }

    @And("I click on Reissue button under claims attachment tab")
    public void iClickOnButtonUnderClaimsAttachmentTab()  throws Exception {
        claimDetails.claimsReissueDocButton.controlIsClickable();
        claimDetails.claimsReissueDocButton.controlIsDisplayed(10);
        claimDetails.claimsReissueDocButton.click();
    }

    @And("I click on [{}] button under Actions column")
    public void iClickOnVoidCheckButtonUnderActionsColumnClaimDetail(String buttonName) throws Exception {
        claimDetails.voidCheckButton.waitUntilControlIsDisplayed();
        claimDetails.voidCheckButton.click();
    }

    @And("I click on Reissue checkbox on Void Check popup")
    public void iClickOnReissueCheckboxClaimDetail() throws Exception {
        claimDetails.voidCheckLabel.waitUntilControlIsDisplayed();
        claimDetails.reissueCheckCheckbox.click();
    }

    @And("I get a Check Number on {}")
    public void iGetACheckNumberClaimDetail(String variable) throws Exception{
        CommonValues.variables.put(variable,this.replaceConfigurationValues(claimDetails.checkNumberOnPopupLabel.getText().trim()));
        Logger.log(Level.INFO,this.getClass().getName()+" save the variable ["+variable+"] value: "+CommonValues.variables.get(variable));
    }

    @When("I click on Save button on Void Check popup")
    public void iClickOnSaveButtonOnVoidCheckPopupClaimDetail() throws Exception {
        claimDetails.voidCheckPopUpSaveButton.waitUntilControlIsDisplayed();
        claimDetails.voidCheckPopUpSaveButton.click();
    }

    @Then("I verify the a new note should be displayed with message under Claim - Notes tab")
    public void iVerifyNewNoteIsDisplayedUnderClaimNotesClaimDetail(String expectedResult) throws Exception {
        claimDetails.checkReissuedMessageLabel.waitUntilControlIsDisplayed();
        String actualResult = claimDetails.checkReissuedMessageLabel.getText();
        expectedResult = this.replaceConfigurationValues(expectedResult);
        Assertions.assertTrue(actualResult.contains(expectedResult),
                "ERROR the check reissued message is not displayed successfully, actual: [" + actualResult + "] vs expected: [" + expectedResult + "]");
    }

    @And("I get a Policy Number on {} from Claim Detail Page")
    public void iGetAPolicyNumberFromClaimDetail(String variable) throws Exception{
        CommonValues.variables.put(variable,this.replaceConfigurationValues(claimDetails.policyNumber.getText().trim()));
        Logger.log(Level.INFO,this.getClass().getName()+" save the variable ["+variable+"] value: "+CommonValues.variables.get(variable));
    }
}