package runner.stepsOrca.policy;


import configuration.CommonValues;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orca.pet.PetDetailPage;
import runner.BaseSteps;
import utils.Level;
import utils.Logger;

import java.util.List;


public class PetDetailSteps extends BaseSteps {
    PetDetailPage petDetailPage = new PetDetailPage();

    @Then("the Pet Detail page should be displayed")
    public void thePetDetailPageShouldBeDisplayed() {
        Assertions.assertTrue(petDetailPage.petDetailLabel.controlIsDisplayed(), "ERROR! the pet detail page is not displayed");
    }

    @When("I click on the [{}] tab option on pet detail page")
    public void iClickOnTheClaimsTabOptionOnPetDetailPage(String tabOption) throws Exception {
        if (petDetailPage.petDetailTabOption.containsKey(tabOption))
            petDetailPage.petDetailTabOption.get(tabOption).click();
        else
            throw new Exception("Error the option in tab " + tabOption + " does not exist");
    }

    @And("the claim table should be displayed with the columns")
    public void theClaimTableShouldBeDisplayedWithTheColumns(List<String> expectedLabels) throws Exception {
        Assertions.assertTrue(petDetailPage.claimsTable.verifyAllHeaderLabel(expectedLabels),
                "Some labels in the table is missing, actual [" + petDetailPage.claimsTable.getAllHeaderLabel().toString() + " vs expected [" + expectedLabels.toString() + "]");
    }

    @And("I get the {} value in Pet Detail in {}")
    public void iGetThePetnameValueInPetDetailInPetName(String textbox, String variableName) throws Exception {
        String value = petDetailPage.petDetailTextBox.get(textbox).getTextAttribute("value");
        CommonValues.variables.put(variableName, value);
        Logger.log(Level.INFO, this.getClass().getName() + "> save the value: [" + CommonValues.variables.get(variableName) + "] in [" + variableName + "]");
    }

    @And("select the {string} option on {string} on Pet Detail Page")
    public void selectTheOptionOnWaitingPeriodWaiverOnPetDetailPage(String value, String control) throws Exception {
        petDetailPage.petDetailSelect.get(control).selectValue(this.replaceConfigurationValues(value));
    }

    @And("click on save button on Pet Detail Page")
    public void clickOnSaveButtonOnPetDetailPage() throws Exception {
        petDetailPage.saveButton.click();
    }


    @Then("verify the {string} is displayed on Allowance Table on pet detail page")
    public void verifyTheIsDisplayedOnAllowanceTableOnPetDetailPage(String expectedValue) throws Exception {
        petDetailPage.allowanceTable.controlIsDisplayed(5);
        Assertions.assertTrue(petDetailPage.allowanceTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(expectedValue)),
                "ERROR>  the value: ["+this.replaceConfigurationValues(expectedValue)+"] is not displayed in Allowance Table");
    }

    @Then("No Results\\(s) message should be displayed")
    public void noResultSMessageShouldBeDisplayed() {
        Assertions.assertTrue(petDetailPage.waitingPeriodWaiverNoResultsLabel.controlIsDisplayed(), "No Results alert was not found under Waiting Period Waiver History tab");
    }

    @Then("Waiting Period Waiver History table has a row for {string}")
    public void waitingPeriodWaiverHistoryTableHasARowFor(String value) throws Exception {
        Assertions.assertFalse(petDetailPage.waitingPeriodWaiverNoResultsLabel.controlIsDisplayed(), "There is no results in the Waiting Period Waiver History table");
        Assertions.assertTrue(petDetailPage.waitingPeriodWaiverHistoryTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(value)),"ERROR>  the value: ["+this.replaceConfigurationValues(value)+"] is not displayed in Waiting Period Waiver History table");
    }

    @Then("The Waiting Period Waiver Table should be displayed with the columns")
    public void theWaitingPeriodWaiverTableShouldBeDisplayedWithTheColumns(List<String> expectedLabelsTable) throws Exception {
        Assertions.assertTrue(petDetailPage.waitingPeriodWaiverHistoryTable.verifyAllHeaderLabel(expectedLabelsTable),
                "Some labels in the table is missing, actual [" + petDetailPage.waitingPeriodWaiverHistoryTable.getAllHeaderLabel().toString() + " vs expected [" + expectedLabelsTable.toString() + "]");

    }
}