package runner.stepsOrca.partner;
import entities.orca.partner.PartnerDetailOverviewEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.orca.partner.PartnerDetailOverviewPage;
import runner.BaseSteps;

import java.util.Map;

public class PartnerDetailSteps extends BaseSteps {
    PartnerDetailOverviewPage partnerDetailOverviewPage = new PartnerDetailOverviewPage();

    @And("filling details in the partner detail overview page")
    public void fillingDetailsInThePartnerDetailOverviewPage(PartnerDetailOverviewEntity partDtlsOverviewEntity) throws Exception {
        this.partnerDetailOverviewPage.fillPartnerDetailOverviewDetails(partDtlsOverviewEntity);
    }

    @DataTableType
    public PartnerDetailOverviewEntity partDtlsOverviewEntity(Map<String, String> entry) {
        PartnerDetailOverviewEntity entity = new PartnerDetailOverviewEntity();
        entity.setPartnerName(replaceConfigurationValues(entry.get("PartnerName")))
                .setPartnerCode(this.replaceConfigurationValues(entry.get("PartnerCode")))
                .setDefaultAffinityGroup(this.replaceConfigurationValues(entry.get("DefaultAffinityGroup")))
                .setPartnerType(this.replaceConfigurationValues(entry.get("PartnerType")))
                .setNpn(this.replaceConfigurationValues(entry.get("NPN")));
        return entity;
    }

    @And("I click on save button in partner detail overview page")
    public void iClickOnSaveButtonInPartnerDetailOverviewPage() throws Exception {
        this.partnerDetailOverviewPage.partnerDetailSaveButton.click();
    }

    @When("I click on NPN in Partner Detail overview page")
    public void iClickOnNPNInPartnerDetailOverviewPage() throws Exception {
        this.partnerDetailOverviewPage.npnTextBox.click();
    }

    @Then("I modify npn value in partner detail overview page")
    public void iModifyNPNValueInPartnerDetailOverviewPage(Map<String, String> controlsValue) throws Exception {
        partnerDetailOverviewPage.npnTextBox.clearSetText(this.replaceConfigurationValues(controlsValue.get("NPNValue")));
    }

    @And("I Enter the Affiliate Name to textBox")
    public void iEnterTheAffiliateNameToTextBox(Map<String, String> controlsValue) throws Exception {
        this.partnerDetailOverviewPage.affiliateTextBox.setText(this.replaceConfigurationValues(controlsValue.get("DisplayValue")));

    }
}
