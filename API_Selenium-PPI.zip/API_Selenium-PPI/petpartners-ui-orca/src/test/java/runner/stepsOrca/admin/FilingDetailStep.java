package runner.stepsOrca.admin;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import pages.orca.admin.productManagement.FilingDetailPage;
import runner.BaseSteps;

public class FilingDetailStep extends BaseSteps {

    FilingDetailPage filingDetailPage = new FilingDetailPage();

    @And("I click on {string} Button under the product table in Filing Detail Page")
    public void iClickOnButtonUnderTheProductTable(String value) throws Exception {
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(20);
        filingDetailPage.productDetailsButtons.get(value).click();
    }

    @And("I enter {string} to Marketing Textbox in Filing Detail Page")
    public void iEnterToMarketingTextBox(String value) throws Exception {
        filingDetailPage.marketingTextBox.clearSetText(value);
    }
    @And("I click on [Save] button in Filing Detail Page")
    public void iClickOnSaveButton() throws Exception {
        filingDetailPage.saveButton.click();
    }

    @Then("I verify {string} Display under the marketing Textbox in Filing Detail Page")
    public void iVerifyDisplayUnderTheMarketingTextBox(String value) throws Exception {
        Assertions.assertTrue(filingDetailPage.marketingTextBox.getTextAttribute("value").contains(value),
                "Error: "+filingDetailPage.marketingTextBox.getText()+" is not displayed");
    }
}
