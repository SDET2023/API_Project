package runner.stepsOrca.common;

import configuration.CommonValues;
import configuration.Configuration;
import gifBuilder.ScreenShot;
import helper.requirement.CreatePolicyRequirement;
import helpers.GetProperties;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.JavascriptExecutor;
import pages.orca.common.AlertSection;
import pages.orca.common.SubMenuSection;
import runner.BaseSteps;
import session.Session;
import utils.DateUtils;
import utils.Level;
import utils.Logger;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.time.Year;

public class CommonSteps extends BaseSteps {
    SubMenuSection subMenuSection = new SubMenuSection();
    AlertSection alertSection = new AlertSection();
    @And("close the tab {string}")
    public void closeTheTab(String tabTitle) throws Exception {
        List<String> tabList=new ArrayList<String>(Session.getInstance().getDriver().getWindowHandles());
        Map<String, Integer> titlePositionTab= new HashMap<>();
        for (int i=0;i<tabList.size();i++) {
            Session.getInstance().getDriver().switchTo().window(tabList.get(i));
            titlePositionTab.put(Session.getInstance().getDriver().getTitle(),i);
            Logger.log(Level.INFO,this.getClass().getName()+"> Tab: "+Session.getInstance().getDriver().getTitle());
        }
        if (!titlePositionTab.containsKey(this.replaceConfigurationValues(tabTitle)))
            throw new Exception("The tab name "+this.replaceConfigurationValues(tabTitle)+" does not exist! review if the tab name");

        Session.getInstance().getDriver().switchTo().window(tabList.get(titlePositionTab.get(this.replaceConfigurationValues(tabTitle))));
        Session.getInstance().getDriver().close();
        Session.getInstance().getDriver().switchTo().window(tabList.get(0));
        Logger.log(Level.INFO,this.getClass().getName()+"> Current Tab Page: "+Session.getInstance().getDriver().getTitle());
    }

    @And("go to the tab {string}")
    public void  goToTheLinkForThePolicyNumber(String tabTitle) throws Exception {
        ScreenShot.addScreen(this.getClass().getName()+"> go to the tab: "+tabTitle);
        Thread.sleep(5000);
        List<String> tabList=new ArrayList<String>(Session.getInstance().getDriver().getWindowHandles());
        Map<String, Integer> titlePositionTab= new HashMap<>();
        Logger.log(Level.INFO,this.getClass().getName()+"> Number of Tabs Open: "+tabList.size());
        for (int i=0;i<tabList.size();i++) {
            Session.getInstance().getDriver().switchTo().window(tabList.get(i));
            titlePositionTab.put(Session.getInstance().getDriver().getTitle(),i);
            Logger.log(Level.INFO,this.getClass().getName()+"> Tab: "+Session.getInstance().getDriver().getTitle());
        }
        if (!titlePositionTab.containsKey(this.replaceConfigurationValues(tabTitle)))
            throw new Exception("The tab name "+this.replaceConfigurationValues(tabTitle)+" does not exist! review if the tab name");

        Session.getInstance().getDriver().switchTo().window(tabList.get(titlePositionTab.get(this.replaceConfigurationValues(tabTitle))));
        Logger.log(Level.INFO,this.getClass().getName()+"> Current Tab Page: "+Session.getInstance().getDriver().getTitle());
        ScreenShot.addScreen(this.getClass().getName()+"> Current Tab Page: "+Session.getInstance().getDriver().getTitle());
    }

    @Then("the new tab url {string} should be displayed")
    public void theNewTabShouldBeDisplayed(String expectedTabName) throws InterruptedException {
        ScreenShot.addScreen(this.getClass().getName()+"> Current Tab Page: "+expectedTabName);
        Thread.sleep(3000);
        boolean isDisplayed=false;
        List<String> tabList=new ArrayList<String>(Session.getInstance().getDriver().getWindowHandles());
        Logger.log(Level.INFO,this.getClass().getName()+"> Number of Tabs Open: "+tabList.size());
        for (int i=0;i<tabList.size();i++) {
            Session.getInstance().getDriver().switchTo().window(tabList.get(i));
            if (Session.getInstance().getDriver().getCurrentUrl().contains(expectedTabName))
                isDisplayed=true;
        }
        Assertions.assertTrue(isDisplayed,"ERROR: the tab with the name: ["+expectedTabName+"] is not displayed");
        ScreenShot.addScreen(this.getClass().getName()+"> Current Tab Page: "+expectedTabName);
    }

    @And("click on the {string} submenu on {}")
    public void clickOnTheSubmenuOnClaimDashboard(String submenu, String page)throws Exception {
        if (subMenuSection.optionSubMenu.containsKey(submenu)) {
            subMenuSection.optionSubMenu.get(submenu).controlIsDisplayed();
            subMenuSection.optionSubMenu.get(submenu).click();
        }
        else
            throw new Exception("ERROR> the submenu option: ["+submenu+"] does not exist");
    }

    @And("I open a new tab with Orca PetPartners")
    public void iOpenANewTabWithOrcaPetPartners() throws InterruptedException {
        Thread.sleep(2000);
        JavascriptExecutor jse = (JavascriptExecutor)Session.getInstance().getDriver();
        jse.executeScript("window.open()");
        List<String> tabList=new ArrayList<String>(Session.getInstance().getDriver().getWindowHandles());
        Session.getInstance().getDriver().switchTo().window(tabList.get(tabList.size()-1));
        ScreenShot.addScreen(this.getClass().getName()+"> Open a new tab with url: "+Configuration.WEB_URL);
        Logger.log(Level.INFO,this.getClass().getName()+"> Open a new tab with url: "+Configuration.WEB_URL);
        Session.getInstance().getDriver().get(Configuration.WEB_URL);
        ScreenShot.addScreen(this.getClass().getName()+"> Open a new tab with url: "+Configuration.WEB_URL);
        Thread.sleep(2000);
    }

    @And("i get the number of tab on {}")
    public void iGetTheNumberOfTabOnCurrentTabNumber(String numberTabs) {
        List<String> tabList=new ArrayList<String>(Session.getInstance().getDriver().getWindowHandles());
        Logger.log(Level.INFO,this.getClass().getName()+"> save the number of tabs: ["+String.valueOf(tabList.size())+"] in "+numberTabs);
        CommonValues.variables.put(numberTabs,String.valueOf(tabList.size()));
    }

    @Then("the number of tabs should be greater than {} with {int} unit")
    public void theNumberOfTabsShouldBeGreaterThanCurrentTabNumberWithUnit(String oldValue, int comparingValue) {
        List<String> currentTabs=new ArrayList<String>(Session.getInstance().getDriver().getWindowHandles());

        Assertions.assertTrue(currentTabs.size()  == (Integer.parseInt(this.replaceConfigurationValues(oldValue))+comparingValue),
                "The current tabs opened: ["+currentTabs.size()+"] is not greater than the previous tabs number ["+this.replaceConfigurationValues(oldValue)+"] in "+comparingValue+" unit"  );
   }

    @And("close the browser")
    public void closeTheBrowser() throws InterruptedException {
        Session.getInstance().closeSession();
        Thread.sleep(3000);
    }

    @When("I get the logged user name on {}")
    public void iGetTheLoggedUserNameOnLoggerUser(String variable) throws Exception {
        String value=footerSection.getUserLogged();
        CommonValues.variables.put(variable,value);
        Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(variable)+"] in ["+variable+"]");
    }

    @And("i go to the default tab")
    public void iGoToTheDefaultTab() {
        ArrayList<String> tabs = new ArrayList<String>(Session.getInstance().getDriver().getWindowHandles());
        Logger.log(Level.INFO,this.getClass().getName()+"> go to the default tab: "+Session.getInstance().getDriver().switchTo().window(tabs.get(0)).getTitle());
        Session.getInstance().getDriver().switchTo().window(tabs.get(0));
    }

    @And("i save the {} date on {} with format {}")
    public void iSaveTheCurrentDateOnCurrentDate(String date,String variable, String format) {
        if (date.equals("yesterday")){
            DateFormat dateFormat = new SimpleDateFormat(format);
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DATE, -1);
            CommonValues.variables.put(variable, dateFormat.format(cal.getTime()));
        }else if (date.equals("tomorrow")){
            Date dt = new Date();
            Calendar c = Calendar.getInstance();
            c.setTime(dt);
            c.add(Calendar.DATE, 1);
            CommonValues.variables.put(variable, new SimpleDateFormat(format).format(c.getTime()));
        }else{
            //current
            CommonValues.variables.put(variable, new SimpleDateFormat(format).format(new Date()));
        }

        Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(variable)+"] in ["+variable+"]");
    }

    @And("i add {int} days from today in the variable {} with format {}")
    public void iCreateANewDate(int days, String variable, String format) {
        Date dt = new Date();
        Calendar c = Calendar.getInstance();
        c.setTime(dt);
        c.add(Calendar.DATE, days);
        CommonValues.variables.put(variable, new SimpleDateFormat(format).format(c.getTime()));
        Logger.log(Level.INFO, this.getClass().getName() + "> save the value: [" + CommonValues.variables.get(variable) + "] in [" + variable + "]");
    }


    @And("the case is {}")
    public void theCaseIsDetail(String detail) {
        Logger.log(Level.INFO,this.getClass().getName()+" detail for scenario outline"+detail);
    }

    @And("i save random phone number on {}")
    public void iSaveRandomPhoneNumberOnPHONE(String variable) {
        long theRandomNum = (long) (Math.random()*Math.pow(10,10));
        CommonValues.variables.put(variable, "(111)" + String.valueOf(theRandomNum).substring(3,6) + "-" + String.valueOf(theRandomNum).substring(6));
        Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(variable)+"] in ["+variable+"]");
    }

    @And("i save random {} characters string on {}")
    public void iSaveRandomCodeOnCODE(int iLength, String sVariable) {
        String sCodeChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        StringBuilder sbCode = new StringBuilder();
        Random random = new Random();
        for (int iCnt = 0; iCnt < iLength; iCnt++) {
            sbCode.append(sCodeChars.charAt(random.nextInt(sCodeChars.length())));
        }
        CommonValues.variables.put(sVariable, sbCode.toString());
        Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(sVariable)+"] in ["+sVariable+"]");
    }


    @Then("^verify the (information|center) alert (title|detail) should be$")
    public void verifyTheInformationAlertTitleShouldBe(String typeAlert,String section, String expectedResult) throws Exception {
        String actualResult="";
        expectedResult=this.replaceConfigurationValues(expectedResult);
        switch (typeAlert.toLowerCase()){
            case "information":
                actualResult=section.contains("title")?alertSection.infoTitleAlertLabel.getText():
                                                       alertSection.infoDetailAlertLabel.getText();
                break;
            case "center":
                actualResult=section.contains("title")?alertSection.centerTitleAlertLabel.getText():
                                                       alertSection.centerDetailAlertLabel.getText();
                break;

        }
        Assertions.assertTrue(actualResult.contains(expectedResult),"ERROR> actual result: ["+actualResult+"] does not have the expected result: ["+expectedResult+"]");
    }
    @Given("I get the current year in {word}")
    public void iGetTheCurrentYearInYear(String variableName) {
        String year = Year.now().getValue()+"";
        CommonValues.variables.put(variableName, year);
        Logger.log(Level.INFO,this.getClass().getName()+"> save current year value: ["+CommonValues.variables.get(variableName)+"] in ["+variableName+"]");
    }

    @And("^I get the current (alias environment|environment) in (.*)$")
    public void iGetTheCurrentEnvironmentInEnvironment(String type,String variableName) {
        String environment = GetProperties.getInstance().getEnvironment();
        // if we need to add new environment please add in the map the alias for each environment
        Map<String,String> aliasEnvironment= new HashMap<>();
        aliasEnvironment.put("qa","QAS");
        aliasEnvironment.put("staging","STAGING");

        if (type.contains("alias")) {
            CommonValues.variables.put(variableName, aliasEnvironment.get(environment));
        }else{
            CommonValues.variables.put(variableName, environment);
        }

        Logger.log(Level.INFO,this.getClass().getName()+"> save current environment value: ["+CommonValues.variables.get(variableName)+"] in ["+variableName+"]");
    }

    @And("I get the current user name in {word}")
    public void iGetTheCurrentUserNameInUserName(String variableName) {
        String user = GetProperties.getInstance().getUser().split("@")[0];
        CommonValues.variables.put(variableName, user);
        Logger.log(Level.INFO,this.getClass().getName()+"> save current user value: ["+CommonValues.variables.get(variableName)+"] in ["+variableName+"]");
    }
    @And("i save random {} digits number on {}")
    public void iSaveRandomDigitsNumberOnVariable(int iLen, String variable) {
        long theRandomNum = (long) (Math.random()*Math.pow(10, iLen));
        CommonValues.variables.put(variable,  String.valueOf(theRandomNum));
        Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(variable)+"] in ["+variable+"]");
    }

    @When("I wait {int} seconds")
    public void iWaitSeconds(int seconds) throws InterruptedException {
        Thread.sleep(seconds*1000);
    }

    @And("I compare the list actual: {} vs expected: {}")
    public void iCompareTheListPrefDeliveryListVsDisplayListDataBase(String actualResult, String expectedResult) {
        List<String> actualResultList = Arrays.asList(this.replaceConfigurationValues(actualResult).split(","));
        List<String> expectedResultList = Arrays.asList(this.replaceConfigurationValues(expectedResult).split(","));

        Assertions.assertTrue(actualResultList.containsAll(expectedResultList) && expectedResultList.containsAll(actualResultList),
                "ERROR! the actual result: ["+this.replaceConfigurationValues(actualResult)+ "] vs expected result: ["+
                        this.replaceConfigurationValues(expectedResult)+"] are different");

    }

    @Then("I check the list actual: {} contains expected: {}")
    public void iCheckTheListActualPrefDeliveryListContainsExpectedDisplayListDataBase(String actualResult, String expectedResult) {
            List<String> actualResultList = Arrays.asList(this.replaceConfigurationValues(actualResult).split(","));
            List<String> expectedResultList = Arrays.asList(this.replaceConfigurationValues(expectedResult).split(","));

        for (String expected: expectedResultList) {
            expected=expected.replace("[","").replace("]","");
            boolean exist = false;
            for ( String actual :actualResultList
                 ) {
                    expected = expected.replace(" ","");
                    actual = actual.replace(" ","");
                    if (expected.equals("PostalMail")) {
                        expected = "Email";
                    }
                    if (actual.contains(expected))
                        exist=true;
            }
            Assertions.assertTrue(exist ,
                    "ERROR! the actual result: ["+actualResultList+ "] does not contains expected result: ["+
                            expected+"]");
        }
    }

    @And("I verify the value of: {} equals the value of: {}")
    public void verifyTwoEqualValues(String firstValue, String secondValue) throws Exception {
        Assertions.assertEquals(this.replaceConfigurationValues(firstValue),this.replaceConfigurationValues(secondValue),
                "ERROR> The first parameter: "+this.replaceConfigurationValues(firstValue)+ " doesn't match the second parameter: "+this.replaceConfigurationValues(secondValue));
    }

    @And("I save the Today date of EST timezone on {}")
    public void iSaveTheCurrentDateOfESTTimeZone(String variable) {
        CommonValues.variables.put(variable, DateUtils.getCurrentDateOfESTTimeZone());
        Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(variable)+"] in ["+variable+"]");
    }

    /*
    * This method is only for requirement when we need to create a policy  using some market channel with random data
    * */
    @Given("creating policy in order to get policy Id on {} using")
    public void createPolicyInOrderToGetPolicyIdOnVariableUsing(String variable, Map<String,String> requirementForPolicy ) {
        CreatePolicyRequirement createPolicyRequirement = new CreatePolicyRequirement();
        createPolicyRequirement.setBreedName(requirementForPolicy.get("petBreed"))
                               .setPetType(requirementForPolicy.get("petType").contains("dog")?"1":"2")
                               .setPostalCode(requirementForPolicy.get("zipCode"))
                               .setMarketChannelName(requirementForPolicy.get("marketChannelName"));

        if (requirementForPolicy.containsKey("email"))
            createPolicyRequirement.seEmailRandomValue(this.replaceConfigurationValues(requirementForPolicy.get("email")));

        createPolicyRequirement.setOrcaUser(GetProperties.getInstance().getUser())
                .setOrcaPassword(GetProperties.getInstance().getPassword())
                .setAppName("orca")
                .setGatewayUrl(GetProperties.getInstance().getGatewayUrl())
                .setHostApi(GetProperties.getInstance().getApiHost())
                .setTrustCommerce(GetProperties.getInstance().getTrustCommerce());

        String policyId = createPolicyRequirement.getPolicyIdByApi();
        CommonValues.variables.put(variable,  policyId);
        Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(variable)+"] in ["+variable+"]");
    }
}
