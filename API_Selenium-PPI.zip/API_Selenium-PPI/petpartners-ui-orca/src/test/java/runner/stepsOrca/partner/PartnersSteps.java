package runner.stepsOrca.partner;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orca.partner.PartnersPage;
import runner.BaseSteps;

import java.util.List;
import java.util.Map;
import java.util.Objects;

public class PartnersSteps extends BaseSteps {
    PartnersPage partnersPage = new PartnersPage();
    @And("I click Add Partner link in the left menu")
    public void iClickAddPartnerLinkInTheLeftMenu() throws Exception {
        partnersPage.addPartnerLink.click();
    }

    @When("I Enter the Partner Name to textBox")
    public void iEnterThePartnerNameToTextBox(Map<String, String> controlsValue) throws Exception {
        partnersPage.partnerNameTextBox.setText(this.replaceConfigurationValues(controlsValue.get("DisplayValue")));
    }

    @And("I Click [{string}] button in Partners page")
    public void iClickButtonInPartnersPage(String value) throws Exception {
        partnersPage.partnersRunSearchButton.click();
    }

    @And("I click the link on partners search results Table")
    public void iClickTheLinkOnPartnersSearchResultsTable(Map<String, String> controlsValue) throws Exception {
        partnersPage.partnerResultTable.clickOnLinkCell(this.replaceConfigurationValues(controlsValue.get("DisplayValue")));
    }

    @And("I search on Partner Search Page using")
    public void searchingOnPartnerSearchPageUsing(Map<String, String> controlsValue) throws Exception {
        for (String control: controlsValue.keySet()
        ) {
            if (!partnersPage.textBoxMap.containsKey(control) && !Objects.equals(control, "Market Channel"))
                throw new Exception("The control: "+control+" is not present. There is no field related.");
            if(Objects.equals(control, "Market Channel")){
                if (!partnersPage.marketChannelSelect.getAllValuesCommaSeparated().contains(this.replaceConfigurationValues(controlsValue.get(control)))){
                    throw new Exception("The market channel: "+this.replaceConfigurationValues(controlsValue.get(control))+" is not present, not able to select.");
                }
                partnersPage.marketChannelSelect.selectValueContainsOption(this.replaceConfigurationValues(controlsValue.get(control)));
            } else {
            partnersPage.textBoxMap.get(control).setText(this.replaceConfigurationValues(controlsValue.get(control)));}
        }
        partnersPage.partnersRunSearchButton.controlIsClickable();
        partnersPage.partnersRunSearchButton.click();
    }

    @And("I Clear search fields in Partner Search Page")
    public void clearSearchFields() throws Exception {
        partnersPage.clearSearchButton.click();
    }

    @Then("I verify that all Partners displayed in Partner Search Result Table contains {string} in column")
    public void iVerifyThatAllPartnersDisplayedContainsInColumn(String searchCondition, String column) throws Exception {
        partnersPage.amountOfResultsSelect.selectValue("All Rows");
        List<String> columnItems = partnersPage.partnerResultTable.getEntireColumn(this.replaceConfigurationValues(column));
        for (String item : columnItems){
            item = item.toLowerCase();
            Assertions.assertTrue(item.contains(this.replaceConfigurationValues(searchCondition).toLowerCase()),"ERROR> Partner: "+item+" does not contains: "+this.replaceConfigurationValues(searchCondition));
        }
    }
}
