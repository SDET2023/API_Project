package runner;

import configuration.CommonValues;
import configuration.Configuration;
import org.openqa.selenium.JavascriptExecutor;
import pages.orca.common.*;
import session.Session;
import utils.Level;
import utils.Logger;
import java.util.*;

public class BaseSteps {
    protected FooterSection footerSection= new FooterSection();
    protected MenuSection menuSection = new MenuSection();
    protected SubMenuSection subMenuSection= new SubMenuSection();
    protected AlertSection alertSection= new AlertSection();

    protected LoadingSection loadingSection = new LoadingSection();
    public List<String> queryResult= new ArrayList<>();
    public BaseSteps(){

    }

    public String replaceConfigurationValues(String value){
        for (String key: CommonValues.variables.keySet()
             ) {
            value=value.replace(key,CommonValues.variables.get(key));
        }
        return value.replace(CommonValues.DEFAULT_USER, Configuration.USER)
                    .replace(CommonValues.HELPER_FILES,CommonValues.getHelperFilesValue())
                    .replace(CommonValues.DEFAULT_PWD,Configuration.PASSWORD);

    }

    public void scrollDown(){
        Logger.log(Level.INFO,this.getClass().getName()+"> Scroll Down Action "+this.getClass().getSimpleName());
        JavascriptExecutor js = (JavascriptExecutor) Session.getInstance().getDriver();
        js.executeScript("window.scrollBy(0,500)");
    }

    public void scrollUp(){
        Logger.log(Level.INFO,this.getClass().getName()+"> scroll up");
        JavascriptExecutor js = (JavascriptExecutor) Session.getInstance().getDriver();
        js.executeScript("window.scrollBy(0,-400)");
    }

    public void scrollDownTillPageEnd(){
        Logger.log(Level.INFO,this.getClass().getName()+"> scroll down till page end");
        JavascriptExecutor js = (JavascriptExecutor) Session.getInstance().getDriver();
        js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
    }
}
