package helpers;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class GetProperties {
    private static GetProperties getProperties = null;
    private String urlWeb;
    private String urlWebPPI;
    private String user;
    private String password;
    private String browser;

    private String urlWebAkc;


    private String sqlServer;
    private String sqlDB;
    private String sqlUser;
    private String sqlPassword;

    private String urlWebOrcaGroup;

    private Boolean generateGifImage;
    private String environment;
    private String apiHost;
    private String gatewayUrl;
    private String trustCommerce;

    private boolean isEnabledOrcaMfa;

    // User with specific roles

    private String claimUser;
    private String claimPassword;
    private String claimAuditUser;
    private String claimAuditPassword;
    private String salesUser;
    private String salesPassword;
    private String retentionAgentUser;
    private String retentionAgentPassword;
    private String customerUser;
    private String customerPassword;

    private GetProperties() {
        Properties properties = new Properties();
        String propFileName = System.getProperty("propertyFile") == null ? "qa.properties" : System.getProperty("propertyFile");
        environment = propFileName.replace(".properties", "");
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);
        if (inputStream != null) {
            try {
                properties.load(inputStream);
                urlWeb = properties.getProperty("urlWeb");
                user = properties.getProperty("user");
                password = properties.getProperty("password");

                browser = properties.getProperty("browser");
                urlWebPPI = properties.getProperty("urlWebPPI");
                urlWebAkc = properties.getProperty("urlWebAKC");
                sqlServer = properties.getProperty("sqlServer");
                sqlDB = properties.getProperty("sqlDB");
                sqlUser = properties.getProperty("sqlUser");
                sqlPassword = properties.getProperty("sqlPassword");
                urlWebOrcaGroup = properties.getProperty("urlWebOrcaGroup");

                generateGifImage = Boolean.parseBoolean(properties.getProperty("generateGifImage"));
                apiHost = properties.getProperty("apiHost");
                gatewayUrl = properties.getProperty("gatewayUrl");
                trustCommerce = properties.getProperty("trustCommerce");

                isEnabledOrcaMfa = Boolean.parseBoolean(properties.getProperty("isEnabledOrcaMFA"));

                claimUser = properties.getProperty("claimUser");
                claimPassword = properties.getProperty("claimPassword");
                claimAuditUser = properties.getProperty("claimAuditUser");
                claimAuditPassword = properties.getProperty("claimAuditPassword");
                salesUser = properties.getProperty("salesUser");
                salesPassword = properties.getProperty("salesPassword");
                retentionAgentUser = properties.getProperty("retentionAgentUser");
                retentionAgentPassword = properties.getProperty("retentionAgentPassword");
                customerUser = properties.getProperty("customerUser");
                customerPassword = properties.getProperty("customerPassword");

                inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    public static GetProperties getInstance() {
        if (getProperties == null)
            getProperties = new GetProperties();
        return getProperties;
    }

    public String getUrlWebOrcaGroup() {
        return urlWebOrcaGroup;
    }

    public String getUrlWeb() {
        return urlWeb;
    }

    public String getUrlWebAkc() {
        return urlWebAkc;
    }

    public String getUser() {
        return user;
    }

    public String getPassword() {
        return password;
    }

    public String getClaimUser() {
        return claimUser;
    }

    public String getClaimPassword() {
        return claimPassword;
    }

    public String getClaimAuditUser() {
        return claimAuditUser;
    }

    public String getClaimAuditPassword() {
        return claimAuditPassword;
    }

    public String getBrowser() {
        return browser;
    }

    public String getUrlWebPPI() {
        return urlWebPPI;
    }

    public String getSqlServer() {
        return sqlServer;
    }

    public String getSqlDB() {
        return sqlDB;
    }

    public String getSqlUser() {
        return sqlUser;
    }

    public String getSqlPassword() {
        return sqlPassword;
    }

    public Boolean getGenerateGifImage() {
        return generateGifImage;
    }

    public String getEnvironment() {
        return environment;
    }

    public String getApiHost() {
        return apiHost;
    }

    public boolean isEnabledOrcaMfa() {
        return isEnabledOrcaMfa;
    }

    public String getSalesUser() {
        return salesUser;
    }

    public String getSalesPassword() {
        return salesPassword;
    }

    public String getRetentionAgentUser() {
        return retentionAgentUser;
    }

    public String getRetentionAgentPassword() {
        return retentionAgentPassword;
    }

    public String getCustomerUser() {
        return customerUser;
    }

    public String getCustomerPassword() {
        return customerPassword;
    }


    public String getGatewayUrl() {
        return gatewayUrl;
    }

    public String getTrustCommerce() {
        return trustCommerce;
    }

}

