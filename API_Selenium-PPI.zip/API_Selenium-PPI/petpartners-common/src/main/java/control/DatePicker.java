package control;

import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class DatePicker extends ControlBase {

    public Select monthSelect = new Select(By.xpath("//select[@class='ui-datepicker-month']"));
    public Select yearSelect = new Select(By.xpath("//select[@class='ui-datepicker-year']"));
    public Button previousButton = new Button(By.xpath("//span[text()='Prev']"));
    public Button nextButton = new Button(By.xpath("//span[text()='Next']"));
    private Button dayButton;

    public DatePicker(By locator) {
        super(locator);
    }

    public void selectDate(String month, String year, String day) throws Exception {
        Logger.log(Level.INFO, this.getClass().getName() + "> Select Date on [" + this.locator + "] " + this.getClass().getSimpleName() + " the value: [" + month + "/" + day + "/" + day + "]");
        this.click();
        monthSelect.selectValue(month);
        yearSelect.selectValue(year);
        yearSelect.click();
        dayButton = new Button(By.xpath("//a[@href='#' and text()='" + day + "']"));
        dayButton.click();
    }

    public void clickDayButton(String day) throws Exception {
        dayButton = new Button(By.xpath("//a[@class='ui-state-default' and text()='" + day + "']"));
        dayButton.click();
    }


//    public void selectDateCalendar(String date) throws Exception {
//        Logger.log(Level.INFO,this.getClass().getName()+"> Select Date on ["+this.locator+"] "+ this.getClass().getSimpleName()+" the value: ["+month+"/"+day+"/"+day+"]");
//        this.click();
//        monthSelect.selectValue(month);
//        yearSelect.selectValue(year);
//        yearSelect.click();
//        dayButton = new Button(By.xpath("//a[@href='#' and text()='"+day+"']"));
//        dayButton.click();
//    }


}
