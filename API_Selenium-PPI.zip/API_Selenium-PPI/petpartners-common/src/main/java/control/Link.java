package control;

import org.openqa.selenium.By;

public class Link extends ControlBase {

    public Link(By locator) {
        super(locator);
    }

}
