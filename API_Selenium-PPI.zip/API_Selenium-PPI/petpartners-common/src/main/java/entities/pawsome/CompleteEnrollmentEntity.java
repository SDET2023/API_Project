package entities.pawsome;

public class CompleteEnrollmentEntity {

    public String firstName = "";
    public String lastName = "";
    public String address = "";
    public String aptSuiteEtc = "";
    public String city = "";
    public String state = "";
    public String zipCode = "";
    public String phoneNumber = "";
    public String emailAddress = "";
    public String groupCode = "";
    public String nameOnCard = "";
    public String cardNumber = "";
    public String expiresMM = "";
    public String expiresYYYY = "";
    public String expiresCVC = "";
    public String iAggreToGoPaperless = "";
    public String iAgreeThatByChecking = "";

    public boolean isUsingDifferentBilling = false;
    public String differentAddress = "";
    public String differentAptSuiteEtc = "";
    public String differentCity = "";
    public String differentState = "";
    public String differentZipCode = "";

    public CompleteEnrollmentEntity() {
    }

    public CompleteEnrollmentEntity setFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    public CompleteEnrollmentEntity setLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    public CompleteEnrollmentEntity setAddress(String address) {
        this.address = address;
        return this;
    }

    public CompleteEnrollmentEntity setAptSuiteEtc(String aptSuiteEtc) {
        this.aptSuiteEtc = aptSuiteEtc;
        return this;
    }

    public CompleteEnrollmentEntity setCity(String city) {
        this.city = city;
        return this;
    }

    public CompleteEnrollmentEntity setState(String state) {
        this.state = state;
        return this;
    }

    public CompleteEnrollmentEntity setZipCode(String zipCode) {
        this.zipCode = zipCode;
        return this;
    }

    public CompleteEnrollmentEntity setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
        return this;
    }

    public CompleteEnrollmentEntity setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
        return this;
    }

    public CompleteEnrollmentEntity setGroupCode(String groupCode) {
        this.groupCode = groupCode;
        return this;
    }

    public CompleteEnrollmentEntity setNameOnCard(String nameOnCard) {
        this.nameOnCard = nameOnCard;
        return this;
    }

    public CompleteEnrollmentEntity setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
        return this;
    }

    public CompleteEnrollmentEntity setExpiresMM(String expiresMM) {
        this.expiresMM = expiresMM;
        return this;
    }

    public CompleteEnrollmentEntity setExpiresYYYY(String expiresYYYY) {
        this.expiresYYYY = expiresYYYY;
        return this;
    }

    public CompleteEnrollmentEntity setExpiresCVC(String expiresCVC) {
        this.expiresCVC = expiresCVC;
        return this;
    }

    public CompleteEnrollmentEntity setiAggreToGoPaperless(String iAggreToGoPaperless) {
        this.iAggreToGoPaperless = iAggreToGoPaperless;
        return this;
    }

    public CompleteEnrollmentEntity setiAgreeThatByChecking(String iAgreeThatByChecking) {
        this.iAgreeThatByChecking = iAgreeThatByChecking;
        return this;
    }

    public CompleteEnrollmentEntity setUsingDifferentBilling(boolean usingDifferentBilling) {
        isUsingDifferentBilling = usingDifferentBilling;
        return this;
    }

    public CompleteEnrollmentEntity setDifferentAddress(String differentAddress) {
        this.differentAddress = differentAddress;
        return this;
    }

    public CompleteEnrollmentEntity setDifferentAptSuiteEtc(String differentAptSuiteEtc) {
        this.differentAptSuiteEtc = differentAptSuiteEtc;
        return this;
    }

    public CompleteEnrollmentEntity setDifferentCity(String differentCity) {
        this.differentCity = differentCity;
        return this;
    }

    public CompleteEnrollmentEntity setDifferentState(String differentState) {
        this.differentState = differentState;
        return this;
    }

    public CompleteEnrollmentEntity setDifferentZipCode(String differentZipCode) {
        this.differentZipCode = differentZipCode;
        return this;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getAddress() {
        return address;
    }

    public String getAptSuiteEtc() {
        return aptSuiteEtc;
    }

    public String getCity() {
        return city;
    }

    public String getState() {
        return state;
    }

    public String getZipCode() {
        return zipCode;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public String getNameOnCard() {
        return nameOnCard;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public String getExpiresMM() {
        return expiresMM;
    }

    public String getExpiresYYYY() {
        return expiresYYYY;
    }

    public String getExpiresCVC() {
        return expiresCVC;
    }

    public String getiAggreToGoPaperless() {
        return iAggreToGoPaperless;
    }

    public String getiAgreeThatByChecking() {
        return iAgreeThatByChecking;
    }

    public boolean isUsingDifferentBilling() {
        return isUsingDifferentBilling;
    }

    public String getDifferentAddress() {
        return differentAddress;
    }

    public String getDifferentAptSuiteEtc() {
        return differentAptSuiteEtc;
    }

    public String getDifferentCity() {
        return differentCity;
    }

    public String getDifferentState() {
        return differentState;
    }

    public String getDifferentZipCode() {
        return differentZipCode;
    }
}
