package entities.pawsome;

public class GetQuoteEntity {

    public String petName = "";
    public String zipCode = "";
    public String petType = "";
    public String petBreed = "";
    public String petAge = "";
    public String hasYourPetEverBeenDiagnosed = "";
    public String emailAddress = "";

    public String registrationNumberCertificate = "";
    public String zipCodeCertificate = "";

    public GetQuoteEntity() {
    }

    public GetQuoteEntity setPetName(String petName) {
        this.petName = petName;
        return this;
    }

    public GetQuoteEntity setZipCode(String zipCode) {
        this.zipCode = zipCode;
        return this;
    }

    public GetQuoteEntity setPetType(String petType) {
        this.petType = petType;
        return this;
    }

    public GetQuoteEntity setPetBreed(String petBreed) {
        this.petBreed = petBreed;
        return this;
    }

    public GetQuoteEntity setPetAge(String petAge) {
        this.petAge = petAge;
        return this;
    }

    public GetQuoteEntity setHasYourPetEverBeenDiagnosed(String hasYourPetEverBeenDiagnosed) {
        this.hasYourPetEverBeenDiagnosed = hasYourPetEverBeenDiagnosed;
        return this;
    }

    public GetQuoteEntity setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
        return this;
    }

    public GetQuoteEntity setRegistrationNumberCertificate(String registrationNumberCertificate) {
        this.registrationNumberCertificate = registrationNumberCertificate;
        return this;
    }

    public GetQuoteEntity setZipCodeCertificate(String zipCodeCertificate) {
        this.zipCodeCertificate = zipCodeCertificate;
        return this;
    }

    public String getPetName() {
        return petName;
    }

    public String getZipCode() {
        return zipCode;
    }

    public String getPetType() {
        return petType;
    }

    public String getPetBreed() {
        return petBreed;
    }

    public String getPetAge() {
        return petAge;
    }

    public String getHasYourPetEverBeenDiagnosed() {
        return hasYourPetEverBeenDiagnosed;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public String getRegistrationNumberCertificate() {
        return registrationNumberCertificate;
    }

    public String getZipCodeCertificate() {
        return zipCodeCertificate;
    }
}
