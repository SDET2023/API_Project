package entities.akc;

public class ClaimEntity {

    private String selectPolicy;
    private String doesYourPetHaveAdditional;
    private String injuryOrIllness;
    private String wellness;
    private String tellUsMoreAboutInjury;
    private String whenDidYuFirstNoticeSignDate;
    private String treatmentStartDate;
    private String uploadFile;

    public ClaimEntity() {
    }

    public String getSelectPolicy() {
        return selectPolicy;
    }

    public ClaimEntity setSelectPolicy(String selectPolicy) {
        this.selectPolicy = selectPolicy;
        return this;
    }

    public String getDoesYourPetHaveAdditional() {
        return doesYourPetHaveAdditional;
    }

    public ClaimEntity setDoesYourPetHaveAdditional(String doesYourPetHaveAdditional) {
        this.doesYourPetHaveAdditional = doesYourPetHaveAdditional;
        return this;
    }

    public String getInjuryOrIllness() {
        return injuryOrIllness;
    }

    public ClaimEntity setInjuryOrIllness(String injuryOrIllness) {
        this.injuryOrIllness = injuryOrIllness;
        return this;
    }

    public String getWellness() {
        return wellness;
    }

    public ClaimEntity setWellness(String wellness) {
        this.wellness = wellness;
        return this;
    }

    public String getTellUsMoreAboutInjury() {
        return tellUsMoreAboutInjury;
    }

    public ClaimEntity setTellUsMoreAboutInjury(String tellUsMoreAboutInjury) {
        this.tellUsMoreAboutInjury = tellUsMoreAboutInjury;
        return this;
    }

    public String getWhenDidYuFirstNoticeSignDate() {
        return whenDidYuFirstNoticeSignDate;
    }

    public ClaimEntity setWhenDidYuFirstNoticeSignDate(String whenDidYuFirstNoticeSignDate) {
        this.whenDidYuFirstNoticeSignDate = whenDidYuFirstNoticeSignDate;
        return this;
    }

    public String getTreatmentStartDate() {
        return treatmentStartDate;
    }

    public ClaimEntity setTreatmentStartDate(String treatmentStartDate) {
        this.treatmentStartDate = treatmentStartDate;
        return this;
    }

    public String getUploadFile() {
        return uploadFile;
    }

    public ClaimEntity setUploadFile(String uploadFile) {
        this.uploadFile = uploadFile;
        return this;
    }
}
