package entities.ppi;

public class ChangeCoverageEntity {
    public String planDetail = "";
    public String deductible = "";
    public String coinsurance = "";
    public String annualLimit = "";

    public ChangeCoverageEntity() {
    }

    public ChangeCoverageEntity setPlanDetail(String planDetail) {
        this.planDetail = planDetail;
        return this;
    }

    public ChangeCoverageEntity setDeductible(String deductible) {
        this.deductible = deductible;
        return this;
    }

    public ChangeCoverageEntity setCoinsurance(String coinsurance) {
        this.coinsurance = coinsurance;
        return this;
    }

    public ChangeCoverageEntity setAnnualLimit(String annualLimit) {
        this.annualLimit = annualLimit;
        return this;
    }

    public String getPlanDetail() {
        return planDetail;
    }

    public String getDeductible() {
        return deductible;
    }

    public String getCoinsurance() {
        return coinsurance;
    }

    public String getAnnualLimit() {
        return annualLimit;
    }


}
