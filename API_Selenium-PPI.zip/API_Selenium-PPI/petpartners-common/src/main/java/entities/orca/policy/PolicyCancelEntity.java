package entities.orca.policy;

public class PolicyCancelEntity {
    private String cancelRequestOnTextBox = "";

    private String cancelReasonDropdown = "";

    private String cancelNotesTextBox = "";

    private String cancelTypeDropdown = "";

    public PolicyCancelEntity() {
    }

    public void setCancelRequestOnTextBox(String cancelRequestOnTextBox) {
        this.cancelRequestOnTextBox = cancelRequestOnTextBox;
    }

    public void setCancelReasonDropdown(String cancelReasonDropdown) {
        this.cancelReasonDropdown = cancelReasonDropdown;
    }

    public void setCancelNotesTextBox(String cancelNotesTextBox) {
        this.cancelNotesTextBox = cancelNotesTextBox;
    }

    public void setCancelTypeDropdown(String cancelTypeDropdown) {
        this.cancelTypeDropdown = cancelTypeDropdown;
    }

    public String getCancelReasonDropdown() {
        return cancelReasonDropdown;
    }

    public String getCancelNotesTextBox() {
        return cancelNotesTextBox;
    }

    public String getCancelTypeDropdown() {
        return cancelTypeDropdown;
    }

    public String getCancelRequestOnTextBox() {
        return cancelRequestOnTextBox;
    }
}
