package entities.orca.policy;

public class PolicySearchEntity {
    private String marketChannel = "";
    private String policyNumber = "";
    private String postalCode = "";

    private String emailAddress = "";

    private String lastName = "";

    private String billingId = "";

    private String phoneNum = "";

    private String registrationNumber = "";

    private String linkedPolicy = "";

    private String petName = "";

    public PolicySearchEntity() {
    }

    public void setLinkedPolicy(String linkedPolicy) {
        this.linkedPolicy = linkedPolicy;
    }

    public String getLinkedPolicy() {
        return linkedPolicy;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public void setBillingId(String billingId) {
        this.billingId = billingId;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public String getBillingId() {
        return billingId;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public String getMarketChannel() {
        return marketChannel;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setMarketChannel(String marketChannel) {
        this.marketChannel = marketChannel;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getPetName() {
        return petName;
    }

    public void setPetName(String petName) {
        this.petName = petName;
    }
}


