package entities.orca.followUp;

public class FollowUpDetailEntity {

    private String assignedTo="";
    private String followUpType="";
    private String complaintType="";
    private String followUpBy="";
    private String receivedOn="";
    private String closedOn="";
    private String summary="";
    private String resolution="";

    public FollowUpDetailEntity(){
    }

    public String getAssignedTo() {
        return assignedTo;
    }

    public String getFollowUpType() {
        return followUpType;
    }

    public String getComplaintType() {
        return complaintType;
    }

    public String getFollowUpBy() {
        return followUpBy;
    }

    public String getReceivedOn() {
        return receivedOn;
    }

    public String getClosedOn() {
        return closedOn;
    }

    public String getSummary() {
        return summary;
    }

    public String getResolution() {
        return resolution;
    }

    public FollowUpDetailEntity setAssignedTo(String assignedTo) {
        this.assignedTo = assignedTo;
        return this;
    }

    public FollowUpDetailEntity setFollowUpType(String followUpType) {
        this.followUpType = followUpType;
        return this;
    }

    public FollowUpDetailEntity setComplaintType(String complaintType) {
        this.complaintType = complaintType;
        return this;
    }

    public FollowUpDetailEntity setFollowUpBy(String followUpBy) {
        this.followUpBy = followUpBy;
        return this;
    }

    public FollowUpDetailEntity setReceivedOn(String receivedOn) {
        this.receivedOn = receivedOn;
        return this;
    }

    public FollowUpDetailEntity setClosedOn(String closedOn) {
        this.closedOn = closedOn;
        return this;
    }

    public FollowUpDetailEntity setSummary(String summary) {
        this.summary = summary;
        return this;
    }

    public FollowUpDetailEntity setResolution(String resolution) {
        this.resolution = resolution;
        return this;
    }
}
