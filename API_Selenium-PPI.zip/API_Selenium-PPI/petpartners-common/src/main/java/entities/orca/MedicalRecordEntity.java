package entities.orca;

public class MedicalRecordEntity {

    private String requestTypeDropdown ="";

    private String pet ="";

    private String vet ="";

    private String requestSearch = "";

    public String getRequestTypeDropdown() {
        return requestTypeDropdown;
    }

    public void setRequestTypeDropdown(String requestTypeDropdown) {
        this.requestTypeDropdown = requestTypeDropdown;
    }

    public String getPet() {
        return pet;
    }

    public void setPet(String pet) {
        this.pet = pet;
    }

    public String getVet() {
        return vet;
    }

    public void setVet(String vet) {
        this.vet = vet;
    }

    public String getRequestSearch() {
        return requestSearch;
    }

    public void setRequestSearch(String requestSearch) {
        this.requestSearch = requestSearch;
    }

    public MedicalRecordEntity(){


    }
}
