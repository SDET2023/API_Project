package entities.orca.makeChanges;

public class MakeChangesProductEntity {

    public String covProdType = "";

    //CompanionCare Product Upgrades
    public String covHereditaryPlus = "";
    public String covSupportPlus = "";
    public String covAlternativePlus = "";
    public String covBreedingCoverage = "";
    public String covExamPlus = "";
    public String covDefender = "";
    public String covDefenderPlus = "";

    public MakeChangesProductEntity() {
    }


    public String getCovProdType() {
        return covProdType;
    }

    public MakeChangesProductEntity setCovProdType(String covProdType) {
        this.covProdType = covProdType;
        return this;
    }

    //Make Changes - Product Upgrades
    public String getCovHereditaryPlus() {
        return covHereditaryPlus;
    }

    public MakeChangesProductEntity setCovHereditaryPlus(String covHereditaryPlus) {
        this.covHereditaryPlus = covHereditaryPlus;
        return this;
    }

    public String getCovSupportPlus() {
        return covSupportPlus;
    }

    public MakeChangesProductEntity setCovSupportPlus(String covSupportPlus) {
        this.covSupportPlus = covSupportPlus;
        return this;
    }

    public String getCovBreedingCoverage() {
        return covBreedingCoverage;
    }

    public MakeChangesProductEntity setCovBreedingCoverage(String covBreedingCoverage) {
        this.covBreedingCoverage = covBreedingCoverage;
        return this;
    }

    public String getCovAlternativePlus() {
        return covAlternativePlus;
    }

    public MakeChangesProductEntity setCovAlternativePlus(String covAlternativePlus) {
        this.covAlternativePlus = covAlternativePlus;
        return this;
    }

    public String getCovExamPlus() {
        return covExamPlus;
    }

    public MakeChangesProductEntity setCovExamPlus(String covExamPlus) {
        this.covExamPlus = covExamPlus;
        return this;
    }

    public String getCovDefender() {
        return covDefender;
    }

    public MakeChangesProductEntity setCovDefender(String covDefender) {
        this.covDefender = covDefender;
        return this;
    }

    public String getCovDefenderPlus() {
        return covDefenderPlus;
    }

    public MakeChangesProductEntity setCovDefenderPlus(String covDefenderPlus) {
        this.covDefenderPlus = covDefenderPlus;
        return this;
    }

}

