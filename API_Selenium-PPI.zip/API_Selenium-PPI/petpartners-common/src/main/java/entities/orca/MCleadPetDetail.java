package entities.orca;

public class MCleadPetDetail {
    public String registrationNo = "";
    public String registrationDate = "";
    public String dateOfBirth = "";
    public String color = "";
    public String marketChannel = "";
    public String partner = "";
    public String petName = "";
    public String species = "";
    public String breed = "";
    public String gender = "";
    public String soldDate = "";

    public MCleadPetDetail() {
    }

    public MCleadPetDetail setRegistrationNo(String registrationNo) {
        this.registrationNo = registrationNo;
        return this;
    }

    public MCleadPetDetail setRegistrationDate(String registrationDate) {
        this.registrationDate = registrationDate;
        return this;
    }

    public MCleadPetDetail setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
        return this;
    }

    public MCleadPetDetail setColor(String color) {
        this.color = color;
        return this;
    }

    public MCleadPetDetail setMarketChannel(String marketChannel) {
        this.marketChannel = marketChannel;
        return this;
    }

    public MCleadPetDetail setPartner(String partner) {
        this.partner = partner;
        return this;
    }

    public MCleadPetDetail setPetName(String petName) {
        this.petName = petName;
        return this;
    }

    public MCleadPetDetail setSpecies(String species) {
        this.species = species;
        return this;
    }

    public MCleadPetDetail setBreed(String breed) {
        this.breed = breed;
        return this;
    }

    public MCleadPetDetail setGender(String gender) {
        this.gender = gender;
        return this;
    }
    public MCleadPetDetail setSoldDate(String soldDate) {
        this.soldDate = soldDate;
        return this;
    }

    public String getRegistrationNo() {
        return registrationNo;
    }

    public String getRegistrationDate() {
        return registrationDate;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public String getColor() {
        return color;
    }

    public String getMarketChannel() {
        return marketChannel;
    }

    public String getPartner() {
        return partner;
    }

    public String getPetName() {
        return petName;
    }

    public String getSpecies() {
        return species;
    }

    public String getBreed() {
        return breed;
    }

    public String getGender() {
        return gender;
    }

    public String getSoldDate() {
        return soldDate;
    }
}
