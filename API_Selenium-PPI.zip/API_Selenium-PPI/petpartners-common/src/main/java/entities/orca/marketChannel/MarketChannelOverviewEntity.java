package entities.orca.marketChannel;

public class MarketChannelOverviewEntity {
    //Market Channel Overview Details
    public String mcName = "";
    public String mcCode = "";
    public String mcDisplay = "";
    public String mcTrial = "";
    public String mcTerms = "";
    public String mcAdd1 = "";
    public String mcAdd2 = "";
    public String mcCity = "";
    public String mcState = "";
    public String mcPostal = "";
    public String mcPhone = "";
    public String mcFax = "";
    public String mcEmailFromName = "";
    public String mcEmailFromAdd = "";
    public String mcClaimEmailFromAdd = "";
    public String mcWebsite = "";

    /*
    * Group Info
    * */

    private String groupPhoneNumber="";
    private String groupEmailFromAddress="";
    private String groupClaimEmailFromAddress="";
    private String groupWebsite="";

    public MarketChannelOverviewEntity() {
    }

    public String getMktChnlName() {
        return mcName;
    }

    public MarketChannelOverviewEntity setMktChnlName(String mcName) {
        this.mcName = mcName;
        return this;
    }

    public String getMktChnlCode() {
        return mcCode;
    }

    public MarketChannelOverviewEntity setMktChnlCode(String mcCode) {
        this.mcCode = mcCode;
        return this;
    }

    public String getMktChnlDisplay() {
        return mcDisplay;
    }

    public MarketChannelOverviewEntity setMktChnlDisplay(String mcDisplay) {
        this.mcDisplay = mcDisplay;
        return this;
    }

    public String getMktChnlTrial() {
        return mcTrial;
    }

    public MarketChannelOverviewEntity setMktChnlTrial(String mcTrial) {
        this.mcTrial = mcTrial;
        return this;
    }

    public String getMktChnlTerms() {
        return mcTerms;
    }

    public MarketChannelOverviewEntity setMktChnlTerms(String mcTerms) {
        this.mcTerms = mcTerms;
        return this;
    }

    public String getMktChnlAdd1() {
        return mcAdd1;
    }

    public MarketChannelOverviewEntity setMktChnlAdd1(String mcAdd1) {
        this.mcAdd1 = mcAdd1;
        return this;
    }

    public String getMktChnlAdd2() {
        return mcAdd2;
    }

    public MarketChannelOverviewEntity setMktChnlAdd2(String mcAdd2) {
        this.mcAdd2 = mcAdd2;
        return this;
    }

    public String getMktChnlCity() {
        return mcCity;
    }

    public MarketChannelOverviewEntity setMktChnlCity(String mcCity) {
        this.mcCity = mcCity;
        return this;
    }

    public String getMktChnlState() {
        return mcState;
    }

    public MarketChannelOverviewEntity setMktChnlState(String mcState) {
        this.mcState = mcState;
        return this;
    }

    public String getMktChnlPostal() {
        return mcPostal;
    }

    public MarketChannelOverviewEntity setMktChnlPostal(String mcPostal) {
        this.mcPostal = mcPostal;
        return this;
    }

    public String getMktChnlPhone() {
        return mcPhone;
    }

    public MarketChannelOverviewEntity setMktChnlPhone(String mcPhone) {
        this.mcPhone = mcPhone;
        return this;
    }

    public String getMktChnlFax() {
        return mcFax;
    }

    public MarketChannelOverviewEntity setMktChnlFax(String mcFax) {
        this.mcFax = mcFax;
        return this;
    }

    public String getMktChnlEmailFromName() {
        return mcEmailFromName;
    }

    public MarketChannelOverviewEntity setMktChnlEmailFromName(String mcEmailFromName) {
        this.mcEmailFromName = mcEmailFromName;
        return this;
    }

    public String getMktChnlEmailFromAdd() {
        return mcEmailFromAdd;
    }

    public MarketChannelOverviewEntity setMktChnlEmailFromAdd(String mcEmailFromAdd) {
        this.mcEmailFromAdd = mcEmailFromAdd;
        return this;
    }

    public String getMktChnlClaimEmailFromAdd() {
        return mcClaimEmailFromAdd;
    }

    public MarketChannelOverviewEntity setMktChnlClaimEmailFromAdd(String mcClaimEmailFromAdd) {
        this.mcClaimEmailFromAdd = mcClaimEmailFromAdd;
        return this;
    }

    public String getMktChnlWebsite() {
        return mcWebsite;
    }

    public MarketChannelOverviewEntity setMktChnlWebsite(String mcWebsite) {
        this.mcWebsite = mcWebsite;
        return this;
    }

    public String getGroupPhoneNumber() {
        return groupPhoneNumber;
    }

    public String getGroupEmailFromAddress() {
        return groupEmailFromAddress;
    }

    public String getGroupClaimEmailFromAddress() {
        return groupClaimEmailFromAddress;
    }

    public String getGroupWebsite() {
        return groupWebsite;
    }

    public MarketChannelOverviewEntity setGroupPhoneNumber(String groupPhoneNumber) {
        this.groupPhoneNumber = groupPhoneNumber;
        return this;
    }

    public MarketChannelOverviewEntity setGroupEmailFromAddress(String groupEmailFromAddress) {
        this.groupEmailFromAddress = groupEmailFromAddress;
        return this;
    }

    public MarketChannelOverviewEntity setGroupClaimEmailFromAddress(String groupClaimEmailFromAddress) {
        this.groupClaimEmailFromAddress = groupClaimEmailFromAddress;
        return this;
    }

    public MarketChannelOverviewEntity setGroupWebsite(String groupWebsite) {
        this.groupWebsite = groupWebsite;
        return this;
    }
}
