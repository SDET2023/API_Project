package entities.orca.makeChanges;

public class MakeChangesPetDetailsEntity {
    //Pet Details
    public String makeChangesPetName = "";
    public String makeChangesPetDOB = "";
    public String makeChangesPetGender = "";
    public String makeChangesPetSpecies = "";
    public String makeChangesPetBreed = "";

    public MakeChangesPetDetailsEntity() {
    }

    ;

    //Make Changes - Pet Details

    public String getMakeChangesPetName() {
        return makeChangesPetName;
    }

    public MakeChangesPetDetailsEntity setMakeChangesPetName(String petName) {
        this.makeChangesPetName = petName;
        return this;
    }

    public String getMakeChangesPetDOB() {
        return makeChangesPetDOB;
    }

    public MakeChangesPetDetailsEntity setMakeChangesPetDOB(String petDOB) {
        this.makeChangesPetDOB = petDOB;
        return this;
    }

    public String getMakeChangesPetGender() {
        return makeChangesPetGender;
    }

    public MakeChangesPetDetailsEntity setMakeChangesPetGender(String petGender) {
        this.makeChangesPetGender = petGender;
        return this;
    }

    public String getMakeChangesPetSpecies() {
        return makeChangesPetSpecies;
    }

    public MakeChangesPetDetailsEntity setMakeChangesPetSpecies(String petSpecies) {
        this.makeChangesPetSpecies = petSpecies;
        return this;
    }

    public String getMakeChangesPetBreed() {
        return makeChangesPetBreed;
    }

    public MakeChangesPetDetailsEntity setMakeChangesPetBreed(String petBreed) {
        this.makeChangesPetBreed = petBreed;
        return this;
    }
}
