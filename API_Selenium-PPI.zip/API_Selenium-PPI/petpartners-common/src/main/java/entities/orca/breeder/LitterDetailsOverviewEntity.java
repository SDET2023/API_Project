package entities.orca.breeder;

public class LitterDetailsOverviewEntity {
    public String ldMarketChannel = "";
    public String ldRegistrationNumber = "";
    public String ldRegistrationDate = "";
    public String ldDateOfBirth = "";
    public String ldBreed = "";
    public String ldMaleCount = "";
    public String ldFemaleCount = "";

    public String getLdRegistrationDate() {
        return this.ldRegistrationDate;
    }

    public LitterDetailsOverviewEntity setLdRegistrationDate(String ldRegistrationDate) {
        this.ldRegistrationDate = ldRegistrationDate;
        return this;
    }

    public LitterDetailsOverviewEntity() {
    }

    public String getLdBreed() {
        return this.ldBreed;
    }

    public String getLdFemaleCount() {
        return this.ldFemaleCount;
    }

    public LitterDetailsOverviewEntity setLdFemaleCount(String ldFemaleCount) {
        this.ldFemaleCount = ldFemaleCount;
        return this;
    }

    public String getLdMaleCount() {
        return this.ldMaleCount;
    }

    public LitterDetailsOverviewEntity setLdMaleCount(String ldMaleCount) {
        this.ldMaleCount = ldMaleCount;
        return this;
    }

    public LitterDetailsOverviewEntity setLdBreed(String ldBreed) {
        this.ldBreed = ldBreed;
        return this;
    }

    public String getLdRegistrationNumber() {
        return this.ldRegistrationNumber;
    }

    public String getLdDateOfBirth() {
        return this.ldDateOfBirth;
    }

    public LitterDetailsOverviewEntity setLdDateOfBirth(String ldDateOfBirth) {
        this.ldDateOfBirth = ldDateOfBirth;
        return this;
    }

    public LitterDetailsOverviewEntity setLdRegistrationNumber(String ldRegistrationNumber) {
        this.ldRegistrationNumber = ldRegistrationNumber;
        return this;
    }

    public String getLdMarketChannel() {
        return this.ldMarketChannel;
    }

    public LitterDetailsOverviewEntity setLdMarketChannel(String ldMarketChannel) {
        this.ldMarketChannel = ldMarketChannel;
        return this;
    }
}