package entities.orca.breeder;

public class BreederSearchEntity {
    private String lastName;
    private String emailAddress;

    public BreederSearchEntity() {
    }

    public BreederSearchEntity(String lastName, String emailAddress) {
        this.lastName = lastName;
        this.emailAddress = emailAddress;
    }

    public String getLastName() {
        return this.lastName;
    }

    public BreederSearchEntity setLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    public String getEmailAddress() {
        return this.emailAddress;
    }

    public BreederSearchEntity setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
        return this;
    }
}