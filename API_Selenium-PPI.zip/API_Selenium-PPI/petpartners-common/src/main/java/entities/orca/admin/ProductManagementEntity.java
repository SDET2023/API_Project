package entities.orca.admin;

public class ProductManagementEntity {

    public String productTypeDropDown = "";
    public String codeTextBox = "";
    public String displayTextBox ="";


    public String getProductTypeDropDown() {
        return productTypeDropDown;
    }

    public void setProductTypeDropDown(String productTypeDropDown) {
        this.productTypeDropDown = productTypeDropDown;
    }

    public String getCodeTextBox() {
        return codeTextBox;
    }

    public void setCodeTextBox(String codeTextBox) {
        this.codeTextBox = codeTextBox;
    }

    public String getDisplayTextBox() {
        return displayTextBox;
    }

    public void setDisplayTextBox(String displayTextBox) {
        this.displayTextBox = displayTextBox;
    }

    public ProductManagementEntity(){


    }
}
