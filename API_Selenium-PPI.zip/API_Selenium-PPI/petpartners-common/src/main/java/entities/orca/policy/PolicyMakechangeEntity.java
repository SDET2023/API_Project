package entities.orca.policy;

public class PolicyMakechangeEntity {

    private String gender = "";

    private String petName = "";

    private String species = "";

    private String breed = "";

    private String dateOfBirth = "";


    public PolicyMakechangeEntity() {
    }

    public void setDateOfBirth(String dateOfBrith) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public String getBreed() {
        return breed;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public String getSpecies() {
        return species;
    }

    public void setPetName(String petName) {
        this.petName = petName;
    }

    public String getPetName() {
        return petName;
    }


    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getGender() {
        return gender;
    }
}
