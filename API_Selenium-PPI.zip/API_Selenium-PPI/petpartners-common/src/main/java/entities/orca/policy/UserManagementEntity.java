package entities.orca.policy;

public class UserManagementEntity {

    private String firstName = "";
    private String lastName = "";
    private String syuserId = "";
    private String userName = "";
    private String emailAddress = "";
    private String brokerId = "";

    public UserManagementEntity() {
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setSyuserId(String syuserId) {
        this.syuserId = syuserId;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public void setBrokerId(String brokerId) {
        this.brokerId = brokerId;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getSyuserId() {
        return syuserId;
    }

    public String getUserName() {
        return userName;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public String getBrokerId() {
        return brokerId;
    }


}
