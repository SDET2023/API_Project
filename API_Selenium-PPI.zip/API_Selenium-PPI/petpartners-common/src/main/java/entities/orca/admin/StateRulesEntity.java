package entities.orca.admin;

public class StateRulesEntity {
    private String cancelOverride = "";
    private String leadFeeCap = "";
    private String allowElectricDeliveryDropDown = "";

    private String serviceFee="";

    public StateRulesEntity() {
    }
    public StateRulesEntity setCancelOverride(String cancelOverride) {
        this.cancelOverride = cancelOverride;
        return this;
    }
    public StateRulesEntity setLeadFeeCap(String leadFeeCap) {
        this.leadFeeCap = leadFeeCap;
        return this;
    }
    public StateRulesEntity setAllowElectricDeliveryDropDown(String allowElectricDeliveryDropDown) {
        this.allowElectricDeliveryDropDown = allowElectricDeliveryDropDown;
        return this;
    }
    public String getCancelOverride() {
        return cancelOverride;
    }
    public String getLeadFeeCap() {
        return leadFeeCap;
    }
    public String getAllowElectricDeliveryDropDown() {
        return allowElectricDeliveryDropDown;
    }

    public String getServiceFee() {
        return serviceFee;
    }

    public void setServiceFee(String serviceFee) {
        this.serviceFee = serviceFee;
    }
}
