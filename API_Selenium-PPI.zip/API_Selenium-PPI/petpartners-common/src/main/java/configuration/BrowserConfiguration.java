package configuration;

public class BrowserConfiguration {
    public static String browser = "chrome";
}
