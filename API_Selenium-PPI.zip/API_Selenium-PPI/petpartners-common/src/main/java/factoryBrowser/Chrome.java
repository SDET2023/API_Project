package factoryBrowser;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import utils.Level;
import utils.Logger;

import java.time.Duration;

public class Chrome implements IBrowser {
    @Override
    public WebDriver create() {
        WebDriverManager.chromedriver().setup();
        ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.addArguments("--window-size=2120,1400", "--ignore-certificate-errors","--remote-allow-origins=*");
        ChromeDriver driver = new ChromeDriver(chromeOptions);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
        Logger.log(Level.INFO, this.getClass().getName() + "> Creating Chrome browser with --window-size=2120,1400");
        return driver;
    }
}
