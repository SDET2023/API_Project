package factoryBrowser;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

import utils.Level;
import utils.Logger;

import java.time.Duration;

public class Edge implements IBrowser {
    @Override
    public WebDriver create() {
        WebDriverManager.edgedriver().setup();
        EdgeOptions edgeOptions = new EdgeOptions();
        edgeOptions.addArguments("--window-size=2120,1400", "--ignore-certificate-errors","--remote-allow-origins=*");
        EdgeDriver driver = new EdgeDriver(edgeOptions);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
        Logger.log(Level.INFO, this.getClass().getName() + "> Creating Edge browser with --window-size=2120,1400");
        return driver;
    }
}
