package factoryBrowser;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import utils.Level;
import utils.Logger;

import java.time.Duration;

public class FireFox implements IBrowser {
    @Override
    public WebDriver create() {
        WebDriverManager.firefoxdriver().setup();
        FirefoxOptions firefoxOptions = new FirefoxOptions();
        firefoxOptions.addArguments("--window-size=2120,1400", "--ignore-certificate-errors","--remote-allow-origins=*");
        FirefoxDriver driver = new FirefoxDriver(firefoxOptions);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
        Logger.log(Level.INFO, this.getClass().getName() + "> Creating firefox browser with --window-size=2120,1400");
        return driver;
    }
}
