package utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class GetPropertiesEmail {
    private static GetPropertiesEmail getProperties = null;
    private String emailTo;
    private String messageSubject;
    private String user;
    private String pwd;
    private String environmentInformation;
    private String reportLink;
    private String reportFile;

    private GetPropertiesEmail() {
        Properties properties = new Properties();
        String propFileName = System.getProperty("propertyFile") == null ? "email.properties" : System.getProperty("propertyFile");
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);
        if (inputStream != null) {
            try {
                properties.load(inputStream);
                emailTo = properties.getProperty("emailTo");
                messageSubject = properties.getProperty("messageSubject");
                user = properties.getProperty("user");
                pwd = properties.getProperty("pwd");
                environmentInformation = properties.getProperty("environmentInformation");
                reportLink = properties.getProperty("reportLink");
                reportFile = properties.getProperty("reportFile");
                inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    public static GetPropertiesEmail getInstance() {
        if (getProperties == null)
            getProperties = new GetPropertiesEmail();
        return getProperties;
    }

    public static GetPropertiesEmail getGetProperties() {
        return getProperties;
    }

    public String getEmailTo() {
        return emailTo;
    }

    public String getMessageSubject() {
        return messageSubject;
    }

    public String getUser() {
        return user;
    }

    public String getPwd() {
        return pwd;
    }

    public String getEnvironmentInformation() {
        return environmentInformation;
    }

    public String getReportLink() {
        return reportLink;
    }

    public String getReportFile() {
        return reportFile;
    }
}
