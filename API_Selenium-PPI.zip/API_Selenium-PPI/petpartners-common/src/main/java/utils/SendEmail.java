package utils;

import org.jsoup.Jsoup;
import us.codecraft.xsoup.Xsoup;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class SendEmail {

    private static final String ALIAS_FROM_EMAIL = "qaautomation.results@petpartners.com";

//     private static final String MAIL_SMTP_START_TLS_ENABLE="true";
//     private static final String MAIL_SMPT_HOST="smtp.gmail.com";
//     private static final String MAIL_SMTP_PORT="587";
//     private static final String MAIL_SMTP_AUTH="true";

    private static final String MAIL_SMTP_START_TLS_ENABLE = "true";
    private static final String MAIL_SMPT_HOST = "smtp.office365.com";
    private static final String MAIL_SMTP_PORT = "587";
    private static final String MAIL_SMTP_AUTH = "true";

    private static final String SIGNATURE = "<br>Best Regards<br>QA-Automation Team<br><img src=\"cid:petpartners_icon\"/></body></html>";
    private static final String CSS = "body {font-family: verdana,arial,sans-serif;	font-size:11px;	color:#333333;}table tr td, table tr th {font-size: 100%;}table.details tr, th{color: #ffffff; font-weight: bold;text-align:center;background:#2FB4D5;white-space: nowrap;font-size: 13px;}table.details tr,td{color:#000000 ;background:#eeeee0;white-space: nowrap;font-size: 12px;}";

    private static final String TCS_PASSED = "//*[@id=\"tablesorter\"]/tfoot/tr[1]/td[8]/text()";
    private static final String TCS_FAILED = "//*[@id=\"tablesorter\"]/tfoot/tr[1]/td[9]/text()";
    private static final String TCS_TOTAL = "//*[@id=\"tablesorter\"]/tfoot/tr[1]/td[10]/text()";
    private static final String TCS_TIME = "//*[@id=\"tablesorter\"]/tfoot/tr[1]/td[11]/text()";


    public static void main(String[] args) {
        String body;

        Properties properties = System.getProperties();
        properties.put("mail.smtp.starttls.enable", MAIL_SMTP_START_TLS_ENABLE);
        properties.put("mail.smtp.host", MAIL_SMPT_HOST);
        properties.put("mail.smtp.port", MAIL_SMTP_PORT);
        properties.put("mail.smtp.auth", MAIL_SMTP_AUTH);

        Session session = Session.getDefaultInstance(properties,
                new Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(
                                GetPropertiesEmail.getInstance().getUser(), GetPropertiesEmail.getInstance().getPwd());
                    }
                });
        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(ALIAS_FROM_EMAIL, ALIAS_FROM_EMAIL));
            String[] result = GetPropertiesEmail.getInstance().getEmailTo().split(";");
            for (String emailRec : result)
                message.addRecipient(Message.RecipientType.TO, new InternetAddress(emailRec));

            message.setSubject(String.format("Result : %s", GetPropertiesEmail.getInstance().getMessageSubject()));
            Multipart multipart = new MimeMultipart();

            // Html Format
            BodyPart htmlBodyPart = new MimeBodyPart();
            body = "<html><head><style>" + CSS + "</style></head><body>Hi Team<br><br> This is the result for automation test<br>";
            body = body + "<br><b>Environment Information :</b> <br><br>" + GetPropertiesEmail.getInstance().getEnvironmentInformation() + "<br>";
            body = body + SendEmail.buildingSummary(GetPropertiesEmail.getInstance().getReportLink(), GetPropertiesEmail.getInstance().getReportFile());
            body = body + SIGNATURE;

            htmlBodyPart.setContent(body, "text/html; charset=utf-8");
            multipart.addBodyPart(htmlBodyPart);

            // Embedded Image Signature
            MimeBodyPart imagePart = new MimeBodyPart();
            String iconPath = new File("").getAbsoluteFile() + "/src/main/resources/petpartners_icon.jpg";
            File f = new File(iconPath);
            if (!f.exists()) {
                iconPath = System.getProperty("user.dir") + "/petpartners-common/src/main/resources/petpartners_icon.jpg";
            }
            imagePart.attachFile(iconPath);
            imagePart.setContentID("<petpartners_icon>");
            imagePart.setDisposition(MimeBodyPart.INLINE);
            multipart.addBodyPart(imagePart);

            message.setContent(multipart);
            Transport.send(message);
            System.out.println("INFO > Sent message successfully....");
        } catch (MessagingException mex) {
            System.out.print("ERROR > There was a problem when sending the email," + mex.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String buildingSummary(String linkReport, String reportFile) throws Exception {
        String tableSummary = "";
        BufferedReader reader = new BufferedReader(new FileReader(reportFile));
        StringBuilder stringBuilder = new StringBuilder();
        String line = null;
        String ls = System.getProperty("line.separator");
        while ((line = reader.readLine()) != null) {
            stringBuilder.append(line);
            stringBuilder.append(ls);
        }
        stringBuilder.deleteCharAt(stringBuilder.length() - 1);
        reader.close();
        String html = stringBuilder.toString();
        org.jsoup.nodes.Document document = Jsoup.parse(html);
        String passed = Xsoup.compile(TCS_PASSED).evaluate(document).get();
        String failed = Xsoup.compile(TCS_FAILED).evaluate(document).get();
        String total = Xsoup.compile(TCS_TOTAL).evaluate(document).get();
        String time = Xsoup.compile(TCS_TIME).evaluate(document).get();

        tableSummary = "<b><br>Summary Result<br><br><table style=\"width:40%\"><tr><th colspan='4'> Summary Scenarios</th></tr>" +
                "<tr><th>Passed</th><th>Failed</th><th>Total</th><th>Time ms</th></tr>" +
                "<tr>" +
                "<td align='center'><font color=green>" + passed + "</font></td>" +
                "<td align='center'><font color=red>" + failed + "</font></td>" +
                "<td align='center'><font color=black>" + total + "</font></td>" +
                "<td align='center'><font color=black>" + time + "</font></td>" +
                "</tr>" +
                "</table></b>" +
                "<br>detail for the execution link : <b><a href='" + linkReport + "'>Report Detail</a></b>.<br>";
        return tableSummary;
    }

}
