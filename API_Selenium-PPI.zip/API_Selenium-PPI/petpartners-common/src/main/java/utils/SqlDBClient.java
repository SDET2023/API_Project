package utils;

import java.sql.*;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

public class SqlDBClient {

    private String server;
    private String dataBase;
    private String user;
    private String pwd;
    private String encrypt = "false";
    private String trustServerCertificate = "false";
    private String loginTimeout = "30";

    public SqlDBClient setServer(String server) {
        this.server = server;
        return this;
    }



    public SqlDBClient setDataBase(String dataBase) {
        this.dataBase = dataBase;
        return this;
    }

    public SqlDBClient setUser(String user) {
        this.user = user;
        return this;
    }

    public SqlDBClient setPwd(String pwd) {
        this.pwd = pwd;
        return this;
    }

    public SqlDBClient setEncrypt(String encrypt) {
        this.encrypt = encrypt;
        return this;
    }

    public SqlDBClient setTrustServerCertificate(String trustServerCertificate) {
        this.trustServerCertificate = trustServerCertificate;
        return this;
    }

    public SqlDBClient setLoginTimeout(String loginTimeout) {
        this.loginTimeout = loginTimeout;
        return this;
    }

    public Connection getConnection() throws ClassNotFoundException, SQLException {
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        byte[] decodedBytes = Base64.getDecoder().decode(pwd);
        pwd = new String(decodedBytes);
        String connectionUrl =
                "jdbc:sqlserver://" + server + ";"
                        + "database=" + dataBase + ";"
                        + "user=" + user + ";"
                        + "password=" + pwd + ";"
                        + "encrypt=" + encrypt + ";"
                        + "trustServerCertificate=" + trustServerCertificate + ";"
                        + "loginTimeout=" + loginTimeout + ";";
        Logger.log(Level.INFO, this.getClass().getName() + "SQL Connection: " + "jdbc:sqlserver://" + server + ";"
                                                                                        + "database=" + dataBase + ";"
                                                                                        + "user=" + user + ";"
                                                                                        + "password=*******************;"
                                                                                        + "encrypt=" + encrypt + ";"
                                                                                        + "trustServerCertificate=" + trustServerCertificate + ";"
                                                                                        + "loginTimeout=" + loginTimeout + ";");
        return DriverManager.getConnection(connectionUrl);

    }

    /**
     * this method is to execute SQL queries and get a List of result
     *
     * @param connection connection object
     * @param query      SQL query : SELECT * FROM table WHERE condition
     * @param label      this is the column name
     * @return
     */
    public List<String> executeQuery(Connection connection, String query, String label) {
        Logger.log(Level.INFO, this.getClass().getName() + "SQL Query: [ " + query + " ]");
        Logger.log(Level.INFO, this.getClass().getName() + "Column Name: [ " + label + " ]");
        List<String> resultList = new ArrayList<>();
        ResultSet resultSet;
        try (connection;
             Statement statement = connection.createStatement();) {
            resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                resultList.add(resultSet.getString(label));
                //Logger.log(Level.INFO,this.getClass().getName()+"Value "+resultSet.getString(label));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
        return resultList;
    }


    /**
     * this method is to execute SQL queries and get a List of result
     *
     * @param connection     connection object
     * @param query          SQL query : SELECT * FROM table WHERE condition
     * @param positionColumn this is the column index
     * @return
     */
    public List<String> executeQuery(Connection connection, String query, int positionColumn) {
        List<String> resultList = new ArrayList<>();
        ResultSet resultSet;
        try (connection;
             Statement statement = connection.createStatement();) {
            resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                System.out.println(resultSet.getString(positionColumn));
                resultList.add(resultSet.getString(positionColumn));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
        return resultList;
    }
}