package utils;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class DateUtils {
    public static String getCurrentDateOfESTTimeZone(){
        // Set the timezone to Eastern Standard Time (EST)
        ZoneId estTimeZone = ZoneId.of("America/New_York");
        LocalDate currentDate = LocalDate.now(estTimeZone);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/dd/yyyy");
        String formattedDate = currentDate.format(formatter);
        return formattedDate;
    }
}
