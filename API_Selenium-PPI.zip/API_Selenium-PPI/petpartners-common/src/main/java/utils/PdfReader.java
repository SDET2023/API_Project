package utils;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

import java.io.File;
import java.io.IOException;

public class PdfReader {
    public static String getTextPDF(String pdfFilePath){
        try {
            PDDocument document = PDDocument.load(new File(pdfFilePath));
            PDFTextStripper textStripper = new PDFTextStripper();
            String contentPDF = textStripper.getText(document);
            document.close();
            return contentPDF;
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("ERROR! there is a error reading the file: ["+pdfFilePath+"] please review if the file exist");
        }
    }
}
