package utils;

import java.io.File;
import java.io.FileInputStream;
import java.util.*;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {

    private Map<String, List<String>> excelSheet = new HashMap<>();
    private List<String> headers = new ArrayList<>();
    private String file;

    public ExcelReader(String file) {
        this.file = file;
    }

    /**
     * this method is to read the file  and save all the values in a map object
     */
    public void readBuildMap() {
        try {
            Logger.log(Level.INFO, "reading the excel file: [" + file + "]");
            File file = new File(this.file);
            FileInputStream fis = new FileInputStream(file);
            XSSFWorkbook wb = new XSSFWorkbook(fis);
            XSSFSheet sheet = wb.getSheetAt(0);
            Iterator<Row> itr = sheet.iterator();
            boolean isHeader = true;
            while (itr.hasNext()) {
                int position = 0;
                String value = " ";
                Row row = itr.next();
                Iterator<Cell> cellIterator = row.cellIterator();
                while (cellIterator.hasNext()) {
                    Cell cell = cellIterator.next();
                    switch (cell.getCellType()) {
                        case STRING:
                            value = cell.getStringCellValue();
                            break;
                        case NUMERIC:
                            // remove .0
                            value = String.valueOf(cell.getNumericCellValue());
                            break;
                        default:
                    }
                    if (isHeader) {
                        headers.add(value);
                        excelSheet.put(value, new ArrayList<>());
                    } else {

                        // System.out.println("***** POSITION "+position+"VALUE "+value);
                        excelSheet.get(headers.get(position)).add(value);
                    }
                    position++;
                }
                isHeader = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * this value is to get some specific value
     *
     * @param nameColumn
     * @param row
     * @return
     * @throws Exception
     */
    public String getValue(String nameColumn, int row) throws Exception {
        if (!excelSheet.containsKey(nameColumn))
            throw new Exception("The name of column does not exist: [" + nameColumn + "]");
        return excelSheet.get(nameColumn).get(row);
    }

    /**
     * this method get the complete list of column
     *
     * @param nameColumn
     * @return
     * @throws Exception
     */
    public List<String> getListColumn(String nameColumn) throws Exception {
        if (!excelSheet.containsKey(nameColumn))
            throw new Exception("The name of column does not exist: [" + nameColumn + "]");
        return excelSheet.get(nameColumn);
    }

    /**
     * ge the columns names
     *
     * @return
     */
    public List<String> getColumnName() {
        return headers;
    }

    public void showInfo() {
        for (String key : this.excelSheet.keySet()
        ) {
            for (String value : excelSheet.get(key)
            ) {
                System.out.println("* [" + key + "] ***: " + value);
            }
        }
    }

    public Map<String, List<String>> getExcelSheet() {
        return excelSheet;
    }
}