package utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileUtils {

    public static String readFile(String filePath) {
        String text = "";
        try {
            File myObj = new File(filePath);
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                text = text + data;
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            Logger.log(Level.ERROR, FileUtils.class.getName() + " File does not found");
            e.printStackTrace();
        }
        return text;
    }


}
