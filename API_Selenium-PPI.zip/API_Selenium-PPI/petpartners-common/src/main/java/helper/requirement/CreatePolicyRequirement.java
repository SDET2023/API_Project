package helper.requirement;

import com.jayway.jsonpath.DocumentContext;
import factoryRequest.FactoryRequest;
import factoryRequest.RequestInformation;
import io.restassured.response.Response;
import com.jayway.jsonpath.JsonPath;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import utils.Level;
import utils.Logger;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CreatePolicyRequirement {

    private String breedName="";
    private String petType=""; // 1 = dog / 2 = cat
    private String marketChannelName="";

    private String orcaUser="";
    private String orcaPassword="";
    private String appName="";
    private String postalCode="";

    private String hostApi="";
    private String gatewayUrl="";
    private String trustCommerce="";

    private RequestInformation request;
    private Response response;

    private String randomEmail = "";
    public CreatePolicyRequirement setBreedName(String breedName) {
        this.breedName = breedName;
        return this;
    }

    public CreatePolicyRequirement setPetType(String petType) {
        this.petType = petType;
        return this;
    }

    public CreatePolicyRequirement setMarketChannelName(String marketChannelName) {
        this.marketChannelName = marketChannelName;
        return this;
    }

    public CreatePolicyRequirement setOrcaUser(String orcaUser) {
        this.orcaUser = orcaUser;
        return this;
    }

    public CreatePolicyRequirement setOrcaPassword(String orcaPassword) {
        this.orcaPassword = orcaPassword;
        return this;
    }

    public CreatePolicyRequirement setAppName(String appName) {
        this.appName = appName;
        return this;
    }

    public CreatePolicyRequirement setPostalCode(String postalCode) {
        this.postalCode = postalCode;
        return this;
    }

    public CreatePolicyRequirement setHostApi(String hostApi) {
        this.hostApi = hostApi;
        return this;
    }

    public CreatePolicyRequirement setGatewayUrl(String gatewayUrl) {
        this.gatewayUrl = gatewayUrl;
        return this;
    }

    public CreatePolicyRequirement setTrustCommerce(String trustCommerce) {
        this.trustCommerce = trustCommerce;
        return this;
    }

    public String getEmailRandomValue() {
        return randomEmail;
    }

    public CreatePolicyRequirement seEmailRandomValue(String randomValue) {
        this.randomEmail = randomValue;
        return this;
    }

    public String getPolicyIdByApi(){
        Logger.log(Level.INFO, this.getClass().getName() + " ********* Creating Policy ID as Requirement By API ************");
        Logger.log(Level.INFO, this.getClass().getName() + " * breedName :  [ "+breedName+" ] ");
        Logger.log(Level.INFO, this.getClass().getName() + " * petType :  [ "+petType+" ] where  1 = dog and 2 = cat ");
        Logger.log(Level.INFO, this.getClass().getName() + " * marketChannelName :  [ "+marketChannelName+" ] ");
        Logger.log(Level.INFO, this.getClass().getName() + " * orcaUser :  [ "+orcaUser+" ] ");
        Logger.log(Level.INFO, this.getClass().getName() + " * orcaPassword :  [ "+orcaPassword+" ] ");
        Logger.log(Level.INFO, this.getClass().getName() + " * appName :  [ "+appName+" ] ");
        Logger.log(Level.INFO, this.getClass().getName() + " * postalCode :  [ "+postalCode+" ] ");
        Logger.log(Level.INFO, this.getClass().getName() + " * hostApi :  [ "+hostApi+" ] ");
        Logger.log(Level.INFO, this.getClass().getName() + " * gatewayUrl :  [ "+gatewayUrl+" ] ");
        Logger.log(Level.INFO, this.getClass().getName() + " * trustCommerce :  [ "+trustCommerce+" ] ");
        Logger.log(Level.INFO, this.getClass().getName() + " ***************************************************************");

        String random = new Date().getTime()+"@automation.com";
        this.randomEmail = randomEmail.isEmpty()?random:randomEmail;

        String breedId = this.getBreedId(breedName,petType);
        String orcaToken = "Bearer "+this.getOrcaToken(orcaUser,orcaPassword,appName);
        String marketChannelId = this.getMarketChannel(marketChannelName,orcaToken);
        String tomorrow = this.getDateFormat("yyyy-MM-dd",1);

        // save quote

        request = new RequestInformation();
        request.setUrl(hostApi+"/quote/v1")
                .setBody("{\n" +
                        "    \"marketChannelId\": "+marketChannelId+",\n" +
                        "    \"effectiveOn\": \""+tomorrow+"T00:00:00\",\n" +
                        "    \"postalCode\": \""+postalCode+"\",\n" +
                        "    \"pets\": [\n" +
                        "        {\n" +
                        "            \"petName\": \"python\",\n" +
                        "            \"breedId\": "+breedId+",\n" +
                        "            \"dob\": \"2021-04-14T00:00:00\",\n" +
                        "            \"qualifyingConditions\": false,\n" +
                        "            \"coverage\": null\n" +
                        "        }\n" +
                        "    ],\n" +
                        "    \"customer\": {\n" +
                        "        \"customerId\": null,\n" +
                        "        \"firstName\": \"Automation\",\n" +
                        "        \"lastName\": \"Requirement\",\n" +
                        "        \"address1\": \"100 Automation Street\",\n" +
                        "        \"address2\": \"\",\n" +
                        "        \"city\": \"Troy\",\n" +
                        "        \"postalCode\": \""+postalCode+"\",\n" +
                        "        \"phone\": \"9563322541\",\n" +
                        "        \"email\": \""+ this.randomEmail+"\",\n" +
                        "        \"salesforceId\": null\n" +
                        "    },\n" +
                        "    \"discounts\": null\n" +
                        "}")
                .addHeader("Content-Type","application/json")
                .addHeader("Authorization",orcaToken);

        response= FactoryRequest.make("post").send(request);
        response.then().statusCode(200);
        String quoteId=response.then().extract().path("data.quoteGuid")+"";
        String petId=response.then().extract().path(" data.pets.petId")+"";
        petId= petId.replace("[","").replace("]","");
        String newBody =new JSONObject(response.body().asString()).get("data").toString();

        // Get Product Quote Pet
        request = new RequestInformation();
        request.setUrl(hostApi+"/quote/v1/quote-pet/"+petId+"/products?continuingCoverage=false")
                .addHeader("Content-Type","application/json")
                .addHeader("Authorization",orcaToken);
        response= FactoryRequest.make("get").send(request);
        response.then().statusCode(200);


        String companionCareId=JsonPath.read(response.body().asString(),"$.baseProducts.[?(@.display=='CompanionCare')].stateFilingProductId").toString();
        companionCareId= companionCareId.replace("[","").replace("]","");
        String supportPlusId=JsonPath.read(response.body().asString(),"$.upgradeOptions.[?(@.display=='SupportPlus' && @.parentStateFilingProductId=='"+companionCareId+"')].stateFilingProductId").toString();
        String examPlusId=JsonPath.read(response.body().asString(),"$.upgradeOptions.[?(@.display=='ExamPlus' && @.parentStateFilingProductId=='"+companionCareId+"')].stateFilingProductId").toString();
        String breedingId=JsonPath.read(response.body().asString(),"$.upgradeOptions.[?(@.display=='BreedingCoverage' && @.parentStateFilingProductId=='"+companionCareId+"')].stateFilingProductId").toString();
        String defenderPlusId=JsonPath.read(response.body().asString(),"$.wellnessOptions.[?(@.display=='DefenderPlus' && @.parentStateFilingProductId=='"+companionCareId+"')].stateFilingProductId").toString();
        String alternativePlusId=JsonPath.read(response.body().asString(),"$.preselectedOptions.[?(@.display=='AlternativePlus' && @.parentStateFilingProductId=='"+companionCareId+"')].stateFilingProductId").toString();
        supportPlusId= supportPlusId.replace("[","").replace("]","");
        examPlusId= examPlusId.replace("[","").replace("]","");
        breedingId= breedingId.replace("[","").replace("]","");
        defenderPlusId= defenderPlusId.replace("[","").replace("]","");
        alternativePlusId= alternativePlusId.replace("[","").replace("]","");


        // Get Limits
        request = new RequestInformation();
        request.setUrl(hostApi+"/quote/v1/limits/"+postalCode+"")
                .addHeader("Content-Type","application/json")
                .addHeader("Authorization",orcaToken);
        response= FactoryRequest.make("get").send(request);
        response.then().statusCode(200);

        String coverageLimitId=JsonPath.read(response.body().asString(),"$.coverageLimits.[?(@.display=='Unlimited')].id").toString();
        String incidentLimitId=JsonPath.read(response.body().asString(),"$.incidentLimits.[?(@.display=='Unlimited')].id").toString();
        String deductibleLimitId=JsonPath.read(response.body().asString(),"$.deductibleLimits.[?(@.display=='$250')].id").toString();
        String coinsuranceLimitId=JsonPath.read(response.body().asString(),"$.coinsuranceLimits.[?(@.display=='10%')].id").toString();
        coverageLimitId= coverageLimitId.replace("[","").replace("]","");
        incidentLimitId= incidentLimitId.replace("[","").replace("]","");
        deductibleLimitId= deductibleLimitId.replace("[","").replace("]","");
        coinsuranceLimitId= coinsuranceLimitId.replace("[","").replace("]","");

        // build new json file
        String subJsonValue=" {\n" +
                "      \"selectedLimits\": {\n" +
                "        \"coverageLimitId\": "+coverageLimitId+",\n" +
                "        \"incidentLimitId\": "+incidentLimitId+",\n" +
                "        \"deductibleId\": "+deductibleLimitId+",\n" +
                "        \"coinsuranceId\": "+coinsuranceLimitId+"\n" +
                "      },\n" +
                "      \"selectedProducts\": [\n" +
                "        {\n" +
                "          \"stateFilingProductId\": "+companionCareId+",\n" +
                "          \"termDays\": 365\n" +
                "        },\n" +
                "        {\n" +
                "          \"stateFilingProductId\": "+supportPlusId+",\n" +
                "          \"termDays\": 365\n" +
                "        },\n" +
                "        {\n" +
                "          \"stateFilingProductId\": "+examPlusId+",\n" +
                "          \"termDays\": 365\n" +
                "        },\n" +
                "        {\n" +
                "          \"stateFilingProductId\": "+breedingId+",\n" +
                "          \"termDays\": 365\n" +
                "        },\n" +
                "        {\n" +
                "          \"stateFilingProductId\": "+defenderPlusId+",\n" +
                "          \"termDays\": 365\n" +
                "        },\n" +
                "        {\n" +
                "          \"stateFilingProductId\": "+alternativePlusId+",\n" +
                "          \"termDays\": 365\n" +
                "        }\n" +
                "      ]\n" +
                "    }";
        DocumentContext jsonBody =JsonPath.parse(newBody).set("$.pets.[0].coverage",JsonPath.parse(subJsonValue).read("$"));
        String jsonBuilder = jsonBody.jsonString();
        JSONObject json = new JSONObject(jsonBuilder);
        json.remove("customerSourceDetail");
        json.remove("customerSourceCode");

        // save quote
        request = new RequestInformation();
        request.setUrl(hostApi+"/quote/v1")
                .setBody(json.toString())
                .addHeader("Content-Type","application/json")
                .addHeader("Authorization",orcaToken);

        response= FactoryRequest.make("post").send(request);
        response.then().statusCode(200);

        // Get trust Commerce Token
        String trusteeApiToken = this.getTrustCommerceToken();

        request = new RequestInformation();
        request.setUrl(trustCommerce+"/trusteeapi/payment.php")
                .setBody(json.toString())
                .addQueryParams("cc","4111111111111111")
                .addQueryParams("action","store")
                .addQueryParams("returnurl","xml")
                .addQueryParams("exp","1224")
                .addQueryParams("token",trusteeApiToken);

        response= FactoryRequest.make("post").send(request);
        response.then().statusCode(200);

        // quote checkout

        request = new RequestInformation();
        request.setUrl(gatewayUrl+"/quote/v1/checkout")
                .setBody(" {\n" +
                        "        \"quoteGuid\": \""+quoteId+"\",\n" +
                        "        \"firstName\": \"automation\",\n" +
                        "        \"lastName\": \"automation\",\n" +
                        "        \"address1\": \"100 automation Street\",\n" +
                        "        \"address2\": \"\",\n" +
                        "        \"city\": \"Troy\",\n" +
                        "        \"postalCode\": \""+postalCode+"\",\n" +
                        "        \"phone\": \"9563322541\",\n" +
                        "        \"email\": \""+randomEmail+"\",\n" +
                        "        \"last4\": \"1111\",\n" +
                        "        \"expiresOn\": \"2024-12-30\",\n" +
                        "        \"trusteeApiToken\": \""+trusteeApiToken+"\",\n" +
                        "        \"isElectronicDelivery\": true,\n" +
                        "        \"eConsent\": true\n" +
                        "    }")
                .addHeader("Content-Type","application/json")
                .addHeader("Authorization",orcaToken);

        response= FactoryRequest.make("post").send(request);
        response.then().statusCode(200);
        String policyId=response.then().extract().path("policyId")+"";
        Logger.log(Level.INFO, this.getClass().getName() + " ****************************************");
        Logger.log(Level.INFO, this.getClass().getName() + " * Policy ID created :  [ "+policyId+" ] *");
        Logger.log(Level.INFO, this.getClass().getName() + " ****************************************");
        Assertions.assertTrue(!policyId.isEmpty(),"ERROR!! there is a error when we are creating a Policy, please review the request");
        return policyId;
    }

    private String getOrcaToken(String user,String pwd,String appName){
        JSONObject body = new JSONObject();
        body.put("username", user);
        body.put("password", pwd);
        body.put("application",appName);

        request= new RequestInformation();
        request.addHeader("Content-Type","application/json");
        request.setUrl(hostApi+"/customer/account/login")
                .setBody(body.toString());
        response=FactoryRequest.make("post").send(request);
        response.then().statusCode(200);
        String token=response.then().extract().path("accessToken");
        return token;
    }

    private String getTrustCommerceToken(){
        request= new RequestInformation();
        request.setUrl(hostApi+"/quote/v1/trustcommerce/token");
        response=FactoryRequest.make("get").send(request);
        response.then().statusCode(200);
        String token=response.then().extract().path("trusteeApiToken");
        return token;
    }

    private String getBreedId(String breedName, String petType){
        request = new RequestInformation();
        request.setUrl(hostApi+"/quote/v1/breeds/"+petType)
               .addHeader("Content-Type","application/json");
        response= FactoryRequest.make("get").send(request);
        response.then().statusCode(200);
        String breedId=JsonPath.read(response.body().asString(),"$.[?(@.display=='"+breedName+"')].breedId").toString();
        return breedId.replace("[","").replace("]","");
    }

    private String getMarketChannel(String marketChannelDisplayName, String orcaToken){
        request = new RequestInformation();
        request.setUrl(hostApi+"/admin/v1/market-channels")
                .addHeader("Content-Type","application/json")
                .addHeader("Authorization",orcaToken);
        response= FactoryRequest.make("get").send(request);
        response.then().statusCode(200);
        String marketChannelId=JsonPath.read(response.body().asString(),"$.[?(@.display=='"+marketChannelDisplayName+"')].marketChannelId").toString();
        return marketChannelId.replace("[","").replace("]","");
    }

    private String getDateFormat(String format, int days){
        Date dt = new Date();
        Calendar c = Calendar.getInstance();
        c.setTime(dt);
        c.add(Calendar.DATE, days);
        return new SimpleDateFormat(format).format(c.getTime()).toString();
    }
}
