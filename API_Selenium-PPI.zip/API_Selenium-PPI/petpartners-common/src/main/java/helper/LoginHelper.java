package helper;

import com.google.gson.JsonObject;
import factoryRequest.FactoryRequest;
import factoryRequest.RequestInformation;
import io.restassured.response.Response;
import org.json.JSONObject;
import utils.Level;
import utils.Logger;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class LoginHelper {

    /*
    * this method is to build the cookie to inject to selenium session to avoid multifactor authentication
    * */
    public String buildCookieInfoUser(String host,String user,String password){
        JSONObject loginBody = new JSONObject();
        loginBody.put("username",user);
        loginBody.put("password",password);
        loginBody.put("application","orca");


        RequestInformation request =  new RequestInformation();
        request.setUrl(host+"/customer/account/login")
                .addHeader("Content-Type","application/json")
                .setBody(loginBody.toString());
        Response response = FactoryRequest.make("post").send(request);
        response.then().statusCode(200);
        String accessToken = response.then().extract().path("accessToken");
        String refreshToken = response.then().extract().path("refreshToken");

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSSS-00:00");
        LocalDateTime now = LocalDateTime.now();
        String expired=dtf.format(now);
        JsonObject cookieBody = new JsonObject ();
        cookieBody.addProperty("accessToken",accessToken);
        cookieBody.addProperty("refreshToken",refreshToken);
        cookieBody.addProperty("expires",expired);
        cookieBody.addProperty("username",user);
        cookieBody.addProperty("sysuserId",389);
        Logger.log(Level.INFO, this.getClass().getName() + "Creating a new cookie:  [ "+cookieBody+" ] ");
        return cookieBody.toString();
    }


}
