package pages.akc;

import control.Button;
import control.TextBox;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class CreateAccountPage {
    public TextBox emailTextBox = new TextBox(By.xpath("//input[@name='emailInputControl']"));
    public TextBox passwordTextBox = new TextBox(By.xpath("//input[@placeholder='Password']"));
    public TextBox confirmPasswordTextBox = new TextBox(By.xpath("//input[@id='confirmRegisterPassword']"));
    public Button createAccountButton = new Button(By.xpath("//button[contains(.,'Create Account')]"));

    public CreateAccountPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }

    public void createNewAccount(String user, String pwd, String confirmPwd) throws Exception {
        emailTextBox.clearSetText(user);
        passwordTextBox.clearSetText(pwd);
        confirmPasswordTextBox.clearSetText(confirmPwd);
        createAccountButton.click();
    }

}
