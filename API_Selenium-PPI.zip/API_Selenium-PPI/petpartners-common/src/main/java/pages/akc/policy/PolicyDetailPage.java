package pages.akc.policy;

import control.Button;
import control.Label;
import control.Link;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class PolicyDetailPage {
    public Label policyDetailLabel = new Label(By.xpath("//h2[contains(.,'Policy Details')]"));
    public Label coverageLabel = new Label(By.xpath("//h2[contains(.,'Coverage')]"));
    public Label claimsLabel = new Label(By.xpath("//h2[contains(.,'Claims')]"));

    public Link viewPolicyDocumentsLink = new Link(By.xpath("//button[contains(@title,\'View policy documents\')]"));
    public Label activeLabel = new Label(By.xpath("//div[contains(text(),'Active')]"));
    public Label costLabel = new Label(By.xpath("//div[contains(text(),'Cost')]"));
    public Label petNameLabel = new Label(By.xpath("//div[contains(text(),'Pet Name')]"));
    public Label premiumLabel = new Label(By.xpath("//div[@class=\"card__label\" and text()='Premium']"));
    public Label productLabel = new Label(By.xpath("//div[@class=\"card__label\" and text()='Products']"));
    public Link showCoverageSummaryLink = new Link(By.xpath("//span[contains(text(),'Show Coverage Summary')]"));

    //dialog
    public Label downloadAttachmentLabelDialog = new Label(By.xpath("//h3[text()='Download your attachments']"));
    public Button closeDialogButton = new Button(By.xpath("//div[@class=\"modal__close\"]"));
    //AddPet
    public Button addPetButton = new Button(By.xpath("//a[@class='ml--1 mb--1 middle-xs button__submit']"));
    //ChangeCoverageOptions
    public Button changeCoverageOptions = new Button(By.xpath("//a[contains(text(),'Change Coverage Options')]"));
    public Button popupContinueButton = new Button(By.xpath("//button[@class='button__submit']"));

    public PolicyDetailPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }

    public boolean isPolicyNumberdisplayed(String policyNumber) {

        Label policyUnique = new Label(By.xpath("//p[text()='" + policyNumber + "']"));
        return policyUnique.controlIsDisplayed();
    }
}
