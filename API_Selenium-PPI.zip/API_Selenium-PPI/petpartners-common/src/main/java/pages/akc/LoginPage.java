package pages.akc;

import control.Button;
import control.TextBox;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class LoginPage {
    public TextBox emailTextBox = new TextBox(By.xpath("//input[@name=\"emailInputControl\"]"));
    public TextBox passwordTextBox = new TextBox(By.xpath("//input[@placeholder=\"Password\"]"));
    public Button loginButton = new Button(By.xpath("//button[contains(text(),'Login')]"));
    public Button createAccountButton = new Button(By.xpath("//button[contains(text(),'Create Account')]"));

    public LoginPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }

    public void login(String user, String pwd) throws Exception {
        emailTextBox.setText(user);
        passwordTextBox.setText(pwd);
        loginButton.click();
    }
}
