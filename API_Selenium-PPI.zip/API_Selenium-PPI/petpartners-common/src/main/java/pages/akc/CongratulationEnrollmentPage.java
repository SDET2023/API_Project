package pages.akc;

import control.Button;
import control.Label;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class CongratulationEnrollmentPage {
    public Label congratulationEnrollmentLabel = new Label(By.xpath("//h1[text()='Congratulations on your enrollment!']"));
    public Label policyNumberLabel = new Label(By.xpath("//h2[contains(.,'Policy')]"));
    public Button portalLoginButton = new Button(By.xpath("//span[contains(.,'Portal Login')]"));
    public Label monthlyTotalLabel = new Label(By.xpath("//div[contains(@class,\"pet-overview__premium-price\")]"));

    public CongratulationEnrollmentPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }

}
