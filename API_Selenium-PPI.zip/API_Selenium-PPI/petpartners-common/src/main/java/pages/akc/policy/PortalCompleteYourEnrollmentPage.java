package pages.akc.policy;

import control.Button;
import control.TextBox;
import entities.akc.ChangeCovCompleteEnrollmentEntity;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class PortalCompleteYourEnrollmentPage {

    //Change Coverage Options - Complete Enrollment Objects
    public TextBox chgCovFirstNameOnCardTextBox = new TextBox(By.xpath("//input[@formcontrolname=\"firstNameOnCard\"]"));
    public TextBox chgCovLastNameOnCardTextBox = new TextBox(By.xpath("//input[@formcontrolname=\"lastNameOnCard\"]"));
    public TextBox chgCovCardNumberTextBox = new TextBox(By.xpath("//input[@formcontrolname=\"cardNumber\"]"));
    public TextBox chgCovExpiresMMTextBox = new TextBox(By.xpath("//input[@formcontrolname=\"expiresMonth\"]"));
    public TextBox chgCovExpiresYYYYTextBox = new TextBox(By.xpath("//input[@formcontrolname=\"expiresYear\"]"));
    public TextBox chgCovExpiresCVCTextBox = new TextBox(By.xpath("//input[@formcontrolname=\"cvc\"]"));
    public Button chgCovEnrollNowButton = new Button(By.xpath("//button[@type=\"submit\"]"));

    public PortalCompleteYourEnrollmentPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }

    public void fillChgCovCompleteYourEnrollment(ChangeCovCompleteEnrollmentEntity completeEnrollmentEntity) throws Exception {
        this.chgCovFirstNameOnCardTextBox.setText(completeEnrollmentEntity.getFirstNameOnCard());
        this.chgCovLastNameOnCardTextBox.setText(completeEnrollmentEntity.getLastNameOnCard());
        this.chgCovCardNumberTextBox.setText(completeEnrollmentEntity.getCardNumber());
        this.chgCovExpiresMMTextBox.setText(completeEnrollmentEntity.getExpiresMM());
        this.chgCovExpiresYYYYTextBox.setText(completeEnrollmentEntity.getExpireYYYY());
        this.chgCovExpiresCVCTextBox.setText(completeEnrollmentEntity.getCvc());
        this.chgCovEnrollNowButton.click();
        Thread.sleep(2000);
    }
}
