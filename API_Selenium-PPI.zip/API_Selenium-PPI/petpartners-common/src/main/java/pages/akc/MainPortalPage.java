package pages.akc;

import control.Button;
import control.Label;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;

public class MainPortalPage {
    public Label welcomeLabel = new Label(By.xpath("//h4[contains(.,'Welcome to your Customer Portal!')]"));

    public Button petGenuxRex = new Button (By.xpath("//main//*[./div[contains(text(),'PetGenius Rx')]]"));
    public Button petGenuxLink = new Button (By.xpath("//p[contains(text(),'Save Money on your pet medications')]"));

    public Map<String,Button> portalButton = new HashMap<>();

    public MainPortalPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());


        portalButton.put("Claim",new Button(By.xpath("//div[@id='dashboard-nav']//div[@class='navigation__label'][normalize-space()='Claims']")));
        portalButton.put("Home",new Button(By.xpath("//div[@id='dashboard-nav']//div[@class='navigation__label'][normalize-space()='Home']")));
        portalButton.put("User Account",new Button(By.xpath("//div[@id='dashboard-nav']//div[@class='navigation__label'][normalize-space()='User Account']")));
        portalButton.put("Sign out",new Button(By.xpath("//div[@id='dashboard-nav']//div[@class='navigation__label'][normalize-space()='Sign Out']")));



    }
}
