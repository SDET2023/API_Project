package pages.akc;

import control.*;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;
import java.util.HashMap;
import java.util.Map;


public class AkcReunitePage {

    public Map<String, Label> labelMap = new HashMap<>();

    public AkcReunitePage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }
    public TextBox createTextValue(String text){
        TextBox textvalue = new TextBox(By.xpath("//*[contains(text(),'"+text+"')]"));
        return textvalue;
    }

}
