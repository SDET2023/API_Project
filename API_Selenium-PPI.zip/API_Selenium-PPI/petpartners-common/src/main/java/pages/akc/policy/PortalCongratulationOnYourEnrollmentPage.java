package pages.akc.policy;

import control.Button;
import org.openqa.selenium.By;

public class PortalCongratulationOnYourEnrollmentPage {
    //Change Coverage Options
    public Button chgCovDeductible = new Button(By.xpath("//li[contains(text(),'Deductible')]"));
    public Button chgCovCoinsurance = new Button(By.xpath("//li[contains(text(),'Coinsurance')]"));
    public Button chgCovAnnual = new Button(By.xpath("//li[contains(text(),'Annual')]"));
    public Button chgCovExamPlus = new Button(By.xpath("//li[contains(text(),'ExamPlus')]"));
    public Button chgCovBreeding = new Button(By.xpath("//li[contains(text(),'BreedingCoverage')]"));

    //Add Pet
    public Button addPetName = new Button(By.xpath("/descendant::h5[@class='pet-overview__name'][1]"));
    public Button addPetBreed = new Button(By.xpath("/descendant::h5[@class='pet-overview__name'][2]"));
    public Button addPetDeductible = new Button(By.xpath("/descendant::li[contains(text(),'Deductible')][1]"));
    public Button addPetCoinsurance = new Button(By.xpath("/descendant::li[contains(text(),'Coinsurance')][1]"));
    public Button addPetAnnual = new Button(By.xpath("/descendant::li[contains(text(),'Annual')][1]"));
    public Button addPetExamPlus = new Button(By.xpath("/descendant::li[contains(text(),'ExamPlus')][1]"));
    public Button addPetBreeding = new Button(By.xpath("/descendant::li[contains(text(),'BreedingCoverage')][1]"));

}
