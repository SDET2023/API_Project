package pages.orca.common;

import control.Label;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class AlertSection {
    public Label successfullyAlertLabel = new Label(By.xpath("//div[contains(@class,'alert alert-success')]"));

    public Label infoTitleAlertLabel = new Label(By.xpath("//div[@class='alert alert-info text-center']/h4"));
    public Label infoDetailAlertLabel = new Label(By.xpath("//div[@class='alert alert-info text-center']/strong"));

    public Label centerTitleAlertLabel = new Label(By.xpath("//div[@class='alert text-center']/h4"));
    public Label centerDetailAlertLabel = new Label(By.xpath("//div[@class='alert text-center']"));
    public AlertSection() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }
}
