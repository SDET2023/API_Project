package pages.orca.orcaDashBoard;

import control.Button;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;

public class OrcaDashboard {

    public Map<String, Button> orcaDashboard = new HashMap<>();

    public OrcaDashboard(){

        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        orcaDashboard.put("Pending",new Button(By.xpath("//a[text()='Pending']")));
        orcaDashboard.put("Request",new Button(By.xpath("//a[text()='Requests']")));
        orcaDashboard.put("Hold Payment Policies",new Button(By.xpath("//a[text()='Hold Payment Policies']")));
        orcaDashboard.put("DNOCs",new Button(By.xpath("//a[text()='DNOCs']")));
        orcaDashboard.put("Follow-Ups",new Button(By.xpath("//a[text()='Follow-up(s)']")));
    }
}
