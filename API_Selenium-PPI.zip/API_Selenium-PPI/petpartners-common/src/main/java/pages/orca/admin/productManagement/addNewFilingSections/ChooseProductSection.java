package pages.orca.admin.productManagement.addNewFilingSections;

import control.Checkbox;
import control.Label;
import control.Select;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import session.Session;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChooseProductSection {
    public Label chooseProductLabel = new Label(By.xpath("//*[contains(text(),'Choose Product')]"));
    public Select selectProductPackageSelect = new Select(By.xpath("//select[@formcontrolname=\"productPackageId\"]"));

    public Checkbox enableApplicationRequirements = new Checkbox(By.xpath("//input[@formcontrolname=\"requiresApplication\"]"));

    public Checkbox companionCareCompanionCareCheckbox = new Checkbox(By.xpath("//div[@id='ngb-panel-25-header']//input[@type='checkbox']"));
    public Checkbox companionCareExamCareCheckbox = new Checkbox(By.xpath("//div[@id='ngb-panel-26-header']//input[@type='checkbox']"));
    public Checkbox companionCareInheritedPlusCheckbox = new Checkbox(By.xpath("//div[@id='ngb-panel-27-header']//input[@type='checkbox']"));
    public Checkbox accidentCareCheckbox = new Checkbox(By.xpath("//input[@type=\"checkbox\"]"));
    public Map<String, Checkbox> companionCareCheckBoxesMap = new HashMap<>();
    public Map<String, Checkbox> newProPackNGJYCheckBoxesMap = new HashMap<>();

    public ChooseProductSection() {
        companionCareCheckBoxesMap.put("CompanionCare", companionCareCompanionCareCheckbox);
        companionCareCheckBoxesMap.put("ExamCare", companionCareExamCareCheckbox);
        companionCareCheckBoxesMap.put("InheritedPlus", companionCareInheritedPlusCheckbox);
        companionCareCheckBoxesMap.put("DefenderPlus", companionCareInheritedPlusCheckbox);
        companionCareCheckBoxesMap.put("ExamCare", companionCareInheritedPlusCheckbox);
        companionCareCheckBoxesMap.put("InheritedPlus", companionCareInheritedPlusCheckbox);

        newProPackNGJYCheckBoxesMap.put("AccidentCare", accidentCareCheckbox);
    }

    public boolean verifyIsCheckboxChecked(String cbox) throws Exception {
        boolean check = true;
        if (cbox.contains("Active CompanionCare")) {
            check = this.companionCareCompanionCareCheckbox.isChecked();
        } else if (cbox.contains("Active ExamCare")) {
            check = this.companionCareExamCareCheckbox.isChecked();
        } else if (cbox.contains("Active InheritedPlus")) {
            check = this.companionCareCompanionCareCheckbox.isChecked();
        }
        return check;
    }

    public void updateCheckBox(String section, String nameCheckBox, String action) throws Exception {
        String nameLocator = "//span[contains(.,'Product Name')]/../input";
        List<WebElement> listControl = Session.getInstance().getDriver().findElements(By.xpath(nameLocator));
        for (WebElement control : listControl) {
            String actualValue = control.getAttribute("value");
            if (actualValue.contains(nameCheckBox)) {
                String checkBoxLocator = "../../..//span[contains(.,'Active')]/input";
                WebElement checkBox = control.findElement(By.xpath(checkBoxLocator));
                if (action.toLowerCase().contains("uncheck")) {
                    if (checkBox.isSelected()) {
                        Logger.log(Level.INFO, this.getClass().getName() + "> uncheck on [" + checkBoxLocator + "] " + this.getClass().getSimpleName());
                        checkBox.click();
                        break;
                    }
                } else {
                    if (!checkBox.isSelected()) {
                        Logger.log(Level.INFO, this.getClass().getName() + "> check on [" + checkBoxLocator + "] " + this.getClass().getSimpleName());
                        checkBox.click();
                        break;
                    }
                }
            }
        }
    }

    public boolean verifyCheckBoxIsChecked(String section, Map<String,String>data) throws Exception {
        boolean isNotSelected = false;
       datafind: for (String nameCheckBox:data.keySet()) {
            String nameLocator = "//span[contains(.,'Product Name')]/../input";
            List<WebElement> listControl = Session.getInstance().getDriver().findElements(By.xpath(nameLocator));
            for (WebElement control : listControl) {
                String actualValue = control.getAttribute("value");
                if (actualValue.contains(nameCheckBox)) {
                    String checkBoxLocator = "../../..//span[contains(.,'Active')]/input";
                    WebElement checkBox = control.findElement(By.xpath(checkBoxLocator));
                    if (data.get(nameCheckBox).toLowerCase().contains("uncheck")) {
                        Logger.log(Level.INFO, this.getClass().getName() + "> uncheck on [" + checkBoxLocator + "] " + this.getClass().getSimpleName());
                        isNotSelected = !checkBox.isSelected();
                        break datafind;
                    }
                }
            }
        }  return isNotSelected;
    }
}