package pages.orca.followUps;

import control.Button;
import control.Select;
import control.TextBox;
import entities.orca.followUp.FollowUpDetailEntity;
import org.openqa.selenium.By;


public class FollowUpsPage {

    public Button addNewButtonFollowUps = new Button(By.xpath("//a[@title='Create Followup'][normalize-space()='Add New']"));
    public Select complainTypeDropDown = new Select(By.id("Followup_complaint_type_id"));
    public Select followupTypeDropDown = new Select(By.id("Followup_followup_type_id"));
    public Button saveButtonFollowUpPage = new Button(By.xpath("//button[normalize-space()='Save']"));
    public Button cancelButtonFollowUpPage = new Button(By.xpath("//a[@title='Cancel']"));
    public Select assignToDropdown = new Select(By.id("Followup_assigned_to"));

    public Select assignedToSelect = new Select(By.xpath("//select[@id=\"Followup_assigned_to\"]"));
    public Select followUpTypeSelect = new Select(By.xpath("//select[@id=\"Followup_followup_type_id\"]"));
    public Select complaintTypeSelect = new Select(By.xpath("//select[@id=\"Followup_complaint_type_id\"]"));

    public TextBox receivedOnTextBox = new TextBox(By.id("Followup_received_on"));
    public TextBox followUpByTextBox = new TextBox(By.id("Followup_followup_by"));
    public TextBox closedOnTextBox = new TextBox(By.id("Followup_closed_on"));

    public TextBox summaryTextBox = new TextBox(By.id("Followup_summary"));
    public TextBox resolutionTextBox = new TextBox(By.id("Followup_resolution"));

    public Button cancelButton = new Button(By.xpath("//a[@title=\"Cancel\"]"));
    public Button saveButton = new Button(By.xpath("//button[contains(.,'Save')]"));


    public void fillDetailPage(FollowUpDetailEntity entity) throws Exception {

        if (entity.getAssignedTo().contains("random")) {
            assignedToSelect.firstValue();
        } else {
            assignedToSelect.selectValueContainsOption(entity.getAssignedTo());
        }
        if (entity.getFollowUpType() != "")
            followUpTypeSelect.selectValueContainsOption(entity.getFollowUpType());

        if (entity.getComplaintType() != "")
            complaintTypeSelect.selectValueContainsOption(entity.getComplaintType());

        if (entity.getReceivedOn() != "")
            receivedOnTextBox.setTextAndTab(entity.getReceivedOn());
        if (entity.getFollowUpBy() != "")
            followUpByTextBox.setTextAndTab(entity.getFollowUpBy());
        if (entity.getClosedOn() != "")
            closedOnTextBox.setTextAndTab(entity.getClosedOn());
        if (entity.getSummary() != "")
            summaryTextBox.setText(entity.getSummary());
        if (entity.getResolution() != "")
            resolutionTextBox.setText(entity.getResolution());

        saveButton.click();
    }
}
