package pages.orca.policy;

import control.Button;
import control.Checkbox;
import control.Table;
import control.TextBox;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class MoveClaimDialog {
    public TextBox policyNoTextBox = new TextBox(By.xpath("//input[@id=\"MoveToPolicyId\"]"));
    public Table claimsToMoveTable = new Table(By.xpath("//table[@class=\"table table-bordered table-striped\"]"));
    public Button goButton = new Button(By.xpath("//div[@class=\"modal-footer btn-block\"]/button[contains(text(),'Go')]"));
    public Button cancelButton = new Button(By.xpath("//div[@class=\"modal-footer btn-block\"]/button[contains(text(),'Cancel')]"));

    public MoveClaimDialog() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }

    public void moveClaim(String policyNo, String claimNumber) throws Exception {
        this.policyNoTextBox.setText(policyNo);
        Checkbox checkBoxClaims;
        if (!claimNumber.equals("any")) {
            checkBoxClaims = new Checkbox(By.xpath("//table[@class=\"table table-bordered table-striped\"]//td[contains(text(),'" + claimNumber + "')]/parent::*//input[@type=\"checkbox\"]"));
        } else {
            checkBoxClaims = new Checkbox(By.xpath("//table[@class=\"table table-bordered table-striped\"]//td[1]/parent::*//input[@type=\"checkbox\"]"));
        }
        checkBoxClaims.click();
        this.goButton.click();
    }

}
