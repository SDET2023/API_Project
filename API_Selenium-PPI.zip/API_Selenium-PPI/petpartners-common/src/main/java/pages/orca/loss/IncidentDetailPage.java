package pages.orca.loss;

import control.ControlBase;
import control.Label;
import control.Table;
import control.TextBox;
import org.openqa.selenium.By;

import java.util.HashMap;
import java.util.Map;

public class IncidentDetailPage {

    public TextBox dateOfEligibilityTextBox = new TextBox(By.id("Incident_DateOfEligibility"));
    public Label dateOfEligibilityToolTip =  new Label(By.xpath("//div[@class=\"tooltip-inner\"]"));
    public TextBox onsetDateTextBox = new TextBox(By.id("Incident_OnsetDate"));
    public Label incidentIdLabel =  new Label(By.xpath("//strong[contains(.,'Incident Id')]/../..//div[@class='controls']"));
    public Label petLabel =  new Label(By.xpath("//strong[contains(.,'Pet')]/../..//div[@class='controls']"));
    public TextBox incidentTypeTextBox = new TextBox(By.id("incident_type"));
    public TextBox openDiagnosisTextBox = new TextBox(By.id("Incident_OpenDiagnosis"));
    public TextBox denialCodeTextBox = new TextBox(By.id("DenialCodeText_autocomplete"));
    public TextBox detailTextBox = new TextBox(By.id("Incident_Details"));

    public Table claimsTable = new Table(By.xpath("//table"));

    public Map<String, ControlBase> allControls = new HashMap<>();

    public IncidentDetailPage(){
        allControls.put("Date Of Eligibility",dateOfEligibilityTextBox);
        allControls.put("Onset Date",onsetDateTextBox);
        allControls.put("Incident Id",incidentIdLabel);
        allControls.put("Pet",petLabel);
        allControls.put("Incident Type",incidentTypeTextBox);
        allControls.put("Open Diagnosis",openDiagnosisTextBox);
        allControls.put("Denial Code",denialCodeTextBox);
        allControls.put("Details",detailTextBox);
    }
}
