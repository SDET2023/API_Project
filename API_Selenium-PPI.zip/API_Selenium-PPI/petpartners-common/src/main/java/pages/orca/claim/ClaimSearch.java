package pages.orca.claim;

import control.Button;
import control.Link;
import control.TextBox;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;

public class ClaimSearch {
    public TextBox claimNoTxtBox = new TextBox(By.xpath("//input[@id='SearchCriteria_ClaimNo']"));
    public TextBox lastNameTxtBox = new TextBox(By.id("SearchCriteria_LastName"));
    public TextBox emailAddressTxtBox = new TextBox(By.id("SearchCriteria_Email"));
    public TextBox checkNumberTxtBox = new TextBox(By.id("SearchCriteria_CheckNo"));
    public TextBox groupEmployeeLastNameTxtBox = new TextBox(By.id("SearchCriteria_GroupEmployeeLastName"));
    public TextBox groupEmployeeEmailTxtBox = new TextBox(By.id("SearchCriteria_GroupEmployeeEmail"));
    public Map<String,TextBox> textBoxMap = new HashMap<>();

    public Button runSearchButton = new Button(By.id("btn-run-search"));


    public ClaimSearch() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        textBoxMap.put("Claim No",claimNoTxtBox);
        textBoxMap.put("Last Name",lastNameTxtBox);
        textBoxMap.put("Email Address",emailAddressTxtBox);
        textBoxMap.put("Check Number",checkNumberTxtBox);
        textBoxMap.put("Group Employee Last Name",groupEmployeeLastNameTxtBox);
        textBoxMap.put("Group Employee Email",groupEmployeeEmailTxtBox);


    }

    public void clickClaimResult(String claimNumber) throws Exception {
        Link claimLink = new Link(By.xpath("//a[contains(@href,'claimId=" + claimNumber + "')]"));
        claimLink.click();
    }
}
