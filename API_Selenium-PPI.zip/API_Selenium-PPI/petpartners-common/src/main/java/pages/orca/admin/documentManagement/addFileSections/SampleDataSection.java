package pages.orca.admin.documentManagement.addFileSections;

import control.Link;
import control.Select;
import org.openqa.selenium.By;

public class SampleDataSection {

    public Select marketChannelSelect = new Select(By.xpath("//label[contains(.,'Market Channel')]/parent::*/select"));

    public Link customerDataLink = new Link(By.xpath("//strong[text()='Customer Data']"));
    public Link policyDataLink = new Link(By.xpath("//strong[text()='Policy Data']"));
    public Link petsDataLink = new Link(By.xpath("//strong[text()='Pets Data']"));
    public Link claimDataLink = new Link(By.xpath("//strong[text()='Claim Data']"));
}
