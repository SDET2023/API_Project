package pages.orca.vet;

import control.*;
import org.openqa.selenium.By;
import java.util.HashMap;
import java.util.Map;

public class VetDashboardPage {

    public TextBox nameTextBox = new TextBox(By.id("SearchCriteria_Name"));
    public TextBox phoneTextBox = new TextBox(By.id("SearchCriteria_PhoneNo"));
    public TextBox cityTextBox = new TextBox(By.id("SearchCriteria_City"));
    public Select stateProvinceDropDown = new Select(By.id("SearchCriteria_StateProvince"));
    public TextBox postalCodeTextBox = new TextBox(By.id("SearchCriteria_PostalCode"));
    public Checkbox showAllCheckbox = new Checkbox(By.id("ShowAllDuplicates"));
    public Button clearButton = new Button(By.xpath("//a[contains(text(),'Clear')]"));
    public Button runSearchButton = new Button(By.xpath("//button[contains(text(),'Run Search')]"));
    public Table vetsTable = new Table(By.id("vets-table"));

    public Map<String,TextBox> textBoxMap = new HashMap<>();
    public Map<String, Button> buttonMap = new HashMap<>();
    public Map<String, Checkbox> checkboxMap = new HashMap<>();

    public  VetDashboardPage(){
        textBoxMap.put("Name",nameTextBox);
        textBoxMap.put("Phone",phoneTextBox);
        textBoxMap.put("City",cityTextBox);
        textBoxMap.put("Postal Code",postalCodeTextBox);
        buttonMap.put("Clear",clearButton);
        buttonMap.put("Run Search", runSearchButton);
        checkboxMap.put("Show All Duplicates",showAllCheckbox);
    }

    public boolean verifyIsFieldEmpty(String fieldName)throws Exception {
       return fieldName.contains("State") ? this.stateProvinceDropDown.controlIsSelectDropdownEmpty("value", "-- Select a State --") : textBoxMap.get(fieldName).controlIsTextboxEmpty("value");
    }

    public void fillDetailsOnVetDashboard(String fieldName, String fieldValue) throws Exception {
          if( fieldName.contains("State")) {
                this.stateProvinceDropDown.selectValue(fieldValue);
            } else{
                textBoxMap.get(fieldName).setText(fieldValue);
            }
    }
}
