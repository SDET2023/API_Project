package pages.orca.mclead;

import control.Button;
import control.Select;
import control.TextBox;
import entities.orca.MCleadCustomerDetail;
import entities.orca.MCleadPetDetail;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class RegistrationMcleadPage {

    //PetDetails
    public TextBox registrationNoTextBox = new TextBox(By.xpath("//input[@id=\"Pet_reg_no\"]"));
    public TextBox registrationDateTextBox = new TextBox(By.xpath("//input[@id=\"Pet_registration_date\"]"));
    public TextBox dateOfBirthTextBox = new TextBox(By.xpath("//input[@id=\"Pet_dob\"]"));
    public TextBox colorTextBox = new TextBox(By.xpath("//input[@id=\"Pet_pet_color\"]"));
    public Select marketChannelSelect = new Select(By.id("market-channel"));
    public Select partnerSelect = new Select(By.id("Pet_partner_id"));
    public TextBox petNameTextBox = new TextBox(By.id("Pet_pet_name"));
    public Select speciesSelect = new Select(By.id("species-select"));
    public Select breedSelect = new Select(By.id("breed-select"));
    public Select genderSelect = new Select(By.id("Pet_gender_id"));
    public TextBox soldDateTextBox = new TextBox(By.xpath("//input[@id='Pet_sold_date']"));

    //CustomerDetails
    public TextBox firstNameTextBox = new TextBox(By.xpath("//input[@id='Customer_Customer_FirstName']"));
    public TextBox middleNameTextBox = new TextBox(By.xpath("//input[@id='Customer_Customer_MiddleName']"));
    public TextBox lastNameTextBox = new TextBox(By.xpath("//input[@id='Customer_Customer_LastName']"));
    public TextBox address1TextBox = new TextBox(By.xpath("//input[@id='Customer_Customer_Address1']"));
    public TextBox address2TextBox = new TextBox(By.xpath("//input[@id='Customer_Customer_Address2']"));
    public TextBox cityTextBox = new TextBox(By.xpath("//input[@id='Customer_Customer_City']"));
    public Select stateProvinceSelect = new Select(By.xpath("//select[@id='state-prov']"));
    public TextBox postalCodeTextBox = new TextBox(By.xpath("//input[@id=\"Customer_Customer_PostalCode\"]"));
    public TextBox emailTextBox = new TextBox(By.xpath("//input[@id=\"Customer_Customer_Email\"]"));
    public TextBox phoneTextBox = new TextBox(By.xpath("//input[@id=\"Customer_Customer_PhoneDay\"]"));
    public Select sendEmailSelect = new Select(By.xpath("//select[@id=\"Customer_Customer_SendEmail\"]"));

    public Button addRegistrationButton = new Button(By.xpath("//button[text()='Add Registration']"));

    public Button getquoteMcLeadDetails = new Button(By.xpath("//a[text()=' Get Quote']"));

    public RegistrationMcleadPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }

    public void fillPetDetailSection(MCleadPetDetail mCleadPetDetail) throws Exception {
        registrationNoTextBox.setText(mCleadPetDetail.registrationNo);
        registrationDateTextBox.click();
        registrationDateTextBox.setTextAndTab(mCleadPetDetail.registrationDate);
        dateOfBirthTextBox.setTextAndTab(mCleadPetDetail.dateOfBirth);
        colorTextBox.setText(mCleadPetDetail.color);
        marketChannelSelect.selectValue(mCleadPetDetail.marketChannel);
        partnerSelect.selectValue(mCleadPetDetail.partner);
        petNameTextBox.setText(mCleadPetDetail.petName);
        speciesSelect.selectValue(mCleadPetDetail.species);
        breedSelect.selectValue(mCleadPetDetail.breed);
        genderSelect.selectValue(mCleadPetDetail.gender);
    }

    public void fillCustomerDetailSection(MCleadCustomerDetail mCleadCustomerDetail) throws Exception {
        firstNameTextBox.setText(mCleadCustomerDetail.firstName);
        middleNameTextBox.setText(mCleadCustomerDetail.middleName);
        lastNameTextBox.setText(mCleadCustomerDetail.lastName);
        address1TextBox.setText(mCleadCustomerDetail.address1);
        address2TextBox.setText(mCleadCustomerDetail.address2);
        cityTextBox.setText(mCleadCustomerDetail.city);
        stateProvinceSelect.selectValueContainsOption(mCleadCustomerDetail.stateProvince);
        postalCodeTextBox.setText(mCleadCustomerDetail.postalCode);
        emailTextBox.setText(mCleadCustomerDetail.email);
        phoneTextBox.click();
        phoneTextBox.setText(mCleadCustomerDetail.phone);
        sendEmailSelect.selectValue(mCleadCustomerDetail.sendEmail);
    }

}
