package pages.orca.claim;

import control.*;
import org.openqa.selenium.By;
import session.Session;
import utils.Level;
import utils.Logger;
import java.util.HashMap;
import java.util.Map;

public class ClaimDetails {

    public Map<String, Select> controlSelect = new HashMap<>();
    public Map<String, Link> controlLinks = new HashMap<>();
    public TextBox receivedOnTextBox = new TextBox(By.xpath("//input[@id='ClaimDto_ReceivedOn' and @type='text']"));
    public TextBox adjusterNoteSearchTextBox = new TextBox(By.xpath("//*[@class='autocomplete ui-autocomplete-input']"));
    public TextBox adjusterNoteTextBox = new TextBox(By.xpath("//textarea[@id='adjuster-note']"));

    public TextBox adjusterNoteTextBoxFrame = new TextBox(By.xpath("//body[@data-id=\"adjuster-note\"]"));
    public Button sendToInvestigatorButton = new Button(By.xpath("//a[contains(.,'Send to Investigator')]"));
    public Button sendToQuickClaims = new Button(By.xpath("//a[contains(.,'Send to QuickClaims')]"));

    public Button regenerateDocs = new Button(By.id("btn-regenerate-docs-claim"));
    public Link claimsResultLink = new Link(By.xpath("//a[contains(text(),'Claims -')]"));
    public Map<String, Button> controlButtonClaimsDetail = new HashMap<>();
    public Button addLossesButton = new Button(By.xpath("//a[@title='Add Loss(es)']"));
    public Link viewClaimDetailsLink = new Link(By.xpath("//a[@title='Add Line Items']"));

    public Label policyNumber = new Label(By.xpath("//div[@class='controls']/a[contains(@href,'/Policy/PolicyDetail?policyId')]"));
    public Table lossesTable = new Table(By.xpath("//div[@id='losses-table']/table"));

    public Label statusLabel = new Label(By.xpath("//div/strong[text()='Status']/parent::*/parent::*/div[@class='controls']"));
    public Label underwriterLabel = new Label(By.xpath("//div/strong[text()='Underwriter']/parent::*/parent::*/div[@class='controls']"));
    public Button finalizeAllLossesButton = new Button(By.xpath("//div[@class='row-fluid'][1]//*[contains(text(),'Finalize All Loss(es)')]"));
    public Button returnToClaimButton = new Button(By.xpath("//a[@title='Return to Claim']"));
    public Table claimResultTable = new Table(By.xpath("//*[@id=\"policy-claims\"]/table"));

    public Table assignedTable  = new Table(By.xpath("//*[@id=\"status-3\"]/div/table/colgroup"));



    //Claim Attachment(s)
    public Map<String, Label> claimAttachmentTabDocTypeLabelsMap = new HashMap<>();
    public Link otherLink = new Link(By.xpath("//a[@data-placeholder-id=\"attachments-other\"]"));

    public Link termLink = new Link(By.xpath("//a[contains(@data-placeholder-id,'-attachments')]"));

    public Button claimsReissueDocButton = new Button(By.id("btn-reissue-claim-attachements"));

    public Checkbox claimsDocumentCheckbox = new Checkbox(By.xpath("//input[@data-hdn-id='SelectedAttachments']"));

     // regenerate document by id - section
    public Button regenerateButton = new Button(By.xpath("//button[@id=\"btn-regenerate-docs\"]"));
    public Select regenerateComboBox = new Select(By.xpath("//select[@id=\"select-document-type\"]"));

    //finance sub-tab
    public Button voidCheckButton = new Button(By.xpath("//a[@title='Void Check']"));
    public Label voidCheckLabel = new Label(By.xpath(" //h3[text()='Void Check']"));
    public Checkbox reissueCheckCheckbox = new Checkbox(By.xpath("//input[@id='IsReissuing']"));
    public Button voidCheckPopUpSaveButton = new Button(By.xpath("//div[@class='modal-footer btn-block']/button[@type='submit']"));
    public Label checkReissuedMessageLabel = new Label(By.xpath("//div[contains(text(),'has been reissued on')]"));

    public Label checkNumberOnPopupLabel = new Label(By.xpath("//input[@id='ClaimCheck_CheckNo']/parent::div"));

    public Link policyNumberLink = new Link(By.xpath("//input[@id='ClaimDto_PolicyId']/parent::div/a"));

    public ClaimDetails() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        controlSelect.put("Adjuster", new Select(By.id("assigned-to")));
        controlSelect.put("Auditor", new Select(By.xpath("//select[@id='auditor-sysuser-id']")));
        controlSelect.put("Priority", new Select(By.id("claim-priority")));
        controlSelect.put("Assistant", new Select(By.xpath("//select[@id='assistant-sysuser-id']")));
        controlSelect.put("Page Size Table", new Select(By.xpath("//select[@class='pagesize']")));

        controlLinks.put("Processing", new Link(By.id("processing-link")));
        controlLinks.put("Attachment(s)", new Link(By.xpath("//a[@title=\"Attachments(s)\" or @title=\"Attachment(s)\"]")));
        controlLinks.put("Finance", new Link(By.id("checks-link")));
        controlLinks.put("Note(s)", new Link(By.xpath("//a[@id='notes-link' or @title='Notes(s)']")));
        controlLinks.put("History", new Link(By.id("history-link")));
        controlLinks.put("Audit Return History", new Link(By.id("audit-return-history-link")));
        controlLinks.put("Request(s)", new Link(By.id("requests-link")));
        controlLinks.put("Claim(s)", new Link(By.xpath("//a[@title='Claim(s)']")));
        controlLinks.put("Follow-up(s)", new Link(By.xpath("//a[@title=\"Follow-up(s)\"]")));
        controlLinks.put("Finance and Cancellations-(1)", new Link(By.xpath("//a[normalize-space()='Finance and Cancellations - (1)']")));


        controlButtonClaimsDetail.put("Return to Policy", new Button(By.xpath("//div[@class='row-fluid'][1]//*[contains(text(),'Return to Policy')]")));
        controlButtonClaimsDetail.put("Submit to Processing", new Button(By.xpath("//div[@class='row-fluid'][1]//*[contains(text(),'Submit to Processing')]")));
        controlButtonClaimsDetail.put("Move Claims", new Button(By.xpath("//div[@class='row-fluid'][1]//*[contains(text(),'Move Claims')]")));
        controlButtonClaimsDetail.put("Place On Hold", new Button(By.xpath("//div[@class='row-fluid'][1]//*[contains(text(),'Place On Hold')]")));
        controlButtonClaimsDetail.put("Save", new Button(By.xpath("//div[@class='row-fluid'][1]//*[contains(text(),'Save')]")));
        controlButtonClaimsDetail.put("Finalize All Loss(es)", new Button(By.xpath("//div[@class='row-fluid'][1]//*[contains(text(),'Finalize All Loss(es)')]")));
        controlButtonClaimsDetail.put("Preview EOB", new Button(By.xpath("//div[@class='row-fluid'][1]//*[contains(text(),'Preview EOB')]")));
        controlButtonClaimsDetail.put("Complete Processing", new Button(By.xpath("//div[@class='row-fluid'][1]//*[contains(text(),'Complete Processing')]")));
        controlButtonClaimsDetail.put("Assign to Me", new Button(By.xpath("//div[@class='row-fluid'][1]//a[contains(.,' Assign to Me')]")));
        controlButtonClaimsDetail.put("Approve", new Button(By.xpath("//div[@class='row-fluid'][1]//a[contains(.,'Approve')]")));
        controlButtonClaimsDetail.put("Do not issue", new Button(By.xpath("//input[@id='do-not-issue']")));
        controlButtonClaimsDetail.put("X", new Button(By.xpath("//button[@id='closeDNIAlert']")));
        controlButtonClaimsDetail.put("Reopen Claim", new Button(By.xpath("//div[@class='row-fluid'][1]//*[contains(text(),'Reopen Claim')]")));

        claimAttachmentTabDocTypeLabelsMap.put("Claim Acknowledgement", new Label(By.xpath("//div[@class='span2 edit' and contains(text(),'Claim Acknowledgement')]")));
        claimAttachmentTabDocTypeLabelsMap.put("Claims", new Label(By.xpath("//div[@class='span2 edit' and contains(text(),'Claims')]")));
        claimAttachmentTabDocTypeLabelsMap.put("Uploaded Files", new Label(By.xpath("//div[@class='span2 edit' and contains(text(),'Uploaded Files')]")));
    }

    public String getLinkForClaimPDF() throws Exception {
        Link linkClaimPDF = new Link(By.xpath("//a[contains(@href,'attachments') and contains(@href,'.pdf')]"));
        return linkClaimPDF.getTextAttribute("href");
    }

    public void clickOnViewDeleteCellForPet(String petName, boolean isDeleteButton) throws Exception {
        String viewOrDelete = isDeleteButton ? "Delete Loss" : "Add Line Items";
        String xpath = "//div[@id='losses-table']/table//td[contains(.,\"" + petName + "\")]/parent::*/td/a[@title='" + viewOrDelete + "']";
        Button control = new Button(By.xpath(xpath));
        control.click();
    }

    public String getLinkForCancellationPDF() throws Exception {
        Link linkCancellationPDF = new Link(By.xpath("//a[contains(@href,'attachments') and contains(@href,'.pdf')]"));
        return linkCancellationPDF.getTextAttribute("href");
    }

    public int getNumberOfElementsOnAttachmentTable(String value){
        try {
            return Session.getInstance().getDriver().findElements(By.xpath("//div[contains(text(),'"+value+"') and @data-source]")).size();
        }catch (Exception e){
            return 0;
        }
    }
}