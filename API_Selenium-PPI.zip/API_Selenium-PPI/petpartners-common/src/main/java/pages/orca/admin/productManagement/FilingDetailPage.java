package pages.orca.admin.productManagement;

import control.*;
import org.openqa.selenium.By;

import java.util.HashMap;
import java.util.Map;

public class FilingDetailPage {
    public TextBox marketingTextBox = new TextBox(By.id("decPageDisplay"));

    public Button saveButton = new Button(By.id("saveButton"));

    public Label overviewLabel = new Label(By.xpath("//h5[text()='Overview']"));
    public Button editIcon = new Button(By.xpath("//div[@class='card-header']//button"));
    public Checkbox activeCheckbox = new Checkbox(By.xpath("//input[@id='active']"));
    public Label activateFilingConfirmationLabel = new Label(By.xpath("//h5[text()='Activate Filing Confirmation']"));
    public Table activateFilingConfirmationTable = new Table(By.xpath("//table[@class='table']"));
    public Label warningLabel = new Label(By.xpath(" //div[@class='alert alert-warning']/span"));
    public Button proceedNDeactivateButton= new Button(By.xpath("//button[text()='Proceed and Deactivate ']"));

    public Map<String,Button> productDetailsButtons = new HashMap<>();

    public FilingDetailPage(){
        productDetailsButtons.put("Edit",new Button(By.xpath("(//h5[text()='Product Details']/../..//button[@class=\"btn btn-info ms-auto\"])[1]")));
        productDetailsButtons.put("Cancel",new Button(By.id("cancelButton")));
    }
}
