package pages.orca.loss;

import control.*;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;

public class LossDetails {

    public TextBox claimNumberTextBox = new TextBox(By.xpath("//div[@class='controls']/input[@id='Loss_claim_id']/.."));
    public TextBox dateOfServiceTextBox = new TextBox(By.xpath("//input[@id='LossDto_DateOfService']"));
    public Select petSelect = new Select(By.xpath("//select[@id='pet' or @id='group-pet']"));
    public Select vetSelect = new Select(By.id("vet"));
    public Button findVetButton = new Button(By.xpath("//a[contains(.,'Find a Vet')]"));
    public Button incidentsPlusButton = new Button(By.xpath("//legend/span/a/i"));
    public Table incidentTable = new Table(By.xpath("//legend[contains(.,'Incidents')]/..//table"));
    public Map<String, Button> controlOverviewButton = new HashMap<>();
    public IncidentModal incidentModal = new IncidentModal();

    //Approved Section

    public Table approvedTable = new Table(By.xpath("//table[@class='table table-bordered loss-incident-lines']"));
    public Map<String, Cell> approvedTableCell = new HashMap<>();
    public Button addNewButton = new Button(By.xpath("//a[@data-append-id='approved-loss-line-items']"));
    public Map<String, Button> controlApprovedButton = new HashMap<>();
    public VetSearchModal vetSearchModal = new VetSearchModal();
    public Link viewlossdetailsLink = new Link(By.xpath("//a[@title='Add Line Items']"));
    public Label denialreason1Label = new Label(By.xpath("//h3[text()='Denial Reason: Exclusion and/or Secondary Condition']"));
    public Label denialreason2Label = new Label(By.xpath("//h3[text()='Denial Reason: Wellness']"));
    public Label denialreason3Label = new Label(By.xpath("//h3[text()='Denial Reason: Exam Fee']"));

    public Label denialReason4Label = new Label(By.xpath("//h3[contains(text(),'Denial Reason: Exclusion and/or Secondary Conditio')]"));

    public Label denialReason5Label = new Label(By.xpath("//h3[contains(text(),'Denial Reason: Anal Glands')]"));
    public Label denialReason6Label = new Label(By.xpath("//h3[contains(text(),'Denial Reason: Wellness')]"));
    public Label denialReasonHeader = new Label(By.xpath("//div[@id='loss']//h3[contains(text(),'Denial Reason')]"));
    public Label alertMessage = new Label(By.xpath("//div[@class='alert alert-error']"));
    public Label denialreasonForDnocLable = new Label(By.xpath("//h3[text()='Denial Reason: Close - Pending DNOC']"));
    public Button checkMarkButton = new Button(By.xpath("//input[@class='add-incident']"));
    public Label warningAlertLabel = new Label(By.xpath("//h3[@class='error']"));
    public TextBox denialCodeTextBox = new TextBox(By.id("DenialCodeText_autocomplete"));

    public Map<String, Button> denySection = new HashMap<>();




    public LossDetails() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        controlOverviewButton.put("Return to Claim", new Button(By.xpath("(//div[@class='pull-right']/a[@title='Return to Claim'])[1]")));
        controlOverviewButton.put("Request Medical Records", new Button(By.xpath("(//div[@class='pull-right']/a[@title='Request Medical Records'])[1]")));
        controlOverviewButton.put("Save", new Button(By.xpath("(//div[@class='pull-right']/*[@name='ButtonPressed'])[1]")));

        controlApprovedButton.put("Return to Claim", new Button(By.xpath("(//div[@class='pull-right']/a[@title='Return to Claim'])[last()]")));
        controlApprovedButton.put("Request Medical Records", new Button(By.xpath("(//div[@class='pull-right']/a[@title='Request Medical Records'])[last()]")));
        controlApprovedButton.put("Save", new Button(By.xpath("(//div[@class='pull-right']/*[@name='ButtonPressed'])[last()]")));

        approvedTableCell.put("Procedure", new Cell(2, "input", "Procedure"));
        approvedTableCell.put("Quantity",new Cell(3,"input","Quantity"));
        approvedTableCell.put("Description", new Cell(4, "input", "Description"));
        approvedTableCell.put("Incident", new Cell(5, "select", "Incident"));
        approvedTableCell.put("Submitted", new Cell(6, "input", "Submitted"));
        approvedTableCell.put("Allowed", new Cell(7, "input", "Allowed"));


        denySection.put("Deny",new Button(By.xpath("//a[text()=' Deny']")));
        denySection.put("Create a new Incident",new Button(By.xpath("//a[text()=' Create a New Denial Reason']")));
        denySection.put("Save", new Button(By.xpath("//button[@class='btn btn-success']")));
        denySection.put("Cancel",new Button(By.xpath("//button[@class='btn btn-inverse']")));



    }

}
