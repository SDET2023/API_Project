package pages.orca.admin.productManagement.addNewFilingSections;

import control.*;
import org.openqa.selenium.By;

import java.util.HashMap;
import java.util.Map;

public class SelectDocumentsSection {

    public Select stateTypeSelect = new Select(By.xpath("//select[@formcontrolname=\"documentAreaId\"]"));
    public Table resultStateTypeTable = new Table(By.xpath("//table[@class=\"table table-responsive table-borderless\"]"));
    public Label sectionDocumentLabel = new Label(By.xpath("//label[text()='Select Documents']"));
    public Button previousButton = new Button(By.xpath("//button[text()='Previous']"));
    public Button completeButton = new Button(By.xpath("//button[text()='Complete']"));
    public Label summaryLabel = new Label(By.xpath("//h4[text()=' Summary ']"));
    public Label stateFilingInformationLabel = new Label(By.xpath("//span[text()='State Filing Information']"));
    public Button stateRulesButton = new Button(By.xpath("//button[contains(text(),'State Rules')]"));
    public Button productsButton = new Button(By.xpath("//button[contains(text(),'Products')]"));
    public Button setRatesButton = new Button(By.xpath(" //button[contains(text(),'Set Rates')]"));

    public Map<String, Button> buttonMap = new HashMap<>();

    public Map<String, Label> labelMap = new HashMap<>();

    public  SelectDocumentsSection(){
        buttonMap.put("State Rules",stateRulesButton);
        buttonMap.put("Products",productsButton);
        buttonMap.put("Set Rates", setRatesButton);
        labelMap.put("State Filing Information",stateFilingInformationLabel);
    }
}
