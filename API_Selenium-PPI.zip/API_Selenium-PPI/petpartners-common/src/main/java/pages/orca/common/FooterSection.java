package pages.orca.common;

import control.Button;
import control.Label;
import org.openqa.selenium.By;
import org.openqa.selenium.support.Color;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;

public class FooterSection {
    public Button logoutButton = new Button(By.xpath("//a[text()='Log Out']"));
    public Label loggedInAsLabel = new Label(By.xpath("//footer//div[contains(text(),'Logged in as')]"));
    public Label serverDataBaseAsLabel = new Label(By.xpath("//footer//div[contains(text(),'Environment')]"));
    public Label signatureLabel = new Label(By.xpath("//footer//div[contains(text(),'PetPartners, Inc.')]"));


    public Map<String, Label> labelMap = new HashMap<>();

    public FooterSection() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        labelMap.put("Logged in as",loggedInAsLabel);
        labelMap.put("Environment",serverDataBaseAsLabel);
        labelMap.put("Signature",signatureLabel);
    }

    public String getUserLogged() throws Exception {
        String value = loggedInAsLabel.getText().replace("Logged in as", "");
        value = value.replace(" ", "").replace(":", "");
        return value;
    }

    public String getFooterColorFont(String section) throws Exception {
        String xpath= section.contains("Admin") || section.contains("Receiving") ||  section.contains("MarketChannels") ? "//footer/div" : "//footer";
        Label footerSection = new Label(By.xpath(xpath));
        String color= Color.fromString(footerSection.getCssAttribute("background-color")).asHex();
        return color;
    }
}
