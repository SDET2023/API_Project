package pages.orca.admin.productManagement.addNewFilingSections;

import control.Button;
import control.Label;
import org.openqa.selenium.By;

public class SummaryReviewSection {
    public Label summaryReviewLabel = new Label(By.xpath("//label[text()='Summary Review']"));
    public Label iDLabel = new Label(By.xpath("//strong[contains(text(),'ID')]//parent::div"));

    public Button submitButton = new Button(By.xpath("//button[text()='Submit']"));
    public Button exitButton = new Button(By.xpath("//button[text()='Exit']"));
    public Label exitFilingLabel = new Label(By.xpath("//h4[text()='Exit Filing?']"));
    public Button yesWantToExitButton = new Button(By.xpath("//button[text()='Yes, I want to Exit']"));
    public Label stateFilingSubmittedLabel = new Label(By.xpath("//h5[text()='State Filing Submitted']"));
    public Button takeMeBackToListingButton = new Button(By.xpath("//button[text()='Ok, take me back to listing']"));
    public Button approveButton = new Button(By.xpath("//button[text()='Approve']"));
    public Button denyButton = new Button(By.xpath("//button[text()='Deny']"));

}
