package pages.orca.admin.adminDashboard;

import control.Button;
import control.Checkbox;
import control.Table;
import control.TextBox;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;

public class AccountDetailPage {
    public Map<String, TextBox> textBoxMap = new HashMap<>();
    public Map<String, Checkbox> rolesCheckBoxMap = new HashMap<>();
    public Button cancelButton = new Button(By.xpath("//a[@title='Cancel']"));
    public Button saveButton = new Button(By.xpath("//button[contains(text(),'Save')]"));
    public Checkbox activeCheckBox = new Checkbox(By.id("SysUser_Active"));
    public TextBox firstNameTextBox = new TextBox(By.id("SysUser_FirstName"));
    public TextBox lastNameTextBox = new TextBox(By.id("SysUser_LastName"));
    public TextBox domainTextBox = new TextBox(By.id("SysUser_Domain"));
    public TextBox userNameTextBox = new TextBox(By.id("SysUser_Username"));
    public TextBox emailAddressTextBox = new TextBox(By.id("SysUser_Email"));

    public Table auditTrialTable = new Table(By.id("audit-sysuser-actions-table"));


    public AccountDetailPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        textBoxMap.put("First Name", firstNameTextBox);
        textBoxMap.put("Last Name", lastNameTextBox);
        textBoxMap.put("Domain", domainTextBox);
        textBoxMap.put("Username", userNameTextBox);
        textBoxMap.put("E-mail Address", emailAddressTextBox);


        rolesCheckBoxMap.put("Administrator", new Checkbox(By.xpath("//label[text()='Administrator']/preceding::input[1]")));
        rolesCheckBoxMap.put("Customer Service", new Checkbox(By.xpath("//label[text()='Customer Service']/preceding::input[1]")));
        rolesCheckBoxMap.put("Claims Specialist", new Checkbox(By.xpath("//label[text()='Claims Specialist']/preceding::input[1]")));
        rolesCheckBoxMap.put("Super Admin", new Checkbox(By.xpath("//label[text()='Super Admin']/preceding::input[1]")));
        rolesCheckBoxMap.put("Test", new Checkbox(By.xpath("//label[text()='Test']/preceding::input[1]")));
        rolesCheckBoxMap.put("Finance", new Checkbox(By.xpath("//label[text()='Finance']/preceding::input[1]")));
        rolesCheckBoxMap.put("Marketing", new Checkbox(By.xpath("//label[text()='Marketing']/preceding::input[1]")));
        rolesCheckBoxMap.put("Sales", new Checkbox(By.xpath("//label[text()='Sales']/preceding::input[1]")));
        rolesCheckBoxMap.put("Claims Admin", new Checkbox(By.xpath("//label[text()='Claims Admin']/preceding::input[1]")));
        rolesCheckBoxMap.put("Claims Auditor", new Checkbox(By.xpath("//label[text()='Claims Auditor']/preceding::input[1]")));
        rolesCheckBoxMap.put("Breeder Support Specialist", new Checkbox(By.xpath("//label[text()='Breeder Support Specialist']/preceding::input[1]")));
        rolesCheckBoxMap.put("Document Specialist", new Checkbox(By.xpath("//label[text()='Document Specialist']/preceding::input[1]")));
        rolesCheckBoxMap.put("Customer Service Administrator", new Checkbox(By.xpath("//label[text()='Customer Service Administrator']/preceding::input[1]")));
        rolesCheckBoxMap.put("Finance Admin", new Checkbox(By.xpath("//label[text()='Finance Admin']/preceding::input[1]")));
        rolesCheckBoxMap.put("Active", new Checkbox(By.id("SysUser_Active")));
    }

}
