package pages.orca.breeder;

import control.Button;
import control.Table;
import control.TextBox;
import java.util.HashMap;
import java.util.Map;
import org.openqa.selenium.By;

public class BreederSearchSection {
    public TextBox bsLastNameTextBox = new TextBox(By.xpath("//input[@id=\"BreederSearchCriteria_LastName\"]"));
    public TextBox bsEmailAddressTextBox = new TextBox(By.xpath("//input[@id=\"BreederSearchCriteria_EmailAddress\"]"));
    public Button breederRunSearchButton = new Button(By.xpath("//button[@class=\"btn btn-success\"]"));
    public Table searchResultsTable = new Table(By.id("mclead-search-results"));
    public Map<String, TextBox> textBoxMap = new HashMap();

    public BreederSearchSection() {
        this.textBoxMap.put("Last Name", this.bsLastNameTextBox);
        this.textBoxMap.put("Email Address", this.bsEmailAddressTextBox);
    }
}