package pages.orca.breeder;

import control.Button;
import control.Label;
import control.Select;
import control.TextBox;
import entities.orca.breeder.LitterDetailsOverviewEntity;
import java.util.HashMap;
import java.util.Map;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class LitterDetailsSection {
    public Map<String, Label> labelMap = new HashMap();
    public Label breederLabel = new Label(By.xpath("//div[@class=\"span4\"]/div/a"));
    public Label marketChannelLabel = new Label(By.xpath("//select[@id=\"market-channel\"]"));
    public Label welcomeSentLabel = new Label(By.xpath("//input[@id=\"Litter_WelcomeSent\"]"));
    public Label registrationNumberLabel = new Label(By.xpath("//input[@id=\"Litter_LitterRegNo\"]"));
    public Label registrationDateLabel = new Label(By.xpath("//input[@id=\"Litter_LitterRegDate\"]"));
    public Label dateOfBirthLabel = new Label(By.xpath("//input[@id=\"Litter_Dob\"]"));
    public Label breedLabel = new Label(By.xpath("//select[@id=\"Litter_BreedId\"]"));
    public Label maleCountLabel = new Label(By.xpath("//input[@id=\"Litter_MaleCount\"]"));
    public Label femaleCountLabel = new Label(By.xpath("//input[@id=\"Litter_FemaleCount\"]"));
    public Select ldMarketChannelSelect = new Select(By.xpath("//select[@name=\"Litter.MarketChannelId\"]"));
    public TextBox ldRegistrationNumberTextBox = new TextBox(By.xpath("//input[@id='Litter_LitterRegNo']"));
    public TextBox ldRegistrationDateTextBox = new TextBox(By.xpath("//input[@id=\"Litter_LitterRegDate\"]"));
    public TextBox ldDateOfBirthTextBox = new TextBox(By.xpath("//input[@id=\"Litter_Dob\"]"));
    public Select ldBreedSelect = new Select(By.xpath("//select[@id=\"breed-select\"]"));
    public TextBox ldMaleCountTextBox = new TextBox(By.xpath("//input[@id=\"Litter_MaleCount\"]"));
    public TextBox ldFemaleCountTextBox = new TextBox(By.xpath("//input[@id=\"Litter_FemaleCount\"]"));
    public Button ldSaveButton = new Button(By.xpath("//button[@class=\"btn btn-success\"]"));
    public Label coOwnerLabel = new Label(By.id("coOwners-link"));

    public LitterDetailsSection() {
        Level logInfo = Level.INFO;
        String testName = this.getClass().getName();
        Logger.log(logInfo, testName + "> Page: " + this.getClass().getSimpleName());
        this.labelMap.put("Breeder", new Label(By.xpath("//div[text()=\"Breeder\"]")));
        this.labelMap.put("Market Channel", new Label(By.xpath("//div[text()=\"Market Channel\"]")));
        this.labelMap.put("Welcome Sent", new Label(By.xpath("//div[text()=\"Welcome Sent\"]")));
        this.labelMap.put("Registration Number", new Label(By.xpath("//label[text()=\"Registration Number\"]")));
        this.labelMap.put("Registration Date", new Label(By.xpath("//label[text()='Registration Date']")));
        this.labelMap.put("Date of Birth", new Label(By.xpath("//label[text()=\"Date of Birth\"]")));
        this.labelMap.put("Breed", new Label(By.xpath("//label[text()=\"Breed\"]")));
        this.labelMap.put("Male Count", new Label(By.xpath("//label[text()=\"Male Count\"]")));
        this.labelMap.put("Female Count", new Label(By.xpath("//label[text()=\"Female Count\"]")));
    }

    public void fillLitterDetailsOverviewPage(LitterDetailsOverviewEntity litterDetailsOverviewEntity) throws Exception {
        Level logInfo = Level.INFO;
        String testName = this.getClass().getName();
        Logger.log(logInfo, testName + "> Fill Litter Details Overview: " + this.getClass().getSimpleName());
        this.ldMarketChannelSelect.selectValue(litterDetailsOverviewEntity.getLdMarketChannel());
        this.ldRegistrationNumberTextBox.setText(litterDetailsOverviewEntity.getLdRegistrationNumber());
        this.ldRegistrationDateTextBox.click();
        this.ldRegistrationDateTextBox.setTextAndTab(litterDetailsOverviewEntity.getLdRegistrationDate());
        this.ldDateOfBirthTextBox.setTextAndTab(litterDetailsOverviewEntity.getLdDateOfBirth());
        this.ldBreedSelect.selectValue(litterDetailsOverviewEntity.getLdBreed());
        this.ldMaleCountTextBox.setText(litterDetailsOverviewEntity.getLdMaleCount());
        this.ldFemaleCountTextBox.setText(litterDetailsOverviewEntity.getLdFemaleCount());
    }
}