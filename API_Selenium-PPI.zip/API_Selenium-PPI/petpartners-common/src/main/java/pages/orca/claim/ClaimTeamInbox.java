package pages.orca.claim;

import control.Label;
import control.Table;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class ClaimTeamInbox {

    public Label receivedDateClaimLabel = new Label(By.xpath("//*[@id='claims-queue']/div/h4"));

    public Table receivedDateClaimTable = new Table(By.xpath("//table[@id='claim-table']"));

    public ClaimTeamInbox() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }
}
