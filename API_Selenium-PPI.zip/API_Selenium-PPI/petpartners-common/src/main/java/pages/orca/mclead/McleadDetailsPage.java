package pages.orca.mclead;

import control.TextBox;
import org.openqa.selenium.By;

public class McleadDetailsPage {
    public TextBox salesforceIdTextBox = new TextBox(By.xpath("//input[@id = 'Pet_SalesforceId' and @type ='text']"));
}
