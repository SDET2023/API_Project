package pages.orca.admin.masterRate;

import control.Button;
import control.Checkbox;
import control.Select;
import control.TextBox;
import org.openqa.selenium.By;

import java.util.HashMap;
import java.util.Map;

public class MasterRateSheetDetailPage {

    public TextBox masterRateSheetIdTxtBox = new TextBox(By.xpath("//input[@formcontrolname=\"masterRateSheetId\"]"));
    public TextBox createdOnTxtBox = new TextBox(By.xpath("//input[@formcontrolname=\"createdOn\"]"));
    public Select rateSheetTypeSelect = new Select(By.xpath("//select[@formcontrolname=\"rateSheetType\"]"));
    public TextBox masterRateSheetNameTxtBox = new TextBox(By.xpath("//input[@formcontrolname=\"masterRateSheetName\"]"));
    public Select ratingFormulaSelect = new Select(By.xpath("//select[@id=\"ratingFormula\"]"));
    public TextBox rateVersionTxtBox = new TextBox(By.xpath("//input[@formcontrolname=\"rateVersion\"]"));
    public Checkbox activeCheckBox = new Checkbox(By.xpath("//label[contains(.,'Active')]/../input"));

    public Button uploadRateSheetsButton = new Button(By.xpath("//button[text()='Upload Rate Sheets']"));
    public Button editButton = new Button(By.xpath("//h5/../button"));
    public Button cancelButton = new Button(By.id("cancelButton"));
    public Button saveButton = new Button(By.id("saveButton"));
    public Map<String, Checkbox> factorSelectedCheckboxes =  new HashMap<>();
    public UploadRateSheetsTableSection uploadRateSheetsSectionTable = new UploadRateSheetsTableSection();
    public MasterRateSheetDetailPage(){
        factorSelectedCheckboxes.put("Age", new Checkbox(By.xpath("//label[contains(.,'Age')]/../input")));
        factorSelectedCheckboxes.put("Anal Gland Expression", new Checkbox(By.xpath("//label[contains(.,'Anal Gland Expression')]/../input")));
        factorSelectedCheckboxes.put("Coinsurance", new Checkbox(By.xpath("//label[contains(.,'Coinsurance')]/../input")));
        factorSelectedCheckboxes.put("Discount", new Checkbox(By.xpath("//label[contains(.,'Discount')]/../input")));
        factorSelectedCheckboxes.put("Max Increase", new Checkbox(By.xpath("//label[contains(.,'Max Increase')]/../input")));
        factorSelectedCheckboxes.put("Multiple Pet Discount", new Checkbox(By.xpath("//label[contains(.,'Multiple Pet Discount')]/../input")));
        factorSelectedCheckboxes.put("Policy Year", new Checkbox(By.xpath("//label[contains(.,'Policy Year')]/../input")));
        factorSelectedCheckboxes.put("Species Gender", new Checkbox(By.xpath("//label[contains(.,'Species Gender')]/../input")));
        factorSelectedCheckboxes.put("Zip Code", new Checkbox(By.xpath("//label[contains(.,'Zip Code')]/../input")));
        factorSelectedCheckboxes.put("Breed", new Checkbox(By.xpath("//label[contains(.,'Breed')]/../input")));
        factorSelectedCheckboxes.put("Base Rate", new Checkbox(By.xpath("//label[contains(.,'Base Rate')]/../input")));
        factorSelectedCheckboxes.put("Deductible", new Checkbox(By.xpath("//label[contains(.,'Deductible')]/../input")));
        factorSelectedCheckboxes.put("Endorsement", new Checkbox(By.xpath("//label[contains(.,'Endorsement')]/../input")));
        factorSelectedCheckboxes.put("Monthly Fee", new Checkbox(By.xpath("//label[contains(.,'Monthly Fee')]/../input")));
        factorSelectedCheckboxes.put("Optional Benefit", new Checkbox(By.xpath("//label[contains(.,'Optional Benefit')]/../input")));
        factorSelectedCheckboxes.put("Rates Plan", new Checkbox(By.xpath("//label[contains(.,'Rates Plan')]/../input")));
        factorSelectedCheckboxes.put("Trend", new Checkbox(By.xpath("//label[contains(.,'Trend')]/../input")));
        factorSelectedCheckboxes.put("Per Incident Limit", new Checkbox(By.xpath("//label[contains(.,'Per Incident Limit')]/../input")));
    }

}
