package pages.orca.breeder;

import control.Button;
import control.Label;
import control.Select;
import control.TextBox;
import entities.orca.breeder.BreederDetailsOverviewEntity;
import java.util.HashMap;
import java.util.Map;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class BreederDetails {
    public Map<String, Label> labelMap = new HashMap();
    public Label firstNameLabel = new Label(By.xpath("//input[@id=\"BreederDTO_FirstName\"]"));
    public Label lastNameLabel = new Label(By.xpath("//div[text()=\"Last Name\"]/..//input[@type=\"text\"]"));
    public Label emailLabel = new Label(By.xpath("//label[text()=\"Email\"]/..//input[@type=\"text\"]"));
    public Label phoneNoLabel = new Label(By.xpath("//input[@id=\"BreederDTO_PhoneNo\"]/..//input[@type=\"text\"]"));
    public Label address1Label = new Label(By.xpath("//input[@id=\"BreederDTO_Address1\"]/..//input[@type=\"text\"]"));
    public Label address2Label = new Label(By.xpath("//input[@id=\"BreederDTO_Address2\"]/..//input[@type=\"text\"]"));
    public Label cityLabel = new Label(By.xpath("//input[@id=\"BreederDTO_City\"]/..//input[@type=\"text\"]"));
    public Label stateLabel = new Label(By.xpath("//select[@id=\"BreederDTO_StateCode\"]"));
    public Label postalCodeLabel = new Label(By.xpath("//input[@id=\"BreederDTO_PostalCode\"]"));
    public Label sendEmailLabel = new Label(By.xpath("//input[@id=\"BreederDTO_SendEmail\"]"));
    public Label incentiveLabel = new Label(By.xpath("//input[@id=\"BreederDTO_BreederIncentiveSignedUpOn_HasValue\"]"));
    public TextBox bdFirstNameTextBox = new TextBox(By.xpath("//input[@id=\"BreederDTO_FirstName\"]"));
    public TextBox bdLastNameTextBox = new TextBox(By.xpath("//input[@id=\"BreederDTO_LastName\"]"));
    public TextBox bdEmailTextBox = new TextBox(By.xpath("//input[@id=\"BreederDTO_Email\"]"));
    public TextBox bdPhoneNoTextBox = new TextBox(By.xpath("//input[@id=\"BreederDTO_PhoneNo\"]"));
    public TextBox bdAddress1TextBox = new TextBox(By.xpath("//input[@id=\"BreederDTO_Address1\"]"));
    public TextBox bdAddress2TextBox = new TextBox(By.xpath("//input[@id=\"BreederDTO_Address2\"]"));
    public TextBox bdCityTextBox = new TextBox(By.xpath("//input[@id=\"BreederDTO_City\"]"));
    public Select bdStateSelect = new Select(By.xpath("//select[@id=\"BreederDTO_StateCode\"]"));
    public TextBox bdPostalCode = new TextBox(By.xpath("//input[@id=\"BreederDTO_PostalCode\"]"));
    public Button bdSaveButton = new Button(By.xpath("//button[@class=\"btn btn-success\"]"));
    public Button impersonateButton = new Button(By.xpath("//a[@class=\"btn btn-info\"]"));

    public TextBox getEmailTextBox(String email) {
        TextBox emailValue = new TextBox(By.xpath("//input[@value='" + email + "']"));
        return emailValue;
    }
    public BreederDetails() {
        Level logInfo = Level.INFO;
        String testName = this.getClass().getName();
        Logger.log(logInfo, testName + "> Page: " + this.getClass().getSimpleName());
        this.labelMap.put("First Name", new Label(By.xpath("//div[text()='First Name']")));
        this.labelMap.put("Last Name", new Label(By.xpath("//div[text()='Last Name']")));
        this.labelMap.put("Email", new Label(By.xpath("//label[text()='Email']")));
        this.labelMap.put("Phone No", new Label(By.xpath("//label[text()='Phone No']")));
        this.labelMap.put("Address 1", new Label(By.xpath("//label[text()='Address 1']")));
        this.labelMap.put("Address 2", new Label(By.xpath("//label[text()='Address 2']")));
        this.labelMap.put("City", new Label(By.xpath("//label[text()='City']")));
        this.labelMap.put("State/Province", new Label(By.xpath("//label[text()='State/Province']")));
        this.labelMap.put("Postal Code", new Label(By.xpath("//label[text()='Postal Code']")));
        this.labelMap.put("Send Email", new Label(By.xpath("//div[text()='Send Email']")));
        this.labelMap.put("Breeder Incentive", new Label(By.xpath("//div[text()='Breeder Incentive']")));
    }

    public void fillBreederDetailsOverviewPage(BreederDetailsOverviewEntity breederDetailsOverviewEntity) throws Exception {
        Level logInfo = Level.INFO;
        String testName = this.getClass().getName();
        Logger.log(logInfo, testName + "> Fill Litter Details Overview: " + this.getClass().getSimpleName());
        this.bdFirstNameTextBox.clear();
        this.bdFirstNameTextBox.setText(breederDetailsOverviewEntity.getBdFirstName());
        this.bdLastNameTextBox.clear();
        this.bdLastNameTextBox.setText(breederDetailsOverviewEntity.getBdLastName());
        this.bdEmailTextBox.clear();
        this.bdEmailTextBox.setText(breederDetailsOverviewEntity.getBdEmail());
        this.bdPhoneNoTextBox.clear();
        this.bdPhoneNoTextBox.setText(breederDetailsOverviewEntity.getBdPhoneNo());
        this.bdAddress1TextBox.clear();
        this.bdAddress1TextBox.setText(breederDetailsOverviewEntity.getBdAddress1());
        this.bdAddress2TextBox.clear();
        this.bdAddress2TextBox.setText(breederDetailsOverviewEntity.getBdAddress2());
        this.bdCityTextBox.clear();
        this.bdCityTextBox.setText(breederDetailsOverviewEntity.getBdCity());
        this.bdStateSelect.selectValue(breederDetailsOverviewEntity.getBdState());
        this.bdPostalCode.clear();
        this.bdPostalCode.setText(breederDetailsOverviewEntity.getBdPostalCode());
    }
}