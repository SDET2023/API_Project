package pages.orca.policy;

import control.Button;
import control.Select;
import org.openqa.selenium.By;
import utils.*;

public class TransferSaleDialog {
    public Button transferSaleButton = new Button(By.xpath("//div[@class='btn-block']/button[contains(text(),'Transfer Sale')]"));
    public Select userDropDown = new Select(By.xpath("//select[@id='targetSysUserSoldById']"));

    public TransferSaleDialog() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }

    public void transferSale(String user) throws Exception {
        this.userDropDown.selectValue(user);
        this.transferSaleButton.click();
    }
}
