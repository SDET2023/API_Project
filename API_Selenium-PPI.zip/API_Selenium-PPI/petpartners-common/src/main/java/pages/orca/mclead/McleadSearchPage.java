package pages.orca.mclead;

import control.*;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;
import java.util.HashMap;
import java.util.Map;

public class McleadSearchPage {

    public Select marketChannelSelect = new Select(By.xpath("//select[@id='selected-market-channel']"));
    public Label petDetailsTab = new Label(By.id("pet-search-link"));
    public Label customerDetailsTab = new Label(By.id("customer-search-link"));
    public TextBox registrationNoTextBox = new TextBox(By.id("SearchCriteria_RegistrationNo"));
    public Button runSearchButton = new Button(By.xpath("//button[contains(.,'Run Search')]"));
    public Link petDetailsLink = new Link(By.xpath("//table[@id='mclead-search-results']/tbody/tr/td/a[@class='selector']"));
    public TextBox lastNameTextBox = new TextBox(By.id("SearchCriteria_CustomerName"));
    public TextBox emailAddressTextBox = new TextBox(By.id("SearchCriteria_EmailAddress"));
    public TextBox phoneNumberTextbox = new TextBox(By.id("SearchCriteria_PhoneNumber"));
    public TextBox locationTextBox = new TextBox(By.id("SearchCriteria_Location"));
    public Table searchResultTable = new Table(By.xpath("//table[@id='mclead-search-results']"));
    public TextBox noteTextBox = new TextBox(By.id("note"));
    public Label searchTable = new Label(By.xpath("//div[@class='control-group']//blockquote"));
    public Map<String,Button> mcleadDetailsMap = new HashMap<>();
    public Link getMcLeadResultLink(String mcLeadRegNumber){
        return new Link(By.xpath("//table//a[@class='selector' and contains(text(),"+mcLeadRegNumber+")]"));
    }
    public McleadSearchPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        mcleadDetailsMap.put("Owner",new Button(By.id("owners-link")));
        mcleadDetailsMap.put("Note",new Button(By.id("notes-link")));
        mcleadDetailsMap.put("Add new",new Button(By.xpath("//a[@title='Add Note']")));
        mcleadDetailsMap.put("Cancel",new Button(By.xpath("//button[normalize-space()='Cancel']")));
        mcleadDetailsMap.put("Save",new Button(By.xpath("//button[@class='btn btn-success']")));
    }
}
