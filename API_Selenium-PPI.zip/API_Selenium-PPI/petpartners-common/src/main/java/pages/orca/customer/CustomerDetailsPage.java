package pages.orca.customer;

import control.*;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;


public class CustomerDetailsPage {
    public TextBox firstNameTextBox = new TextBox(By.xpath("//input[@id='Customer_FirstName']"));
    public Button saveButton = new Button(By.xpath("//button[@class='disable-after-click btn btn-success']"));
    public Link notesLink = new Link(By.xpath("//a[@title='Note(s)']"));
    public Table notesTab = new Table(By.xpath("//div[@id='notes-table']"));

    public TextBox altPhoneNumberTextBox = new TextBox(By.xpath("//input[@id='Customer_AlternatePhone']"));

    public TextBox phoneNumberTextBox = new TextBox(By.xpath("//input[@id='Customer_PhoneDay']"));

    public TextBox textBoxCustomerEmail = new TextBox(By.xpath("//input[@id='Customer_Email']"));
    public TextBox textBoxCustomerPhone = new TextBox(By.xpath("//input[@id='Customer_PhoneDay']"));

    public TextBox lastNameTextBox = new TextBox(By.xpath("//input[@id='Customer_LastName']"));
    public TextBox phoneTextBox = new TextBox(By.xpath("//input[@id='Customer_PhoneDay']"));

    public TextBox emailTextBox = new TextBox(By.xpath("//input[@id='Customer_Email']"));
    public TextBox customerAddress1TextBox = new TextBox(By.xpath("//input[@id='Customer_Address1']"));
    public TextBox customerCityTextBox = new TextBox(By.xpath("//input[@id='Customer_City']"));
    public TextBox customerPostalCodeTextBox = new TextBox(By.xpath("//input[@id='Customer_PostalCode']"));
    public Select stateDropdown = new Select(By.xpath("//select[@id='Customer_StateProvId']"));
    public Button popupSaveButton = new Button(By.xpath("//form[@class='modal-form']//following-sibling::button[text()=' Save']"));

    public Button addNewCustomersButton = new Button(By.xpath("//a[@title=\"Add Customer\"]"));

    public Button createANewCustomerButton = new Button(By.xpath("//a[contains(text(),' Create a New Customer')]"));

    public Checkbox sameAddressAsPrimaryCheckBox = new Checkbox(By.id("SameAddressAsPrimary"));

    public Button customerDetailsPagesaveButton = new Button(By.xpath("//div[@class='modal-footer']//button[@class='disable-after-click btn btn-success']"));


    public TextBox customerAddress2TextBox = new TextBox(By.xpath("//input[@id='Customer_Address2']"));



    public Map<String, TextBox> textBoxMap = new HashMap<>();

    public CustomerDetailsPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        textBoxMap.put("FIRST NAME", firstNameTextBox);
        textBoxMap.put("LAST NAME", lastNameTextBox);
        textBoxMap.put("EMAIL ADDRESS", emailTextBox);
        textBoxMap.put("PHONE NUMBER", phoneTextBox);
        textBoxMap.put("ADDRESS1", customerAddress1TextBox);
        textBoxMap.put("CITY", customerCityTextBox);
        textBoxMap.put("ZIPCODE", customerPostalCodeTextBox);
        textBoxMap.put("ADDRESS2" , customerAddress2TextBox);
     }

    public String getCustomerDetails(String fileText) throws Exception {
        TextBox fileName = new TextBox(By.xpath("//input[@id='"+fileText+"']"));
        return fileName.getText();
    }
}
