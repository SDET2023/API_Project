package pages.orca.admin.masterRate;

import control.Button;
import control.Label;
import control.TextBox;
import org.openqa.selenium.By;

import java.util.HashMap;
import java.util.Map;

public class RateSheetUploadPage {

    public Button uploadDeductibleButton = new Button(By.xpath("//button[text()='Upload Deductible']"));
    public Button uploadOptionalBenefitButton = new Button(By.xpath("//button[text()='Upload Optional Benefit']"));
    public Button uploadCoinsuranceButton = new Button(By.xpath("//button[text()='Upload Coinsurance']"));
    public Button uploadDiscountButton = new Button(By.xpath("//button[text()='Upload Discount']"));
    public Button uploadBreedButton = new Button(By.xpath("//button[text()='Upload Breed']"));
    public Button uploadMaxIncreaseButton = new Button(By.xpath("//button[text()='Upload Max Increase']"));
    public Button uploadMultiPetDiscountButton = new Button(By.xpath("//button[text()='Upload Multiple Pet Discount']"));
    public Button uploadBaseRateButton = new Button(By.xpath("//button[text()='Upload Base Rate']"));
    public Button uploadMonthlyFeeButton = new Button(By.xpath("//button[text()='Upload Monthly Fee']"));
    public Button uploadPolicyYearButton = new Button(By.xpath("//button[text()='Upload Policy Year']"));
    public Button uploadAnalGlandExpressionButton = new Button(By.xpath("//button[text()='Upload Anal Gland Expression']"));
    public Button uploadZipCodeButton = new Button(By.xpath("//button[text()='Upload Zip Code']"));
    public Button uploadEndorsementButton = new Button(By.xpath("//button[text()='Upload Endorsement']"));
    public Button uploadPerIncidentLimitButton = new Button(By.xpath("//button[text()='Upload Per Incident Limit']"));
    public Button uploadAgeButton = new Button(By.xpath("//button[text()='Upload Age']"));
    public Button uploadTrendButton = new Button(By.xpath("//button[text()='Upload Trend']"));
    public Button uploadSpeciesGenderButton = new Button(By.xpath("//button[text()='Upload Species Gender']"));
    public Button uploadRatesPlanButton = new Button(By.xpath("//button[text()='Upload Rates Plan']"));

    public Map<String,Button> buttonMap = new HashMap<>();

    public TextBox uploadFileTextBox = new TextBox(By.xpath("//input[@id='file']"));
    public Button cancelButton = new Button(By.id("cancelButton"));
    public Button uploadButton = new Button(By.id("saveButton"));

    public Label successfullyMessage = new Label(By.xpath("//div[contains(text(),'Success')]"));
    public Button okButton =  new Button(By.xpath("//div[contains(text(),'Ok')]"));

    public RateSheetUploadPage(){
        buttonMap.put("Upload Deductible",uploadDeductibleButton);
        buttonMap.put("Upload Optional Benefit",uploadOptionalBenefitButton);
        buttonMap.put("Upload Coinsurance",uploadCoinsuranceButton);
        buttonMap.put("Upload Discount",uploadDiscountButton);
        buttonMap.put("Upload Breed",uploadBreedButton);
        buttonMap.put("Upload Max Increase",uploadMaxIncreaseButton);
        buttonMap.put("Upload Multiple Pet Discount",uploadMultiPetDiscountButton);
        buttonMap.put("Upload Base Rate",uploadBaseRateButton);
        buttonMap.put("Upload Monthly Fee",uploadMonthlyFeeButton);
        buttonMap.put("Upload Policy Year",uploadPolicyYearButton);
        buttonMap.put("Upload Anal Gland Expression",uploadAnalGlandExpressionButton);
        buttonMap.put("Upload Zip Code",uploadZipCodeButton);
        buttonMap.put("Upload Endorsement",uploadEndorsementButton);
        buttonMap.put("Upload Per Incident Limit",uploadPerIncidentLimitButton);
        buttonMap.put("Upload Age",uploadAgeButton);
        buttonMap.put("Upload Trend",uploadTrendButton);
        buttonMap.put("Upload Species Gender",uploadSpeciesGenderButton);
        buttonMap.put("Upload Rates Plan",uploadRatesPlanButton);
    }

    public void uploadDeductibleLimitRateFactor(String uploadButtonName, String file) throws Exception {
        buttonMap.get(uploadButtonName).click();
        buttonMap.get(uploadButtonName).controlIsNotDisplayed(2);
        uploadFileTextBox.setText(file);
        uploadButton.click();
        // successfully alert
        successfullyMessage.controlIsDisplayed(30);
        okButton.click();
    }
}
