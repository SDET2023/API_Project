package pages.orca.finance;

import control.Button;
import control.Table;
import org.openqa.selenium.By;

public class InvoiceDetailsModalWindowPage {
    public Table invoiceDetailsTable = new Table(By.xpath("//div[@class='modal-body']/table[@id='transactions-table']"));

    public Button closeButton = new Button(By.xpath("//button[contains(.,'Close')]"));
}