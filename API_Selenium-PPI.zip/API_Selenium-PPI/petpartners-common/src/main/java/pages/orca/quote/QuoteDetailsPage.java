package pages.orca.quote;

import control.*;
import org.openqa.selenium.By;

public class QuoteDetailsPage {
    public Button petTableMakeChangesButton = new Button(By.xpath("//a[@id='btn-edit-coverage']"));
    public Button plusButton = new Button(By.xpath("//div[@class=\"plus toggle span1\"]"));
    public Table covPetDetailsTable = new Table(By.xpath("//table[@class='table table-striped table-bordered coverages']"));
    public Table coverageDetailsTable = new Table(By.xpath("//table[@class='table table-striped table-bordered']"));

    public Button saveButton = new Button(By.xpath("//*[@id='quote-actions']//button[contains(.,'Save') and not(contains(.,'policy'))]"));
    public Button returnToPolicyButton = new Button(By.xpath("//*[@id='quote-actions']//a[contains(.,'Return to Policy')]"));

    public Button addPetButton= new Button(By.xpath("//a[contains(.,'Add Pet')]"));
    public Button newPetOption = new Button(By.xpath("//a[contains(.,'New Pet')]"));
    public Button existingPetOption = new Button(By.xpath("//a[contains(.,'Existing Pet')]"));
    public Select groupDropDown = new Select(By.xpath("//select[@id='affinity-group-select']"));


  /*
  * we have coverage period for each pet and we have several cancel coverage
  * */
    public void clickCancelButtonInRow(String petNameInTable) throws Exception {
        Button cancelButton = new Button(By.xpath("//td/div/div[contains(.,'"+petNameInTable+"')]/../../..//a[contains(.,'Cancel Coverage')]"));
        cancelButton.controlIsDisplayed();
        cancelButton.click();
    }

    public String getMessageInPetNameRow(String petNameInTable) throws Exception {
        Label label= new Label(By.xpath("//td/div/div[contains(.,'"+petNameInTable+"')]//strong"));
        return  label.getText();
    }

}
