package pages.orca.policy;

import control.Button;
import control.Select;
import control.TextBox;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;


import java.util.HashMap;
import java.util.Map;

public class EditPaymentPage {

    public Map<String, Button> editPaymentButtons = new HashMap<>();

    //Payment option details table

    public Select paymentType = new Select(By.xpath("//select[@id='select-payment-type']"));
    public Select cardType = new Select(By.xpath("//select[@id='card_type_id']"));
    public TextBox cardNumberTextBox = new TextBox(By.id("card_number"));
    public TextBox expirationDateTextBox = new TextBox(By.id("expires_on"));
    public TextBox cvvTextBox = new TextBox(By.id("cvv"));
    public Button saveButton  = new Button(By.xpath("//div[@class='modal-footer btn-block']//button[@type='submit'][normalize-space()='Save']"));
    public Button cancelButton = new Button(By.xpath("//button[@class='btn'][normalize-space()='Cancel']"));

    public EditPaymentPage() {

        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        editPaymentButtons.put("Create a new",new Button(By.xpath("//a[normalize-space()='Create New']")));
        editPaymentButtons.put("Cancel",new Button(By.xpath("//button[@data-dismiss='modal'][normalize-space()='Cancel']")));
        editPaymentButtons.put("Unassign Payment option",new Button(By.xpath("//a[@class='pull-left btn btn-danger']")));

    }
}
