package pages.orca.breeder;

import control.Button;
import control.Link;
import control.Table;
import org.openqa.selenium.By;

public class YourBreederPortal {
    public Table coverageGetFormsTable = new Table(By.cssSelector(".rounded_table.full_table.striped_table.datalist"));
    public Link downloadLink = new Link(By.xpath("//a[text()=\"Download \"]"));
    public Button printFormButton = new Button(By.xpath("//a[text()=\"Print Form\"]"));

    public YourBreederPortal() {
    }
}
