package pages.orca.admin.documentManagement;

import control.Button;
import org.openqa.selenium.By;
import pages.orca.admin.documentManagement.addFileSections.*;

public class DocumentLibraryAddFilePage {

    public DocumentInformationSection documentInformationSection = new DocumentInformationSection();
    public PreviewDocumentSection previewDocumentSection = new PreviewDocumentSection();
    public SampleDataSection sampleDataSection = new SampleDataSection();
    public UploadFileSection uploadFileSection = new UploadFileSection();
    public UploadSuccessfulDialog uploadSuccessfulDialog = new UploadSuccessfulDialog();
    public Button nextButton = new Button(By.xpath("//button[contains(.,'Next')]"));
    public Button previousButton = new Button(By.xpath("//button[contains(.,'Previous')]"));
    public Button submitButton = new Button(By.xpath("//button[contains(.,'Submit')]"));
}
