package pages.orca.admin.adminDashboard;

import control.*;
import org.openqa.selenium.By;

import utils.Level;
import utils.Logger;

import java.util.*;

public class UserManagementPage {
    public Map<String, TextBox> textBoxMap = new HashMap<>();
    public Button clearButton = new Button(By.xpath("//a[contains(text(),'Clear')]"));
    public Button runSearchButton = new Button(By.id("btn-run-search"));
    public Button addNewButton = new Button(By.xpath("//a[contains(text(),' Add New')]"));
    public Table searchResultTable = new Table(By.id("search-results"));

    public TextBox syUserIdTextBox = new TextBox(By.id("SearchCriteria_SysuserId"));
    public TextBox userNameTextBox = new TextBox(By.id("SearchCriteria_UserName"));
    public TextBox firstNameTextBox = new TextBox(By.id("SearchCriteria_FirstName"));
    public TextBox lastNameTextBox = new TextBox(By.id("SearchCriteria_LastName"));
    public TextBox emailAddress = new TextBox(By.id("SearchCriteria_EmailAddress"));
    public TextBox brokerIdTextBox = new TextBox(By.id("SearchCriteria_BrokerId"));
    public Button registerButton = new Button(By.xpath("//table[@id='search-results']//td/a[@class='ajax-post btn btn-primary btn-mini']"));
    public Button viewButton = new Button(By.xpath("//table[@id='search-results']//td/a[@class='btn btn-info btn-mini']"));

    public Button syuserIdSortButton= new Button(By.xpath("//th[text()='Sysuser Id']"));
    public Button userSortButton = new Button(By.xpath("//th[text()='User']"));
    public Button actionButton = new Button(By.xpath("//th[text()='Actions']"));

    public Button brokerButton = new Button(By.xpath("//th[text()='Broker']"));

    public Table syUserIdResultLable = new Table(By.xpath("//*[@id=\"search-results\"]//tr//td[1]"));

    public Table userResultTable = new Table(By.xpath("//*[@id=\"search-results\"]//tr//td[2]"));

    public Select paginationPropertyDropdown = new Select(By.xpath("//*[@id=\"pager\"]/form/select"));


    public UserManagementPage() {
        Logger.log(Level.INFO,this.getClass().getName()+"> Page: "+this.getClass().getSimpleName());
        textBoxMap.put("Sysuser Id",syUserIdTextBox);
        textBoxMap.put("User Name",userNameTextBox);
        textBoxMap.put("First Name",firstNameTextBox);
        textBoxMap.put("Last Name",lastNameTextBox);
        textBoxMap.put("Email Address",emailAddress);
        textBoxMap.put("Broker ID",brokerIdTextBox);

    }
}
