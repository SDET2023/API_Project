package pages.orca.admin.documentManagement.addFileSections;

import control.Button;
import control.Label;
import org.openqa.selenium.By;

public class UploadSuccessfulDialog {
    public Button returnToDocumentLibraryButton = new Button(By.xpath("//button[contains(.,'Return to Document Library')]"));


    public boolean checkAlertMessage(String message){
        Label messageLabel = new Label(By.xpath("//*[contains(.,'"+message+"')]"));
        return messageLabel.controlIsDisplayed(15);
    }

}
