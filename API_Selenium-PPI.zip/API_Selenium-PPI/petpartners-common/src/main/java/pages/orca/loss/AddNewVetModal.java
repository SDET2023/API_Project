package pages.orca.loss;

import control.Button;
import control.Select;
import control.TextBox;
import org.openqa.selenium.By;

import java.util.HashMap;
import java.util.Map;

public class AddNewVetModal {

    public TextBox vetNameTextBox = new TextBox(By.id("Vet_name"));
    public TextBox vetAddressOneTextBox = new TextBox(By.id("Vet_address1"));
    public TextBox cityTextBox = new TextBox(By.id("Vet_city"));
    public Select stateProvinceDropdown = new Select(By.id("Vet_state_prov_id"));
    public TextBox postalCodeTextBox = new TextBox(By.id("Vet_postal_code"));
    public TextBox phoneTextBox = new TextBox(By.id("Vet_phone_day"));
    public TextBox emailTextBox = new TextBox(By.id("Vet_email"));
    public Button saveButton = new Button(By.id("btn-save"));

    public Map<String,TextBox> textBoxMap = new HashMap<>();
    public Map<String, Button> buttonMap = new HashMap<>();

    public  AddNewVetModal(){
        textBoxMap.put("Vet Name",vetNameTextBox);
        textBoxMap.put("Address 1",vetAddressOneTextBox);
        textBoxMap.put("City",cityTextBox);
        textBoxMap.put("Postal Code",postalCodeTextBox);
        textBoxMap.put("Phone",phoneTextBox);
        textBoxMap.put("Email",emailTextBox);
        buttonMap.put("Save",saveButton);
    }

    public void fillDetailsOnNewVetModal(String fieldName, String fieldValue) throws Exception {
        if( fieldName.contains("StateProvince")) {
            this.stateProvinceDropdown.selectValue(fieldValue);
        } else{
            textBoxMap.get(fieldName).setText(fieldValue);
        }
    }

}
