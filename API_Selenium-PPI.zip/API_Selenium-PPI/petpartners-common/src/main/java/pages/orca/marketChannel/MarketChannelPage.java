package pages.orca.marketChannel;

import control.*;
import org.openqa.selenium.By;

import java.util.HashMap;
import java.util.Map;

public class MarketChannelPage {
    public Map<String , Link> marketChannelNameLinkMap = new HashMap<>();

    public TextBox marketChannelNameTextBox = new TextBox(By.xpath("//span[contains(.,'Market channel name')]/../input[position() < last()]"));
    public TextBox marketChannelIdTextBox = new TextBox(By.xpath("//span[contains(.,'Market channel name')]/../input[last()]"));

    public Checkbox marketChannelActiveCheckBox = new Checkbox(By.xpath("//input[@class='form-check-input ms-2 ng-untouched ng-pristine ng-valid']"));
    public Button marketChannelSearchButton = new Button(By.xpath("//button[@class='btn btn-primary']"));
    public Button marketChannelClearButton = new Button(By.xpath("//button[@class='btn btn-outline-secondary']"));
    public Link marketChannelDashboardLink = new Link(By.xpath("//*[contains(text(),'Market Channel Dashboard')]"));
    public Link newMarketChannelLink = new Link(By.xpath("//*[contains(text(),'New Market Channel')]"));
    public Table marketChannelNamesTable = new Table(By.xpath("//div[@class='main-content']//pp-market-channel-dashboard//table"));
    public Link marketChannelTab = new Link(By.xpath("//a[text()='Market channel']"));
    public Link marketChannelDashboard = new Link(By.xpath("//a[text()=' Market Channel Dashboard ']"));

    public MarketChannelPage(){
        marketChannelNameLinkMap.put("PET",new Link(By.xpath("//div[contains(text(),' PET - PetPartners, Inc.')]")));
        marketChannelNameLinkMap.put("AKC",new Link(By.xpath("//div[contains(text(),' AKC - AKC Pet Insurance ')]")));
        marketChannelNameLinkMap.put("CFA",new Link(By.xpath("//div[contains(text(),' CFA - Cat Fanciers Association ')]")));
        marketChannelNameLinkMap.put("CAR",new Link(By.xpath("//div[contains(text(),' CAR - Companion Animal Recovery ')]")));
        marketChannelNameLinkMap.put("TOTO",new Link(By.xpath("//div[contains(text(),' TOTO - Toto Pet Insurance ')]")));
        marketChannelNameLinkMap.put("FLX",new Link(By.xpath("//div[contains(text(),' FLX - Felix Cat Insurance ')]")));
        marketChannelNameLinkMap.put("SCRATCH",new Link(By.xpath("//div[contains(text(),' SCRATCH - Scratchpay Pet Insurance ')]")));
    }
}
