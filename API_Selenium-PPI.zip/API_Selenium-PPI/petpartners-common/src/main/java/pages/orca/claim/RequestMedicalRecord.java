package pages.orca.claim;

import control.Button;
import control.Select;
import control.Table;
import control.TextBox;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;

public class RequestMedicalRecord {

    public Select requestTypeDropdown = new Select(By.id("request-type-id"));

    public Select petDropdown = new Select(By.id("pet-id"));

    public Select vetDropdown = new Select(By.id("vet-id"));

    public TextBox requestSearch = new TextBox(By.xpath("//input[@placeholder='Search for Requests']"));

    public Button allMrsButton = new Button(By.xpath("//a[text()='All MRs']"));

    public Table medicalRecordTable = new Table(By.xpath("//*[@id=\"requests\"]/div/table"));
    public Button resetButton = new Button(By.xpath("//a[@title='Reset Claim Status To Requested Medical Records']"));

    public Map<String, Button> medicalRecordPageButton = new HashMap<>();


    public RequestMedicalRecord() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        medicalRecordPageButton.put("MedicalRecord",new Button(By.xpath("//a[text()=' Request Medical Records']")));
        medicalRecordPageButton.put("Create New",new Button(By.xpath("//a[text()=' Create New']")));
        medicalRecordPageButton.put("Save",new Button(By.cssSelector("div[class='modal-footer'] button[type='submit']")));
        medicalRecordPageButton.put("Send",new Button(By.xpath("//*[@id=\"form0\"]/div//button[@type='submit']")));
    }
}
