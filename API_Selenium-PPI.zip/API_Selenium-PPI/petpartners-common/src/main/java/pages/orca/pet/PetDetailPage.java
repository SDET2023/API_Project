package pages.orca.pet;

import control.*;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;

public class PetDetailPage {

    public Label petDetailLabel = new Label(By.xpath("//h2[text()='Pet Detail']"));
    public Map<String, TextBox> petDetailTextBox = new HashMap<>();
    public Map<String, Select> petDetailSelect = new HashMap<>();
    public Map<String, Label> petDetailTabOption = new HashMap<>();

    // Claims tab option
    public Table claimsTable = new Table(By.xpath("//div[@id='claims']/table"));

    public Button saveButton = new Button(By.xpath("//button[contains(.,'Save')]"));

    // Allowances
    public Table allowanceTable = new Table(By.xpath("//table[@class=\"table table-striped table-bordered tablesorter\"]"));

    //Waiting Period Waiver
    public Table waitingPeriodWaiverHistoryTable = new Table(By.xpath("//div[@id='waitingperiodwaiverhistory']/table[@class='table table-striped table-bordered tablesorter']"));
    public Label waitingPeriodWaiverNoResultsLabel = new Label(By.xpath("//div[@id='waitingperiodwaiverhistory']/div[contains(text(),'No Results(s)')]"));

    public PetDetailPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        petDetailTextBox.put("Pet Name", new TextBox(By.xpath("//input[@id='Pet_PetName']")));
        petDetailTextBox.put("Call Name", new TextBox(By.id("Pet_CallName")));
        petDetailTextBox.put("DOB", new TextBox(By.id("Pet_Dob")));
        petDetailTextBox.put("Registration No", new TextBox(By.id("Pet_RegistrationNumber")));

        petDetailSelect.put("Gender", new Select(By.id("Pet_GenderId")));
        petDetailSelect.put("Species", new Select(By.id("Pet_SpeciesId")));
        petDetailSelect.put("Breed", new Select(By.id("breed-select")));
        petDetailSelect.put("Waiting Period Waiver", new Select(By.xpath("//select[@id=\"waiting-period-waiver-select\"]")));

        petDetailTabOption.put("Incident(s)", new Label(By.id("incidents-link")));
        petDetailTabOption.put("Attachment(s)", new Label(By.xpath("//a[@title='Attachments(s)']")));
        petDetailTabOption.put("Claim(s)", new Label(By.xpath("//a[@title='Claim(s)']")));
        petDetailTabOption.put("Benefit Schedule", new Label(By.xpath("//a[@title='Benefit Schedule']")));
        petDetailTabOption.put("Allowance", new Label(By.xpath("//a[@title=\"Allowance\"]")));
        petDetailTabOption.put("Waiting Period Waiver History", new Label(By.id("waitingperiodwaiverhistory-link")));

    }
}
