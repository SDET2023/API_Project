package pages.orca.partner;

import control.*;
import org.openqa.selenium.By;

import java.util.HashMap;
import java.util.Map;

public class PartnersPage {
    public Link addPartnerLink = new Link(By.xpath("//a[contains(text(),'Add Partner')]"));
    public TextBox partnerNameTextBox = new TextBox(By.xpath("//input[@id = 'SearchCriteria_Display' and @type ='text']"));
    public TextBox partnerCodeTextBox = new TextBox(By.id("SearchCriteria_Code"));
    public Select marketChannelSelect = new Select(By.id("SearchCriteria_MarketChannelId"));
    public Button partnersRunSearchButton = new Button(By.id("btn-run-search"));
    public Button clearSearchButton = new Button(By.xpath("//a[contains(text(),'Clear')]"));
    public Table partnerResultTable = new Table(By.xpath("//table[@id='groups-table']"));
    public Select amountOfResultsSelect = new Select(By.xpath("//select[contains(@class,'pagesize')]"));

    public Map<String, TextBox> textBoxMap = new HashMap<>();

    public PartnersPage(){
        textBoxMap.put("Partner Name", partnerNameTextBox);
        textBoxMap.put("Partner Code", partnerCodeTextBox);
    }
}
