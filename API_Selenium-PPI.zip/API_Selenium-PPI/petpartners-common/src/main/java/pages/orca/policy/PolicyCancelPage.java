package pages.orca.policy;

import control.*;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;

public class PolicyCancelPage {

    //Orca Policy cancel Page

    public Button cancelPolicyButton = new Button(By.xpath("//a[text()=' Cancel Coverage']"));

    public TextBox cancelRequestOnTextBox = new TextBox(By.id("CancelRequestedOn"));

    public TextBox notesTextBox  = new TextBox(By.id("Notes"));

    public Select cancelReasonDropdown = new Select(By.id("CancelReasonId"));

    public TextBox petnameTextBox = new TextBox(By.xpath("//input[@formcontrolname='petName']"));

    public TextBox cancelNotesTextBox = new TextBox(By.id("Notes"));

    public Button body = new Button(By.id("dialog-content"));

    public Select cancelTypeDropdown = new Select(By.id("CancelTypeId"));

    //Save button on cancel coverage page

    public Button saveButton = new Button(By.xpath("//div[@class='modal-footer btn-block']//i[@class='icon-white icon-ok-circle']"));

    public Button returnPolicyButton = new Button(By.xpath("//*[@id=\"quote-actions\"]/a"));

    public Label warningLabel = new Label(By.xpath("//tr[@class='warning']"));
    public Label cancelCoverage = new Label(By.xpath("//div[contains(text(),'Test')]"));

    public Button submitApprovalButton = new Button(By.xpath("//a[text()=' Submit for Approval']"));

    public Button approveCancellationButton = new Button(By.xpath("//a[text()=' Approve Cancellation']"));
    public Button approveChangesButton = new Button(By.id("btn-approve-changes"));

    public Map<String, Button> buttonsMap = new HashMap<>();
    public Button previewButton = new Button(By.id("preview"));
    public Button submitButton = new Button(By.id("submit-cancellation"));

    public PolicyCancelPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        buttonsMap.put("Preview", previewButton);
        buttonsMap.put("Submit", submitButton);
    }
}