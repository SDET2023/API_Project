package pages.orca.policy.noteTab;

import control.Button;
import control.Checkbox;
import control.TextBox;
import org.openqa.selenium.By;

public class AddNoteSection {
    public Checkbox customerContactCheckBox = new Checkbox(By.id("contact_customer"));
    public TextBox detailTextBox = new TextBox(By.id("noteTextBox"));
    public Button saveButton = new Button(By.xpath("//div[@class='modal-footer']/button[contains(.,'Save')]"));

    public TextBox typeHereTextBox = new TextBox(By.xpath("//body[@data-id=\"noteTextBox\"]"));


}
