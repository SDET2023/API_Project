package pages.orca.loss;

import control.*;
import entities.orca.IncidentEntity;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;

public class IncidentModal {

    public Button createANewIncidentButton = new Button(By.xpath("//div/a[@title='Add New Incident']"));
    public Button cancelButton = new Button(By.xpath("//button[contains(.,'Cancel')]"));
    public Button saveButton = new Button(By.xpath("//div[@id='dialog-content']//button[contains(.,'Save')]"));
    public Table incidentTable = new Table(By.xpath("//div[@id='dialog-content']//table"));

    public TextBox onsetDateTextBox = new TextBox(By.xpath("//input[@id='Incident_OnsetDate']"));
    public TextBox dateOfEligibilityTextBox = new TextBox(By.id("Incident_DateOfEligibility"));
    public TextBox incidentTypeTextBox = new TextBox(By.xpath("//input[@name=\"incident_type\"]"));
    public Label petLabel = new Label(By.xpath("//div[@class=\"container-fluid modal-header\"]//strong[contains(.,'Pet')]/../..//div[@class='controls']"));
    public Select incidentClassSelect = new Select(By.xpath("//select[@id='incident_class_id']"));
    public TextBox openDiagnosisTextBox = new TextBox(By.xpath("//input[@id=\"Incident_OpenDiagnosis\"]"));
    public TextBox denialCodeTextBox = new TextBox(By.id("DenialCodeText_autocomplete"));

    public TextBox detailsTextBox = new TextBox(By.xpath("//textarea[@name=\"Incident.Details\"]"));

    public Map<String, ControlBase> allControls =  new HashMap<>();

    public IncidentModal() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        allControls.put("Onset Date",onsetDateTextBox);
        allControls.put("Date Of Eligibility",dateOfEligibilityTextBox);
        allControls.put("Pet",petLabel);
        allControls.put("Incident Type",incidentTypeTextBox);
        allControls.put("Incident Class",incidentClassSelect);
        allControls.put("Open Diagnosis",openDiagnosisTextBox);
        allControls.put("Denial Code",denialCodeTextBox);
        allControls.put("Details",detailsTextBox);
    }

    public void addIncident(int rowNumber) throws Exception {
        this.incidentTable.clickOnCheckBoxCell(1, rowNumber);
        this.saveButton.click();
    }

    public void createIncident(IncidentEntity incidentEntity) throws Exception {
        detailsTextBox.click();
        detailsTextBox.setTextAndTab("");
        onsetDateTextBox.click();
        onsetDateTextBox.setTextAndTab(incidentEntity.getOnSetDate());
        incidentTypeTextBox.selectTextOption(incidentEntity.getIncidentTypeInitial(), incidentEntity.getIncidentType());

        if (!incidentEntity.getOpenDiagnosis().equals(""))
            openDiagnosisTextBox.setText(incidentEntity.getOpenDiagnosis());
        if (!incidentEntity.getDenialCode().equals(""))
            denialCodeTextBox.selectTextOption(incidentEntity.getDenialCode(), incidentEntity.getDenialCode());

        if (!incidentEntity.getDetails().equals(""))
            detailsTextBox.setText(incidentEntity.getDetails());
        this.saveButton.click();
    }

}
