package pages.orca.common;

import control.Link;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;

public class SubMenuSection {
    public Map<String, Link> optionSubMenu = new HashMap<>();

    public SubMenuSection() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        //admin
        optionSubMenu.put("Dashboard", new Link(By.xpath("//a[text()='Dashboard']")));
        optionSubMenu.put("Admin Dashboard",new Link(By.id("adminDashboard")));
        optionSubMenu.put("User Management", new Link(By.id("userManagement")));
        optionSubMenu.put("Pet Management", new Link(By.id("petManagement")));
        optionSubMenu.put("Filings", new Link(By.id("filings")));
        optionSubMenu.put("Rating Models", new Link(By.id("ratingModels")));
        optionSubMenu.put("RM Affinitys", new Link(By.xpath("//a[text()='RM Affinitys']")));
        optionSubMenu.put("Benefit Schedules", new Link(By.id("benefitSchedules")));
        optionSubMenu.put("Feature Flags", new Link(By.id("featureFlags")));
        optionSubMenu.put("Error Log", new Link(By.id("errorLog")));
        optionSubMenu.put("Rating Formula",new Link(By.id("ratingFormulas")));
        optionSubMenu.put("State Management",new Link(By.id("stateManagement")));
        optionSubMenu.put("Affinity groups",new Link(By.id("affinityGroups")));
        optionSubMenu.put("Claim processing",new Link(By.id("claimsProcessing")));

        optionSubMenu.put("Master Rate Sheets", new Link(By.id("masterRateSheets")));

        optionSubMenu.put("Product Packages", new Link(By.id("productPackages")));
        optionSubMenu.put("Product Management",new Link(By.id("productManagement")));



        optionSubMenu.put("Document Version",new Link(By.id("documentVersion")));
        optionSubMenu.put("Document Library",new Link(By.id("documentLibrary")));


        //Affiliates
        optionSubMenu.put("Add Affiliate", new Link(By.xpath("//a[text()='Add Affiliate']")));
        optionSubMenu.put("Lead Fee Tiers", new Link(By.xpath("//a[text()='Lead Fee Tiers']")));

        //Claim
        optionSubMenu.put("Claims Team Inbox", new Link(By.xpath("//a[text()='Claims Team Inbox']")));
        optionSubMenu.put("Issue Claims", new Link(By.xpath("//a[text()='Issue Claims']")));
        optionSubMenu.put("Adjuster Profiles", new Link(By.xpath("//a[text()='Adjuster Profiles']")));
        optionSubMenu.put("Search for a Claim", new Link(By.xpath("//a[text()='Search for a Claim']")));

        //Mclead
        optionSubMenu.put("Add Registration", new Link(By.xpath("//a[text()='Add Registration']")));

        //User account details
        optionSubMenu.put("User Management account details",new Link(By.xpath("//a[text()='User Management']")));
    }
}
