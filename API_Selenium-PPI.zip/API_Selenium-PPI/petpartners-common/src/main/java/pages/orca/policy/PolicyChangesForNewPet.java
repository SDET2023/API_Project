package pages.orca.policy;

import control.*;
import org.openqa.selenium.By;

import java.util.HashMap;
import java.util.Map;

public class PolicyChangesForNewPet {

    public TextBox petNameTextBox = new TextBox(By.id("Pet_Pet_PetName"));

    public TextBox petDateOfBrithTextBox = new TextBox(By.id("Pet_Pet_Dob"));

    public Select petBrithMonthSelect = new Select(By.cssSelector(".ui-datepicker-month"));

    public Select petBrithYearSelect = new Select(By.xpath("//select[@class='ui-datepicker-year']"));

    public Button petBrithDate = new Button(By.xpath("//a[normalize-space()='14']"));

    public Select genderOfthePet = new Select(By.id("gender-select"));

    public Select speciesOfThePet = new Select(By.id("species-select"));

    public Select breedOfThePet = new Select(By.id("breed-select"));

    public Checkbox hereDitaryPlusCheckBox = new Checkbox(By.id("CoverageProducts_1__IsSelected"));

    public Checkbox supportPlusCheckBox = new Checkbox(By.id("CoverageProducts_2__IsSelected"));

    public Checkbox alternativePlusCheckBox = new Checkbox(By.id("CoverageProducts_3__IsSelected"));

    public Checkbox examPlusCheckBox = new Checkbox(By.id("CoverageProducts_5__IsSelected"));

    public Checkbox defenderPlusCheckBox = new Checkbox(By.id("CoverageProducts_6__IsSelected"));

    public Checkbox defenderCheckBox = new Checkbox(By.id("CoverageProducts_7__IsSelected"));
    public Button returnPolicyButton = new Button(By.xpath("//div[@id='quote-actions']//a[@class='btn btn-inverse'][normalize-space()='Return to Policy']"));

    public Button saveButtonButton = new Button(By.xpath("//button[normalize-space()='Save']"));
    public Map<String, TextBox> textBoxMap = new HashMap<>();

    public PolicyChangesForNewPet() {

        textBoxMap.put("Pet name", petNameTextBox);
        textBoxMap.put("Date Of Brith", petDateOfBrithTextBox);
    }
}
