package pages.orca.admin.documentManagement.addFileSections;

import control.TextBox;
import org.openqa.selenium.By;

public class UploadFileSection {
    public TextBox dragFileHereOrBrowseTextArea = new TextBox(By.id("fileDropRef"));


}
