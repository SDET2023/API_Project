package pages.orca.admin.documentManagement.addFileSections;

import control.Button;
import org.openqa.selenium.By;

public class PreviewDocumentSection {
    public Button submitButton = new Button(By.xpath("//button[contains(.,'Submit')]"));

}
