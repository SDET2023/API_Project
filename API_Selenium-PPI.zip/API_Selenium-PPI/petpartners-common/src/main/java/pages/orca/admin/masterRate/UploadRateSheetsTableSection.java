package pages.orca.admin.masterRate;

import control.Button;
import control.Table;
import org.openqa.selenium.By;

public class UploadRateSheetsTableSection {

    public Button editButton = new Button(By.xpath("//div[@id='tabs-components']//button[@class='btn btn-info ms-auto']/*"));
    public Table detailTable = new Table(By.xpath("//div[@id='tabs-components']//table"));
    public Button cancelButton = new Button(By.id("cancelButton"));
    public Button saveButton = new Button(By.id("saveButton"));
    public UploadRateSheetsTableSection(){}

    public boolean checkIfTabSectionIsDisplayedInFactorSelectedTable(String tabName){
        Button tabNameButton = new Button(By.xpath("//div[contains(@class,'card-footer')]/ul/li/a[text()='"+tabName+"']"));
        return tabNameButton.controlIsDisplayed(3);
    }

    public void clickTabSectionFactorSelectedTable(String tabName) throws Exception {
        Button tabNameButton = new Button(By.xpath("//div[contains(@class,'card-footer')]/ul/li/a[text()='"+tabName+"']"));
        tabNameButton.click();
    }





}
