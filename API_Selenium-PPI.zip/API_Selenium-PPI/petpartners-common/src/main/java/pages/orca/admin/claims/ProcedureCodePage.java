package pages.orca.admin.claims;

import control.Button;
import control.Link;
import control.Table;
import control.TextBox;
import org.openqa.selenium.By;

public class ProcedureCodePage {
    public Button createNewProcedureCodeButton = new Button(By.xpath("//button[contains(text(),'Create New Procedure Code')]"));
    public Table procedureCodeTable = new Table(By.xpath("//table[@class='table table-bordered']"));
    public Link statusHistoryLink = new Link(By.xpath("//a[contains(text(),'Version History')]"));
    public Button denialCodeCreationButton = new Button(By.xpath("//button[contains(text(),'Denial Code Creation')]"));
    public TextBox searchBarTextBox = new TextBox(By.xpath("//input[@id='search-term']"));
    public Table denialCodeTable = new Table(By.xpath("//table[@class='table table-bordered']"));
}

