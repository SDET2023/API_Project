package pages.orca.admin.productManagement;

import control.*;

import org.openqa.selenium.By;

public class FilingPage {
    public Button addNewButton = new Button(By.xpath("//button[text()='Add New']"));
    public Label fieldrequiredLabel = new Label(By.xpath("//div [@class='text-danger']"));
    public Button searchButton = new Button(By.xpath("//button[text()='Search']"));
    public Table rowsInFilingTable= new Table(By.xpath("//table[@class='table table-bordered']/tbody/tr"));
    public Table searchTable = new Table(By.xpath("//table[@class='table table-bordered']"));
    public Label filingsLabel = new Label(By.xpath("//h5[text()='Filings']"));
    public TextBox stateFilingIdTextbox = new TextBox(By.xpath("//input[@formcontrolname='stateFilingId']"));
    public Label statusLabel = new Label(By.xpath("//*[@class='bi bi-square']/parent::td//following-sibling::td"));
    public Link stateFilingIDLink = new Link(By.xpath("//table[@class='table table-bordered']//a"));
    public Checkbox activeCheckbox= new Checkbox(By.xpath("//*[@class='bi bi-check-square']"));


    public TextBox applicationAcknowledgement30Day = new TextBox(By.xpath("//label[text()='Application Acknowledgement (30 Day)']"));

    public Button actionButton = new Button(By.xpath("//button[@title='Edit']"));

    public TextBox procedureTextBox = new TextBox(By.className("input-group-text"));

    public  FilingPage() {



    }


}
