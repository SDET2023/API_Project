package pages.orca.claim;

import control.Button;
import control.Select;
import control.Table;
import org.openqa.selenium.By;
public class ClaimAdjusterProfile {

    public Table adjusterTable = new Table(By.xpath("//table[@class='table table-bordered table-striped']"));
    public Select totalSubmittedLevel = new Select(By.id("sysuser-id"));
    public Button saveButton  = new Button(By.xpath("//button[normalize-space()='Save']"));

    public Button cancelButton = new Button(By.xpath("//a[@title='Cancel']"));
}
