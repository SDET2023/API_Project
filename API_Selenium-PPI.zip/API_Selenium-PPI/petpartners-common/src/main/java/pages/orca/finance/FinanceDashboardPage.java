package pages.orca.finance;

import control.Link;
import control.Select;
import control.Table;
import org.openqa.selenium.By;

import java.util.HashMap;
import java.util.Map;

public class FinanceDashboardPage {
    public Link generateInvoicesLink =  new Link(By.xpath("//a[contains(.,'Generate Invoices')]"));
    public Link updateBillingInfoLink =  new Link(By.xpath("//a[contains(.,'Update Billing Info')]"));
    public Link runTransactionsLink =  new Link(By.xpath("//a[contains(.,'Run Transactions')]"));
    public Link transactionHistoryLink =  new Link(By.xpath("//a[contains(.,'Transaction History')]"));
    public Link policyPendingActionLink =  new Link(By.xpath("//a[contains(.,'Policies Pending Action')]"));
    public Link brokerCommissionsLink =  new Link(By.xpath("//a[contains(.,'Broker Commissions')]"));
    public Link affiliateEarningsLink =  new Link(By.xpath("//a[contains(.,'Affiliate Earnings')]"));
    public Link renewPoliciesLink =  new Link(By.xpath("//a[contains(.,'Renew Policies')]"));
    public Link downloadAchResponseFilesLink =  new Link(By.xpath("//a[contains(.,'Download ACH Response Files')]"));
    public Link pendingAchReturnInformationLink =  new Link(By.xpath("//a[contains(.,'Pending ACH Return Information')]"));
    public Link premiumRefundChecksLink =  new Link(By.xpath("//a[contains(.,'Premium Refund Checks')]"));

    public Select filterByStatusSelect = new Select(By.xpath("//select[@id='ddlStatus']"));

    public Table resultFinanceTable = new Table(By.xpath("//table[@id='pending-policies']"));


    public Map<String,Link> linkMap = new HashMap<>();

    public FinanceDashboardPage(){
        linkMap.put("Generate Invoices",generateInvoicesLink);
        linkMap.put("Update Billing Info",updateBillingInfoLink);
        linkMap.put("Run Transactions",runTransactionsLink);
        linkMap.put("Transaction History",transactionHistoryLink);
        linkMap.put("Policies Pending Action",policyPendingActionLink);
        linkMap.put("Broker Commissions",brokerCommissionsLink);
        linkMap.put("Affiliate Earnings",affiliateEarningsLink);
        linkMap.put("Renew Policies",renewPoliciesLink);
        linkMap.put("Download ACH Response Files",downloadAchResponseFilesLink);
        linkMap.put("Pending ACH Return Information",pendingAchReturnInformationLink);
        linkMap.put("Premium Refund Checks",premiumRefundChecksLink);
    }

}
