package pages.orca.common;

import control.Button;
import control.Select;
import control.TextBox;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;

public class MenuSection {
    public Map<String, Button> optionMenu = new HashMap<>();
    public TextBox searchPoliciesTextBox = new TextBox(By.xpath("//input[@placeholder='Search ']"));
    public Select selectSearchPolicyOrClaim = new Select(By.xpath("//select[@id='optSearch']"));
    public Button goButton = new Button(By.xpath("//button[@id='btnSearch' or @id='btnSearchGroup']"));

    public MenuSection(){
        Logger.log(Level.INFO,this.getClass().getName()+"> Page: "+this.getClass().getSimpleName());
        optionMenu.put("Admin",new Button(By.xpath("//a[text()='Admin']")));
        optionMenu.put("Affiliate",new Button(By.xpath("//a[text()='Affiliate']")));
        optionMenu.put("Breeder",new Button(By.xpath("//a[text()='Breeder']")));
        optionMenu.put("Claims",new Button(By.xpath("//a[text()='Claims']")));
        optionMenu.put("Customer",new Button(By.xpath("//a[text()='Customer']")));
        optionMenu.put("Finance",new Button(By.xpath("//a[text()='Finance']")));
        optionMenu.put("Partner",new Button(By.xpath("//a[text()='Partner']")));
        optionMenu.put("Mclead",new Button(By.xpath("//a[text()='Mclead']")));
        optionMenu.put("Policy",new Button(By.xpath("//a[text()='Policy']")));
        optionMenu.put("Receiving",new Button(By.xpath("//a[text()='Receiving']")));
        optionMenu.put("Vet",new Button(By.xpath("//a[text()='Vet']")));
        optionMenu.put("MarketChannels",new Button(By.xpath("//a[text()='Market Channels' or text()='Market channel']")));
    }

}
