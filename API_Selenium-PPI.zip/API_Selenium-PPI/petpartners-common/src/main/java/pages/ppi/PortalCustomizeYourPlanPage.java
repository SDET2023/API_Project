package pages.ppi;

import control.*;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;

import entities.ppi.ChangeCoverageEntity;

public class PortalCustomizeYourPlanPage {

    public Button addToCartButton = new Button(By.xpath("//button[@type=\"submit\"]"));

    public Map<String, Select> selectMap = new HashMap<>();
    public Map<String, RadioButton> radioButtonMap = new HashMap<>();

    public RadioButton hereditaryPlusOption = new RadioButton(By.xpath("//span[contains(text(),'HereditaryPlus')]/preceding-sibling::input[1]"));
    public RadioButton examPlusOption = new RadioButton(By.xpath("//span[contains(text(),'ExamPlus')]/preceding-sibling::input[1]"));
    public RadioButton supportPlusOption = new RadioButton(By.xpath("//span[contains(text(),'SupportPlus')]/preceding-sibling::input[1]"));
    public RadioButton breedingCoverageOption = new RadioButton(By.xpath("//span[contains(text(),'BreedingCoverage')]/preceding-sibling::input[1]"));
    public RadioButton defenderPlusOption = new RadioButton(By.xpath("//span[contains(text(),'DefenderPlus')]/preceding-sibling::input[1]"));
    public RadioButton defenderOption = new RadioButton(By.xpath("//span[contains(text(),'Defender ')]/preceding-sibling::input[1]"));

    public Select deductibleSelect = new Select(By.xpath("//select[@formcontrolname=\"deductibleId\"]"));
    public Select coinsuranceSelect = new Select(By.xpath("//select[@formcontrolname=\"coinsuranceId\"]"));
    public Select annualLimitSelect = new Select(By.xpath("//select[@formcontrolname=\"coverageLimitId\"]"));

    public PortalCustomizeYourPlanPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        radioButtonMap.put("ExamPlus", examPlusOption);
        radioButtonMap.put("HereditaryPlus", hereditaryPlusOption);
        radioButtonMap.put("BreedingCoverage", breedingCoverageOption);
        radioButtonMap.put("SupportPlus", supportPlusOption);
        radioButtonMap.put("DefenderPlus", defenderPlusOption);
        radioButtonMap.put("Defender", defenderOption);

        selectMap.put("DEDUCTIBLE", deductibleSelect);
        selectMap.put("COINSURANCE", coinsuranceSelect);
        selectMap.put("ANNUAL LIMIT", annualLimitSelect);
    }

    public void fillCoverageOption(ChangeCoverageEntity coverageEntity) throws Exception {
        this.deductibleSelect.selectValue(" " + coverageEntity.deductible + " ");
        this.coinsuranceSelect.selectValue(" " + coverageEntity.coinsurance + " ");
        this.annualLimitSelect.selectValue(" " + coverageEntity.annualLimit + " ");
    }
}
