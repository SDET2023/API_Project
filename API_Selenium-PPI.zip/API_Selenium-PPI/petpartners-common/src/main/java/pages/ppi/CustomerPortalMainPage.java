package pages.ppi;

import control.Link;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class CustomerPortalMainPage {

    public Link welcomeCustomerLink = new Link(By.xpath("//h4[text()='Welcome to your Customer Portal!']"));

    public CustomerPortalMainPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }

}
