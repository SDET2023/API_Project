package pages.ppi.activateCertificate;

import control.Button;
import control.Link;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class DayPetInsuranceCoveragePage {

    public Link activateCertificate = new Link(By.xpath("//a[@title=\"Activate Your Certificate\"]"));
    public Button lookUpPetExpandButton = new Button(By.xpath("//button[@id='look-up-pet-btn']"));

    public DayPetInsuranceCoveragePage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }
}
