package pages.ppi;

import control.Button;
import control.Label;
import control.TextBox;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class CreateAccountPage {
    public TextBox emailTextBox = new TextBox(By.xpath("//input[@name=\"emailInputControl\"]"));
    public TextBox passwordTextBox = new TextBox(By.xpath("//input[@placeholder=\"Password\"]"));
    public TextBox confirmPasswordTextBox = new TextBox(By.xpath("//input[@id=\"confirmRegisterPassword\"]"));
    public Button createAccountButton = new Button(By.xpath("//button[contains(.,'Create Account')]"));
    public Label createAccountLabel = new Label(By.xpath("//h2[text()='Create Account']"));

    public CreateAccountPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }

    public void createAccount(String email, String pwd, String confirmPwd) throws Exception {
        this.emailTextBox.setText(email);
        this.passwordTextBox.setText(pwd);
        this.confirmPasswordTextBox.setText(confirmPwd);
        this.createAccountButton.click();
    }

}
