package pages.ppi;

import control.*;
import entities.ppi.GetQuoteEntity;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;

public class GetQuotePage {

    public TextBox petNameTextBox = new TextBox(By.id("name"));
    public TextBox zipCodeTextBox = new TextBox(By.id("postalCode"));
    public RadioButton dogRadioButton = new RadioButton(By.xpath("//form[@id='step1']//span[contains(@title,'Select dog')]"));
    public RadioButton catRadioButton = new RadioButton(By.xpath("//form[@id='step1']//span[contains(@title,'Select cat')]"));
    public CustomSelect petBreedTextBox = new CustomSelect(By.xpath("//form[@id='step1']//input[@id='breedSearch']"), "p");
    public Select petAgeSelect = new Select(By.xpath("//form[@id='step1']//select[@id='age']"));
    public RadioButton yesPetDiagnosedRadioButton = new RadioButton(By.xpath("//span[@for=\"yes\"]"));
    public RadioButton noPetDiadnosedRadioButton = new RadioButton(By.xpath("//form[@id='step1']//span[@for=\"no\"]"));
    public TextBox emailAdressTextBox = new TextBox(By.xpath("//form[@id=\"step1\"]//input[@id=\"email\"]"));
    public Button chooseCoverageButton = new Button(By.cssSelector("#submit"));
    public Button resetBreedButton = new Button(By.xpath("//button[@id=\"resetBreedButton\"]"));
    public Label lookUpPetFormText = new Label(By.xpath("//*[@id=\"look-up-pet-container\"] "));
    // lookup activation

    public RadioButton petpartnersCertificateRadioButton = new RadioButton(By.xpath("//span[@for=\"ppi-activate\"]"));
    public RadioButton akcReuniteEnrollmentRadioButton = new RadioButton(By.xpath("//span[@for=\"reunite-activate\"]"));
    public TextBox activationCodeTextBox = new TextBox(By.xpath("//input[@id=\"reg_no\"]"));
    public TextBox zipCodeCertificateTextBox = new TextBox(By.xpath("//input[@id=\"zipcode\"]"));
    public Button lookUpPetButton = new Button(By.xpath("//button[@id=\"find-registration\"]"));
    public Button cancelButton = new Button(By.xpath("//a[@id=\"look-up-cancel\"]"));

    // edit ZIP code
    public Button editZipCodeButton = new Button(By.xpath("//button[@id=\"change-postal-code\"]"));
    public Button yesZipCodeModalButton = new Button(By.xpath("//button[contains(text(),'Yes')]"));


    public GetQuotePage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }

    public void fillGetQuoteForm(GetQuoteEntity getQuoteEntity) throws Exception {
        this.petNameTextBox.setText(getQuoteEntity.getPetName());
        this.zipCodeTextBox.setTextAndTab(getQuoteEntity.getZipCode());
        Thread.sleep(2000);
        if (getQuoteEntity.getDogOrCatOption().toLowerCase().equals("dog"))
            this.dogRadioButton.click();
        else
            this.catRadioButton.click();

        Thread.sleep(8000);
        petBreedTextBox.controlIsDisplayed();
        petBreedTextBox.controlIsClickable();
        petBreedTextBox.setAndClickValue(getQuoteEntity.getPetBreed());
        Thread.sleep(1000);
        petAgeSelect.selectValue(getQuoteEntity.getPetAge());

        if (getQuoteEntity.getNoOryesPetDiagnosed().toLowerCase().equals("yes"))
            this.yesPetDiagnosedRadioButton.click();
        else
            this.noPetDiadnosedRadioButton.click();

        this.emailAdressTextBox.setText(getQuoteEntity.getEmailAdress());
        this.chooseCoverageButton.controlIsClickable();
        this.chooseCoverageButton.controlIsDisplayed(10);
        this.chooseCoverageButton.click();
        this.chooseCoverageButton.waitWhileControlDisappears(15);
    }


    public void updateGetQuote(GetQuoteEntity getQuoteEntity) throws Exception {
        Logger.log(Level.INFO, this.getClass().getName() + "> Update QUOTE: " + this.getClass().getSimpleName());
        Thread.sleep(1000);
        if (!getQuoteEntity.getPetName().isEmpty()) {
            this.petNameTextBox.clear();
            this.petNameTextBox.setText(getQuoteEntity.getPetName());
        }

        if (!getQuoteEntity.getZipCode().isEmpty()) {
            this.editZipCodeButton.click();
            Thread.sleep(2000);
            this.yesZipCodeModalButton.click();
            Thread.sleep(2000);
            this.zipCodeTextBox.clear();
            this.zipCodeTextBox.setText(getQuoteEntity.getZipCode());
        }
        Thread.sleep(2000);
        if (getQuoteEntity.getDogOrCatOption().toLowerCase().equals("dog"))
            this.dogRadioButton.click();
        else if (getQuoteEntity.getDogOrCatOption().toLowerCase().equals("cat"))
            this.catRadioButton.click();

        if (!getQuoteEntity.getPetBreed().isEmpty()) {
            // remove the breed selected
            Thread.sleep(2000);
            petBreedTextBox.setAndClickValue(getQuoteEntity.getPetBreed());
        }

        if (!getQuoteEntity.getPetAge().isEmpty()) {
            Thread.sleep(1000);
            petAgeSelect.selectValue(getQuoteEntity.getPetAge());
        }

        if (getQuoteEntity.getNoOryesPetDiagnosed().toLowerCase().equals("yes")) {
            this.yesPetDiagnosedRadioButton.click();
        } else if (getQuoteEntity.getNoOryesPetDiagnosed().toLowerCase().equals("no")) {
            this.noPetDiadnosedRadioButton.click();
        }
        if (!getQuoteEntity.getEmailAdress().isEmpty())
            this.emailAdressTextBox.clear();
        this.emailAdressTextBox.setText(getQuoteEntity.getEmailAdress());

        this.chooseCoverageButton.click();
        Thread.sleep(3000);
    }

    public Map<String, ControlBase> getAllControls() {
        Map<String, ControlBase> controls = new HashMap<>();
        controls.put("PET NAME", petNameTextBox);
        controls.put("ZIP CODE", zipCodeTextBox);
        controls.put("PET TYPE DOG", dogRadioButton);
        controls.put("PET TYPE CAT", catRadioButton);
        controls.put("PET BREED", petBreedTextBox);
        controls.put("PET AGE", petAgeSelect);
        controls.put("YES", yesPetDiagnosedRadioButton);
        controls.put("NO", noPetDiadnosedRadioButton);
        controls.put("EMAIL ADDRESS", emailAdressTextBox);
        controls.put("CHOOSE COVERAGE", chooseCoverageButton);
        return controls;
    }

    public void fillGetQuoteFormForAnotherPet(Map<String, String> getQuoteValue) throws Exception {
        this.petNameTextBox.setText(getQuoteValue.get("petName"));
        Thread.sleep(2000);
        if (getQuoteValue.get("dogOrCat").toLowerCase().equals("dog"))
            this.dogRadioButton.click();
        else
            this.catRadioButton.click();
        Thread.sleep(8000);
        petBreedTextBox.controlIsDisplayed();
        petBreedTextBox.controlIsClickable();
        petBreedTextBox.setAndClickValue(getQuoteValue.get("petBreed"));
        Thread.sleep(1000);
        petAgeSelect.selectValue(getQuoteValue.get("petAge"));
        if (getQuoteValue.get("yesOrNoDiagnose").toLowerCase().equals("yes"))
            this.yesPetDiagnosedRadioButton.click();
        else
            this.noPetDiadnosedRadioButton.click();
        this.chooseCoverageButton.controlIsClickable();
        this.chooseCoverageButton.controlIsDisplayed(10);
        this.chooseCoverageButton.click();
    }
}
