package pages.ppi.landsOnPolicy;

import control.Link;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class PolicyDetailPage {
    public Link submitClaimLink = new Link(By.xpath(""));

    public PolicyDetailPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }
}
