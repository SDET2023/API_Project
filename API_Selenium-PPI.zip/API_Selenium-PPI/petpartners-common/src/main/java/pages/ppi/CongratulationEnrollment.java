package pages.ppi;

import control.Button;
import control.Label;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class CongratulationEnrollment {
    public Label policyNumber = new Label(By.xpath("//header[@class=\"form-quote__svg-container\"]/h2"));
    public Button portalLoginButton = new Button(By.xpath("//span[contains(.,' Portal Login')]"));
    public Label messageCongratulation = new Label(By.xpath("//h1[@class=\"h2 mt--1 header--primary\"]"));
    public Label petOverviewPrice = new Label(By.xpath("//div[@class='pet-overview__price c--primary']"));


    public CongratulationEnrollment() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }


}