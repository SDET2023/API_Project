package pages.orcaGroup;

import control.*;
import org.openqa.selenium.By;
import pages.orca.loss.VetSearchModal;
import utils.Level;
import utils.Logger;
import java.util.HashMap;
import java.util.Map;

public class GroupLossDetailsPage {

    public TextBox claimNumberTextBox = new TextBox(By.xpath("//div[@class='controls']/input[@id='Loss_claim_id']/.."));
    public TextBox dateOfServiceTextBox = new TextBox(By.xpath("//input[@id='LossDto_DateOfService']"));
    public Select petSelect = new Select(By.xpath("//select[@id='pet' or @id='group-pet']"));
    public Select vetSelect = new Select(By.id("vet"));
    public Button findVetButton = new Button(By.xpath("//a[contains(.,'Find a Vet')]"));
    public Button incidentsPlusButton = new Button(By.xpath("//legend/span/a/i"));

    public Map<String, Button> controlOverviewButton = new HashMap<>();
    //Approved Section

    public Table approvedTable = new Table(By.xpath("//table[@class='table table-bordered loss-incident-lines']"));
    public Map<String, Cell> approvedTableCell = new HashMap<>();
    public Button addNewButton = new Button(By.xpath("//a[@data-append-id='approved-loss-line-items']"));
    public Map<String, Button> controlApprovedButton = new HashMap<>();
    public VetSearchModal vetSearchModal = new VetSearchModal();
    public Link viewLossDetailsLink = new Link(By.xpath("//a[@title='Add Line Items']"));
    public Label denialReasonHeader = new Label(By.xpath("//div[@id='loss']//h3[contains(text(),'Denial Reason')]"));

    public Button viewProductsForPetButton = new Button(By.xpath("//a[@title=\"View Products for Pet\"]"));
    public Label duplicateWarningLabel = new Label(By.xpath("//h3[@class='error']"));

    public GroupLossDetailsPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        controlOverviewButton.put("Save", new Button(By.xpath("(//div[@class='pull-right']/*[@name='ButtonPressed'])[1]")));

        controlApprovedButton.put("Return to Claim", new Button(By.xpath("(//div[@class='pull-right']/a[@title='Return to Claim'])[last()]")));
        controlApprovedButton.put("Save", new Button(By.xpath("(//div[@class='pull-right']/*[@name='ButtonPressed'])[last()]")));

        approvedTableCell.put("Procedure", new Cell(2, "input", "Procedure"));
        approvedTableCell.put("Description", new Cell(4, "input", "Description"));
        approvedTableCell.put("Incident", new Cell(5, "select", "Incident"));
        approvedTableCell.put("Submitted", new Cell(6, "input", "Submitted"));
        approvedTableCell.put("Allowed", new Cell(7, "input", "Allowed"));
    }

}
