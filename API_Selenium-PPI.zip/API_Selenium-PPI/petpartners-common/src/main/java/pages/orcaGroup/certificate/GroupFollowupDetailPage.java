package pages.orcaGroup.certificate;

import control.Button;
import control.Select;
import control.TextBox;
import entities.orca.followUp.FollowUpDetailEntity;
import org.openqa.selenium.By;

public class GroupFollowupDetailPage {

    public Select assignedToSelect = new Select(By.xpath("//select[@id=\"GroupFollowup_AssignedTo\"]"));
    public Select followUpTypeSelect = new Select(By.xpath("//select[@id=\"GroupFollowup_FollowupTypeId\"]"));
    public Select complaintTypeSelect = new Select(By.xpath("//select[@id=\"GroupFollowup_ComplaintTypeId\"]"));

    public TextBox receivedOnTextBox = new TextBox(By.id("GroupFollowup_ReceivedOn"));
    public TextBox followUpByTextBox = new TextBox(By.id("GroupFollowup_FollowupBy"));
    public TextBox closedOnTextBox = new TextBox(By.id("GroupFollowup_ClosedOn"));

    public TextBox summaryTextBox = new TextBox(By.id("GroupFollowup_Summary"));
    public TextBox resolutionTextBox = new TextBox(By.id("GroupFollowup_Resolution"));

    public Button cancelButton = new Button(By.xpath("//a[@title=\"Cancel\"]"));
    public Button saveButton = new Button(By.xpath("//button[contains(.,'Save')]"));


    public void fillDetailPage(FollowUpDetailEntity entity) throws Exception {

        if (entity.getAssignedTo().contains("random")){
            assignedToSelect.firstValue();
        }else{
            assignedToSelect.selectValueContainsOption(entity.getAssignedTo());
        }
        followUpTypeSelect.selectValueContainsOption(entity.getFollowUpType());
        complaintTypeSelect.selectValueContainsOption(entity.getComplaintType());

        receivedOnTextBox.setTextAndTab(entity.getReceivedOn());
        followUpByTextBox.setTextAndTab(entity.getFollowUpBy());
        closedOnTextBox.setTextAndTab(entity.getClosedOn());

        summaryTextBox.setText(entity.getSummary());
        resolutionTextBox.setText(entity.getResolution());

        saveButton.click();
    }
}
