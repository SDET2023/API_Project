package pages.orcaGroup.certificate;

import control.Button;
import control.Table;
import control.TextBox;
import org.openqa.selenium.By;

import java.util.HashMap;
import java.util.Map;

public class GroupCertificateDashboardPage {

    public TextBox groupNameTextBox= new TextBox(By.id("GroupNames"));
    public TextBox certificateNumberTextBox= new TextBox(By.id("SearchCriteria_CertificateNo"));
    public TextBox lastNameTextBox= new TextBox(By.id("SearchCriteria_LastName"));
    public TextBox emailAddressTextBox= new TextBox(By.id("SearchCriteria_EmailAddress"));
    public TextBox phoneNumberTextBox= new TextBox(By.id("SearchCriteria_PhoneNumber"));
    public TextBox postalCodeTextBox= new TextBox(By.id("SearchCriteria_PostalCode"));
    public TextBox petNameTextBox= new TextBox(By.id("SearchCriteria_PetName"));
    public Button runSearchButton = new Button(By.id("btn-run-search"));
    public Table searchResultTable= new Table(By.xpath("//table[@id=\"search-results\"]"));

    public Map<String,TextBox> textBoxMap= new HashMap<>();

    public GroupCertificateDashboardPage(){
        textBoxMap.put("Group Name",groupNameTextBox);
        textBoxMap.put("Certificate Number",certificateNumberTextBox);
        textBoxMap.put("Last Name",lastNameTextBox);
        textBoxMap.put("Email Address",emailAddressTextBox);
        textBoxMap.put("Phone Number",phoneNumberTextBox);
        textBoxMap.put("Postal Code",postalCodeTextBox);
        textBoxMap.put("Pet Name",petNameTextBox);
    }



}
