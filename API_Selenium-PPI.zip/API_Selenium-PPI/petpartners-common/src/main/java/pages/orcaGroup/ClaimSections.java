package pages.orcaGroup;

import control.*;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class ClaimSections {

    public Button claimsTab = new Button(By.xpath("//a[text()='Claims']"));

    public Button searchForClaimsButton = new Button(By.xpath("//a[text()='Search for a Claim']"));

    public TextBox claimsNoTextBox = new TextBox(By.id("SearchCriteria_ClaimNo"));

    public Table searchResultTable = new Table(By.xpath("//*[@id=\"search-results-wrapper\"]/table"));

    public Button runSearchButton = new Button(By.id("btn-run-search"));

    public Button  myDashboardButton = new Button(By.xpath("//a[text()='My Dashboard']"));

    public Button  claimsTeamInbox = new Button(By.xpath("//a[text()='Claims Team Inbox']"));

    public Button issueClaimsButton = new Button(By.xpath("//a[text()='Issue Claims']"));

    public Label details = new Label(By.xpath("//div[@id='claim-details']//div[@class='well']"));

    public Table claimsResultTable = new Table(By.cssSelector("a[class='selector']"));

    public Button viewButton = new Button(By.xpath("//div[@id='losses-table']//table//td//*[@title='Add Line Items']"));
    public Link claimNoLink = new Link(By.xpath("//a[@class ='selector']"));

    public ClaimSections(){
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }
}
