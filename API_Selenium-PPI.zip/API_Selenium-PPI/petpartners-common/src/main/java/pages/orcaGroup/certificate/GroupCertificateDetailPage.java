package pages.orcaGroup.certificate;

import control.*;
import org.openqa.selenium.By;

import java.util.HashMap;
import java.util.Map;

public class GroupCertificateDetailPage {


    public Label certificateNoLabel = new Label(By.xpath("//strong[contains(.,'Certificate No')]/../..//div[@class='controls']"));
    public Label groupNameLabel = new Label(By.xpath("//strong[contains(.,'Group Name')]/../..//div[@class='controls']"));


    public Link deductibleTrackerLink = new Link(By.xpath("//a[contains(.,'Deductible Tracker')]"));


    public Table petsTable = new Table(By.xpath("//div[@id=\"pets-table\"]/div/table"));
    public Table deductibleTable = new Table(By.xpath("//div[@id=\"deductible-tracker-accordion\"]//table"));


    // coverage tab
    public Link activeLink = new Link(By.xpath("//a[text()='Active']"));
    public Link upcomingLink = new Link(By.xpath("//a[text()='Upcoming']"));
    public Table coveragePeriodTable = new Table(By.xpath("//div[@class=\"row-fluid\"]/table[@class=\"table table-striped table-bordered\"]"));
    public Table productDetailTable = new Table(By.xpath("//h3[text()='Product Details']/../table"));

    public Table customerDetailsTable = new Table(By.xpath("//table[@id=\"customers-table\"]"));
    public Link iconLink = new Link(By.xpath("//i[@class=\"icon-white icon-info-sign\"]"));
    public Checkbox noteCheckbox = new Checkbox(By.xpath("//input[@id=\"Employee_IsNoteImportant\"]"));
    public TextBox noteTextbox = new TextBox(By.xpath("//textarea[@id=\"Employee_PriorityNote\"]"));

    public Button saveButton = new Button(By.xpath("//button[@class=\"disable-after-click btn btn-success\"]"));


public boolean isDisplayedPetNameLink(String petName) throws Exception {
    Link petNameLink = new Link(By.xpath("//div[contains(@id,'coverages')]//a[text()='" + petName+ "']"));
    return petNameLink.controlIsDisplayed(5);
}


        public String petStatus(String status, Integer number) throws Exception {
        Label petStatus1 = new Label(By.xpath("(//div[@class='row-fluid']//td[contains(text(),' " + status + " ')])[' " + number + " ']"));
        String statusOne = petStatus1.getText();
        return statusOne;

    }

    public String cancellationStatus(String status, Integer number) throws Exception {
        Label cancellationStatusPet = new Label(By.xpath("(//a[text()='Active']/ancestor::div[@id='coverages-accordion']//div/strong[contains(text(),'" + status + "')])[" + number + "]"));
        String cancelledPet = cancellationStatusPet.getText();
        return cancelledPet;
    }


    // follow-up(s)
    public Button addNewFollowUpsButton = new Button(By.xpath("//a[@title=\"Create Followup\"]"));
    public Table followUpsTable = new Table(By.xpath("//table[@id=\"followups-table\"]"));

    // note(s)
    public Map<String, Link> linkMap = new HashMap<>();
    public Map<String, Label> labelValueMap = new HashMap<>();

    public GroupCertificateDetailPage() {
        linkMap.put("Active", activeLink);
        linkMap.put("Upcoming", upcomingLink);

        labelValueMap.put("Certificate No", certificateNoLabel);
        labelValueMap.put("Group Name", groupNameLabel);
    }

    public void clickOnTab(String tabName) throws Exception {
        Button tabOption = new Button(By.xpath("//a[@title='" + tabName + "']"));
        tabOption.click();
    }

    /*
    this method is to return the complete string from coverage period in the Coverage(s) tab in the Active Upcoming section
    */
    public String getCoveragePeriod(String section) throws Exception {
        Label coveragePeriod = new Label(By.xpath("//div[contains(@id,'" + section.toLowerCase() + "-coverages')]//h3[contains(text(),'Coverage Period')]"));
        return coveragePeriod.getText();
    }
    public String petStatusByPetName(String status, String petName) throws Exception {
        Label petStatus1 = new Label(By.xpath("//a[text()='"+petName+"']/ancestor::tbody/tr/td[contains(text(),'"+status+"')]"));
        String statusOne = petStatus1.getText();
        return statusOne;

    }

    public String cancellationStatusByPetName(String status, String petName) throws Exception {
        Label cancellationStatusPet = new Label(By.xpath("//a[text()='"+petName+"']/ancestor::tbody/tr/td//div/strong[contains(text(),'"+status+"')]"));
        String cancelledPet = cancellationStatusPet.getText();
        return cancelledPet;
    }

}