package pages.orcaGroup;

import control.Label;
import org.openqa.selenium.By;

public class GroupPetCoverageInfoPage {



    /*
    this method get the value for the next labels in Overview Section
    Annual Deductible,Diminished Amount,Deductible to Satisfym,Coinsurance,Per Incident Copay,Prior Coverage Credit
    Paid Thru Date Linked Certificate(s)  Linked Policy(ies)
     */
    public String getValueForLabel(String controlName) throws Exception {
        Label control= new Label(By.xpath("//*[text()='"+controlName+"']/../../div[@class='controls']"));
        return control.getText();
    }


    public String getToolTipForLabel(String controlName) throws Exception {
        Label control= new Label(By.xpath("//*[text()='"+controlName+"']/parent::div[@data-toggle=\"tooltip\"]"));
        return control.getTextAttribute("title");
    }
}
