package pages.pawsome;

import control.*;
import entities.pawsome.GetQuoteEntity;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class GetQuotePage {

    public TextBox petNameTextBox = new TextBox(By.xpath("//input[@id=\"name\"]"));
    public TextBox zipCodeTextBox = new TextBox(By.xpath("//input[@id=\"postalCode\"]"));
    public RadioButton dogPetTypeOption = new RadioButton(By.xpath("//span[@for=\"dog\"]"));
    public RadioButton catPetTypeOption = new RadioButton(By.xpath("//span[@for=\"cat\"]"));
    public CustomSelect petBreedSelect = new CustomSelect(By.xpath("//input[@id=\"breedSearch\"]"), "p");
    public Button resetBreedButton = new Button(By.xpath("//button[@id=\"resetBreedButton\"]"));
    public Select petAgeSelect = new Select(By.xpath("//select[@id=\"age\"]"));
    public RadioButton yesHasYourPetOption = new RadioButton(By.xpath("//span[@for=\"yes\"]"));
    public RadioButton noHasYourPetOption = new RadioButton(By.xpath("//span[@for=\"no\"]"));
    public TextBox emailAddressTextBox = new TextBox(By.xpath("//input[@id=\"email\"]"));
    public Button chooseCoverageButton = new Button(By.xpath("//button[@id=\"submit\"]"));

    // edit ZIP code
    public Button editZipCodeButton = new Button(By.xpath("//button[@id=\"change-postal-code\"]"));
    public Button yesZipCodeModalButton = new Button(By.xpath("//button[contains(text(),'Yes')]"));

    // lookUp Pet
    public Button lookUpPenMainButton = new Button(By.xpath("//button[@id=\"look-up-pet-btn\"]"));
    public Button lookUpPetButton = new Button(By.xpath("//button[@id=\"find-registration\"]"));
    public Button cancelButton = new Button(By.xpath("//a[@id=\"look-up-cancel\"]"));
    public TextBox registrationNumberTextBox = new TextBox(By.xpath("//input[@id=\"reg_no\"]"));
    public TextBox zipCodeRegistrationTextBox = new TextBox(By.xpath("//input[@id=\"zipcode\"]"));
    public Select customerSource = new Select(By.xpath("//select[@id=\"customer-source\"]"));

    public GetQuotePage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }

    public void fillGetQuote(GetQuoteEntity getQuoteEntity) throws Exception {
        Logger.log(Level.INFO, this.getClass().getName() + "> Fill QUOTE: " + this.getClass().getSimpleName());
        Thread.sleep(1000);
        this.petNameTextBox.setText(getQuoteEntity.petName);
        this.zipCodeTextBox.setTextAndTab(getQuoteEntity.zipCode);
        Thread.sleep(2000);

        if (getQuoteEntity.getPetType().toLowerCase().equals("dog"))
            this.dogPetTypeOption.click();
        else if (getQuoteEntity.getPetType().toLowerCase().equals("cat"))
            this.catPetTypeOption.click();

        Thread.sleep(8000);
        petBreedSelect.controlIsDisplayed();
        petBreedSelect.controlIsClickable();
        petBreedSelect.setAndClickValue(getQuoteEntity.getPetBreed());
        Thread.sleep(1000);
        petAgeSelect.selectValue(getQuoteEntity.getPetAge());

        if (getQuoteEntity.getHasYourPetEverBeenDiagnosed().toLowerCase().equals("yes")) {
            this.yesHasYourPetOption.click();
        } else if (getQuoteEntity.getHasYourPetEverBeenDiagnosed().toLowerCase().equals("no")) {
            this.noHasYourPetOption.click();
        }
        this.emailAddressTextBox.setText(getQuoteEntity.getEmailAddress());


        this.chooseCoverageButton.click();
        Thread.sleep(3000);
    }

    public void fillLookupPet(String registrationNumber, String zipCode) throws Exception {
        this.lookUpPenMainButton.click();
        this.registrationNumberTextBox.setText(registrationNumber);
        this.zipCodeRegistrationTextBox.setText(zipCode);
        this.lookUpPetButton.click();
    }

    public void updateGetQuote(GetQuoteEntity getQuoteEntity) throws Exception {
        Logger.log(Level.INFO, this.getClass().getName() + "> Update QUOTE: " + this.getClass().getSimpleName());
        Thread.sleep(1000);
        if (!getQuoteEntity.getPetName().isEmpty()) {
            this.petNameTextBox.clear();
            this.petNameTextBox.setText(getQuoteEntity.petName);
        }

        if (!getQuoteEntity.getZipCode().isEmpty()) {

            this.editZipCodeButton.click();
            Thread.sleep(2000);
            this.yesZipCodeModalButton.click();
            Thread.sleep(2000);
            this.zipCodeTextBox.clear();
            this.zipCodeTextBox.setText(getQuoteEntity.getZipCode());
            Thread.sleep(2000);
        }

        if (getQuoteEntity.getPetType().toLowerCase().equals("dog"))
            this.dogPetTypeOption.click();
        else if (getQuoteEntity.getPetType().toLowerCase().equals("cat"))
            this.catPetTypeOption.click();

        if (!getQuoteEntity.getPetBreed().isEmpty()) {
            // remove the breed selected
            Thread.sleep(2000);
            petBreedSelect.setAndClickValue(getQuoteEntity.getPetBreed());
        }

        if (!getQuoteEntity.getPetAge().isEmpty()) {
            Thread.sleep(1000);
            petAgeSelect.selectValue(getQuoteEntity.getPetAge());
        }

        if (getQuoteEntity.getHasYourPetEverBeenDiagnosed().toLowerCase().equals("yes")) {
            this.yesHasYourPetOption.click();
        } else if (getQuoteEntity.getHasYourPetEverBeenDiagnosed().toLowerCase().equals("no")) {
            this.noHasYourPetOption.click();
        }
        if (!getQuoteEntity.getEmailAddress().isEmpty())
            this.emailAddressTextBox.clear();
        this.emailAddressTextBox.setText(getQuoteEntity.getEmailAddress());

        this.chooseCoverageButton.click();
        Thread.sleep(3000);
    }
}
