package unitTest.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import com.google.gson.JsonObject;
import helper.LoginHelper;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import utils.JsonHelper;

import static com.github.tomakehurst.wiremock.client.WireMock.*;


public class LoginHelperTest {
    LoginHelper loginHelper;
    WireMockServer wireMockServer;

    String jsonBodyResponseMock="{\n" +
            "  \"accessToken\": \"eyJhbGciOiJSUzI1NiIsInR5cCI6ImF0K2p3dCJ9.eyJuYmYiOjE2NzM2MjM0NzksImV4cCI6MTY3MzYyNzA3OSwiaXNzIjoiaHR0cHM6Ly9hdXRoLnFhcy5wZXRwYXJ0bmVycy5jb20iLCJhdWQiOlsiYWRtaW4tYXBpIiwiYXR0YWNobWVudC1hcGkiLCJiaWxsaW5nLWFwaSIsImNsYWltLWFwaSIsImNvcmUtYXBpIiwiY3VzdG9tZXItYXBpIiwiZG9jdW1lbnQtYXBpIiwiZmlsZXN0b3JhZ2UtYXBpIiwiZmluYW5jZS1hcGkiLCJtZXNzYWdpbmctYXBpIiwib2NycHJvdmlkZXItYXBpIiwicGV0LWFwaSIsInBvbGljeS1hcGkiLCJxdW90ZS1hcGkiXSwiY2xpZW50X2lkIjoicGV0cGFydG5lcnMtcG9ydGFsIiwic3ViIjoiM2UzNjVkMzItNjdiNy00ZjZmLThhNjMtNDEyZGU3ZWNmMTJkIiwiYXV0aF90aW1lIjoxNjczNjIzNDc5LCJpZHAiOiJsb2NhbCIsImlhdCI6MTY3MzYyMzQ3OSwic2NvcGUiOlsiYWRtaW4tYXBpIiwiYXR0YWNobWVudC1hcGkiLCJiaWxsaW5nLWFwaSIsImNsYWltLWFwaSIsImNvcmUtYXBpIiwiY3VzdG9tZXItYXBpIiwiZG9jdW1lbnQtYXBpIiwiZmlsZXN0b3JhZ2UtYXBpIiwiZmluYW5jZS1hcGkiLCJtZXNzYWdpbmctYXBpIiwib2NycHJvdmlkZXItYXBpIiwib3BlbmlkIiwicGV0LWFwaSIsInBvbGljeS1hcGkiLCJxdW90ZS1hcGkiLCJvZmZsaW5lX2FjY2VzcyJdLCJhbXIiOlsicHdkIl19.QWazyDq4i_LNdzou7zdWERwIUz7WO9QIlfLY29P7JdiAUbK1ZA9bpDF_B5DC31zOuIT2OLm5HWPi92thqasufprjcN_gh_GzL_Zz36Ti4QOrV5HTFyB6HbMI2QQTqVY0Y2XWGjlcxQiQA5h1HnglyXL9HYMuJBiQQiHKmAPyFkfwm3hG-zRUdTgjVUVGSkyy5tIGiof01EF8ofbr3JrjcYbQhYWs7MWU8bTlhKJ8RS1vDXKhiguYM4GKndAzggkvd-r7EHpTUd3c3PDUdYIafULZIQ3B0Va_-wk9LhPNThfX3SzqlRxDBvhTc6JybUpi-S-keyenNuKJD9zAq64P6g\",\n" +
            "  \"identityToken\": null,\n" +
            "  \"tokenType\": \"Bearer\",\n" +
            "  \"refreshToken\": \"9B2993876A7C225424B2AD72BD151BAF2FCAD9D62AF651CC1839E36E14DED66B\",\n" +
            "  \"errorDescription\": null,\n" +
            "  \"expiresIn\": 3600\n" +
            "}";


    @BeforeEach
    public void setupMockService() throws JsonProcessingException {
        WireMockConfiguration configuration = new WireMockConfiguration();
        configuration.port(9191);

        wireMockServer = new WireMockServer(configuration);
        wireMockServer.start();
        ObjectMapper mapper = new ObjectMapper();
        JsonNode actualObj = mapper.readTree(jsonBodyResponseMock);
        configureFor("localhost",wireMockServer.port());
        stubFor(post(urlEqualTo("/customer/account/login"))
                .willReturn(aResponse().withStatus(200).withJsonBody(actualObj).withHeader("Content-Type","application/json"))
        );

        loginHelper = new LoginHelper();
    }

    @AfterEach
    public void closeMockService(){
        wireMockServer.stop();
    }

    @Test
    public void  buildCookieInfoUserTest() throws JsonProcessingException {
        String actualResult =  loginHelper.buildCookieInfoUser("http://localhost:9191","admin","admin");
        JsonObject expectedResult = new JsonObject();
        expectedResult.addProperty("accessToken","eyJhbGciOiJSUzI1NiIsInR5cCI6ImF0K2p3dCJ9.eyJuYmYiOjE2NzM2MjM0NzksImV4cCI6MTY3MzYyNzA3OSwiaXNzIjoiaHR0cHM6Ly9hdXRoLnFhcy5wZXRwYXJ0bmVycy5jb20iLCJhdWQiOlsiYWRtaW4tYXBpIiwiYXR0YWNobWVudC1hcGkiLCJiaWxsaW5nLWFwaSIsImNsYWltLWFwaSIsImNvcmUtYXBpIiwiY3VzdG9tZXItYXBpIiwiZG9jdW1lbnQtYXBpIiwiZmlsZXN0b3JhZ2UtYXBpIiwiZmluYW5jZS1hcGkiLCJtZXNzYWdpbmctYXBpIiwib2NycHJvdmlkZXItYXBpIiwicGV0LWFwaSIsInBvbGljeS1hcGkiLCJxdW90ZS1hcGkiXSwiY2xpZW50X2lkIjoicGV0cGFydG5lcnMtcG9ydGFsIiwic3ViIjoiM2UzNjVkMzItNjdiNy00ZjZmLThhNjMtNDEyZGU3ZWNmMTJkIiwiYXV0aF90aW1lIjoxNjczNjIzNDc5LCJpZHAiOiJsb2NhbCIsImlhdCI6MTY3MzYyMzQ3OSwic2NvcGUiOlsiYWRtaW4tYXBpIiwiYXR0YWNobWVudC1hcGkiLCJiaWxsaW5nLWFwaSIsImNsYWltLWFwaSIsImNvcmUtYXBpIiwiY3VzdG9tZXItYXBpIiwiZG9jdW1lbnQtYXBpIiwiZmlsZXN0b3JhZ2UtYXBpIiwiZmluYW5jZS1hcGkiLCJtZXNzYWdpbmctYXBpIiwib2NycHJvdmlkZXItYXBpIiwib3BlbmlkIiwicGV0LWFwaSIsInBvbGljeS1hcGkiLCJxdW90ZS1hcGkiLCJvZmZsaW5lX2FjY2VzcyJdLCJhbXIiOlsicHdkIl19.QWazyDq4i_LNdzou7zdWERwIUz7WO9QIlfLY29P7JdiAUbK1ZA9bpDF_B5DC31zOuIT2OLm5HWPi92thqasufprjcN_gh_GzL_Zz36Ti4QOrV5HTFyB6HbMI2QQTqVY0Y2XWGjlcxQiQA5h1HnglyXL9HYMuJBiQQiHKmAPyFkfwm3hG-zRUdTgjVUVGSkyy5tIGiof01EF8ofbr3JrjcYbQhYWs7MWU8bTlhKJ8RS1vDXKhiguYM4GKndAzggkvd-r7EHpTUd3c3PDUdYIafULZIQ3B0Va_-wk9LhPNThfX3SzqlRxDBvhTc6JybUpi-S-keyenNuKJD9zAq64P6g");
        expectedResult.addProperty("refreshToken","9B2993876A7C225424B2AD72BD151BAF2FCAD9D62AF651CC1839E36E14DED66B");
        expectedResult.addProperty("expires","IGNORE");
        expectedResult.addProperty("username","admin");
        expectedResult.addProperty("sysuserId",389);
        JsonHelper.assertAreEqualJson(expectedResult.toString(),actualResult,"ERROR: the build cookie is not genereated correctly, please review the method");
    }
}
