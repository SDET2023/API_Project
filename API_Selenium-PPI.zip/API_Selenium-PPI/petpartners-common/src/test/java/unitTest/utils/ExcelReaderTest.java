package unitTest.utils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import utils.ExcelReader;

import java.io.File;
import java.util.*;

public class ExcelReaderTest {

    ExcelReader excelReader;

    @BeforeEach
    public void readFile() {
        excelReader = new ExcelReader(new File("").getAbsolutePath() + "/src/test/resources/unitTest.xlsx");
        excelReader.readBuildMap();
    }

    @Test
    public void verifyTheExcelReader() {
        Map<String, List<String>> expectedResult = new HashMap<>();
        Map<String, List<String>> actualResult = excelReader.getExcelSheet();

        expectedResult.put("Breed", new ArrayList<String>(Arrays.asList("33.0", "55.0")));
        expectedResult.put("Description", new ArrayList<String>(Arrays.asList("44.0", "66.0")));
        expectedResult.put("Name", new ArrayList<String>(Arrays.asList("eynar", "eynar2")));
        expectedResult.put("Testing", new ArrayList<String>(Arrays.asList("  ", "test01")));

        for (String key : expectedResult.keySet()) {
            for (int i = 0; i < expectedResult.get(key).size(); i++) {
                Assertions.assertEquals(expectedResult.get(key).get(i), actualResult.get(key).get(i), "ERROR! the value is not correct");
            }
        }
    }


    @Test
    public void verifyTheHeaders() {
        List<String> actualResult = excelReader.getColumnName();
        List<String> expectedResult = new ArrayList<>();
        expectedResult.add("Name");
        expectedResult.add("Breed");
        expectedResult.add("Description");
        expectedResult.add("Testing");
        expectedResult.add("SeveralDigits");
        expectedResult.add("Decimals");
        expectedResult.add("DigitsSimbol");
        for (int i = 0; i < actualResult.size(); i++) {
            Assertions.assertEquals(expectedResult.get(i), actualResult.get(i), "ERROR! the value is not correct");
        }
    }


    @Test
    public void verifySpecificValues() throws Exception {
        String actualValue = excelReader.getValue("Name", 0);
        String expectedValue = "eynar";
        Assertions.assertEquals(expectedValue, actualValue, "ERROR! the value is not correct");
    }

    @Test
    public void verifyReadSeveralDigitsValues() throws Exception {
        String actualValue = excelReader.getValue("SeveralDigits", 0);
        String expectedValue = "55555.0";
        Assertions.assertEquals(expectedValue, actualValue, "ERROR! the value is not correct");
    }
    @Test
    public void verifyReadDecimalValues() throws Exception {
        String actualValue = excelReader.getValue("Decimals", 0);
        String expectedValue = "4444,333";
        Assertions.assertEquals(expectedValue, actualValue, "ERROR! the value is not correct");
    }
    @Test
    public void verifyReadDigitSymbol() throws Exception {
        String actualValue = excelReader.getValue("DigitsSimbol", 0);
        String expectedValue = "$777777";
        Assertions.assertEquals(expectedValue, actualValue, "ERROR! the value is not correct");
    }


}
