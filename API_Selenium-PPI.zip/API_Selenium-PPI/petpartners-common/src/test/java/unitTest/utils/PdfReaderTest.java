package unitTest.utils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import utils.PdfReader;

import java.io.File;

public class PdfReaderTest {


    String pdfFile= new File("").getAbsolutePath()+"/src/test/resources/pdfReaderUnitTest.pdf";
    String pdfFileDoesNotExist="/tmp/testing.pdf";

    @DisplayName("verify the PdfReader method is getting tbe content text from PDF File - Links")
    @Test
    public void verifyThePdfReaderIsGettingTheTextFromPDFWhenExistLinks(){
        String content = PdfReader.getTextPDF(pdfFile);
        Assertions.assertTrue(content.contains("https://portal.independenceamerican.com"),"ERROR> The link text was not got from pdf file");
    }

    @DisplayName("verify the PdfReader method is getting tbe content text from PDF File - Beginning Text")
    @Test
    public void verifyThePdfReaderIsGettingTheTextInTheBeginning(){
        String content = PdfReader.getTextPDF(pdfFile);
        Assertions.assertTrue(content.contains("Welcome to Your Pet Insurance"),"ERROR> The Beginning text was not got from pdf file");
    }

    @DisplayName("verify the PdfReader method is getting tbe content text from PDF File - End Text")
    @Test
    public void verifyThePdfReaderIsGettingTheTextFromPDFInTheEnd(){
        String content = PdfReader.getTextPDF(pdfFile);
        Assertions.assertTrue(content.contains("INDEPENDENCE AMERICAN INSURANCE COMPANY"),"ERROR> The End text was not got from pdf file");
    }

    @DisplayName("verify the PdfReader method is getting tbe content text from PDF File - Table Text")
    @Test
    public void verifyThePdfReaderIsGettingTheTextFromPDFFromTable(){
        String content = PdfReader.getTextPDF(pdfFile);
        Assertions.assertTrue(content.contains("Rabies Vaccine $15 $30 $40 $50"),"ERROR> The table text was not got from pdf file");
    }

    @DisplayName("verify error is raised when Pdf file does not exist")
    @Test
    public void verifyTheErrorIsRaisedWhenPdfFileDoesNotExist(){
        RuntimeException thrown = Assertions.assertThrows(RuntimeException.class, () -> {
            PdfReader.getTextPDF(pdfFileDoesNotExist);
        });
        Assertions.assertEquals("ERROR! there is a error reading the file: ["+pdfFileDoesNotExist+"] please review if the file exist",
                                         thrown.getMessage(),"ERROR >  error was not raised when the file does not exist");
    }
}
