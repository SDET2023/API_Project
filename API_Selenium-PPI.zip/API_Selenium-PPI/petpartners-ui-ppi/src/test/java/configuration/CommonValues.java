package configuration;

import java.util.HashMap;
import java.util.Map;

public class CommonValues {
    public static final String DEFAULT_USER="DEFAULT_USER";
    public static final String DEFAULT_PWD="DEFAULT_PWD";
    public static final String HELPER_FILES="HELPER_FILES";
    public static Map<String,String> variables= new HashMap<>();


}
