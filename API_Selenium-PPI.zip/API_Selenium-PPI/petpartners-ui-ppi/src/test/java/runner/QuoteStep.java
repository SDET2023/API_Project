package runner;

import configuration.Configuration;
import control.ControlBase;
import entities.ppi.GetQuoteEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;

import pages.ppi.GetQuotePage;
import pages.ppi.LoginPage;
import pages.ppi.MainPage;
import session.Session;
import utils.Level;
import utils.Logger;

import java.util.List;
import java.util.Map;

public class QuoteStep extends BaseSteps{
    MainPage mainPage = new MainPage();
    GetQuotePage getQuotePage = new GetQuotePage();
    LoginPage loginPage = new LoginPage();

    @And("I check the GET QUOTE button in footer is available")
    public void iCheckTheButtonInFooterIsAvailable() {
       Assertions.assertTrue( mainPage.getQuoteFooterButton.controlIsDisplayed(),"ERROR! the button GET QUOTE on footer section is not displayed");
    }

    @Given("open the PPI web page")
    public void openThePPIWebPage() {
        Logger.log(Level.INFO,this.getClass().getName()+"> Go to: "+Configuration.WEB_URL);
        Session.getInstance().getDriver().get(Configuration.WEB_URL);
    }

    @When("I check the GET QUOTE button in header is available")
    public void iCheckTheButtonInHeaderIsAvailable() {
        Assertions.assertTrue( mainPage.getQuoteFooterButton.controlIsDisplayed(),"ERROR! the button GET QUOTE on header section is not displayed");
    }

    @And("I click GET QUOTE button in header is available")
    public void iClickButtonInHeaderIsAvailable() throws Exception {
        mainPage.getQuoteButton.click();
    }

    @Then("The next controls should be displayed in Your pets's quote")
    public void theNextControlsShouldBeDisplayedInYourPetsSQuote(List<String> controlsDisplayed) throws Exception {
        Map<String, ControlBase> controls =getQuotePage.getAllControls();
        Boolean areDisplayed= true;
        String message="";
        for (String controlName: controlsDisplayed ) {
            if(controls.containsKey(controlName)){
                areDisplayed=controls.get(controlName).controlIsDisplayed();
                message=areDisplayed?message:message+"\n ERROR the control: "+controlName+" is not displayed";
            }else {
                throw new Exception("ERROR! control ["+controlName+"] does not exist, please review it");
            }

        }
        Assertions.assertTrue(areDisplayed,message);
    }

    @And("^I (fill|update) the get quote on petpartners page$")
    public void iFillTheGetQuoteOnPetpartnersPage(String action,GetQuoteEntity getQuoteEntity) throws Exception {
        if (action.contains("fill")){
            // commented [getQuote] button , the main page is  /enroll
            //mainPage.getQuoteButton.click();
           getQuotePage.fillGetQuoteForm(getQuoteEntity);
        }else{
           getQuotePage.updateGetQuote(getQuoteEntity);
        }

    }

    @DataTableType
    public GetQuoteEntity quoteEntityEntry(Map<String,String> entry){
        GetQuoteEntity getQuoteEntity = new GetQuoteEntity();

        getQuoteEntity.setPetName(this.replaceConfigurationValues(entry.get("petName")))
                .setDogOrCatOption(this.replaceConfigurationValues(entry.get("dogOrCat")))
                .setPetBreed(this.replaceConfigurationValues(entry.get("petBreed")))
                .setPetAge(this.replaceConfigurationValues(entry.get("petAge")))
                .setNoOryesPetDiagnosed(this.replaceConfigurationValues(entry.get("yesOrNoDiagnose")))
                .setEmailAdress(this.replaceConfigurationValues(entry.get("email")));

        if (entry.containsKey("zipCode")) {
            getQuoteEntity.setZipCode(this.replaceConfigurationValues(entry.get("zipCode")));
        }

        return getQuoteEntity;
    }

    @And("click login button in the menu section")
    public void clickLoginButtonInTheMenuSection() throws Exception {
        mainPage.loginLink.click();
    }

    @When("I login to PPI with the credentials")
    public void iLoginToPPIWithTheCredentials(Map <String,String> credentials) throws Exception {
        loginPage.login(this.replaceConfigurationValues(credentials.get("user")),this.replaceConfigurationValues(credentials.get("password")));
        Thread.sleep(3000);
    }

    @Then("check the ACTIVATE CERTIFICATE is available")
    public void checkTheACTIVATECERTIFICATEIsAvailable() {
        Assertions.assertTrue(mainPage.activateCertificateLink.controlIsDisplayed(),"ERROR!! the ACTIVATE CERTIFICATION is not displayed in the PPI web page");
    }

    @And("click on ACTIVATE COVERAGE link")
    public void clickOnACTIVATECERTIFICATELink() throws Exception {
        mainPage.activateCertificateLink.click();
    }

    @And("click on the Look Up Pet button")
    public void clickOnTheLookUpPetButton() throws Exception {
        getQuotePage.lookUpPetButton.click();
        Thread.sleep(10000);
    }

    @And("click on {} option in HAS YOUR PET EVER BEEN DIAGNOSED WITH OR SHOWN SYMPTOMS OF DIABETES?")
    public void clickOnNOOptionInHASYOURPETEVERBEENDIAGNOSEDWITHORSHOWNSYMPTOMSOFDIABETES(String yesNo) throws Exception {
        if (yesNo.equals("NO"))
            getQuotePage.noPetDiadnosedRadioButton.click();
        else
            getQuotePage.yesPetDiagnosedRadioButton.click();
    }

    @And("click on the CHOOSE COVERAGE button")
    public void clickOnTheCHOOSECOVERAGEButton() throws Exception {
        getQuotePage.chooseCoverageButton.controlIsDisplayed(5);
        getQuotePage.chooseCoverageButton.click();
    }


    @And("i select the {string} in PET BREED combobox in GetQuote Page")
    public void iSelectTheInPETBREEDComboboxInGetQuotePage(String value) throws Exception {
//        getQuotePage.resetBreedButton.click();
        Thread.sleep(2000);
        getQuotePage.petBreedTextBox.setAndClickValue(this.replaceConfigurationValues(value));
    }

    @And("i select the {string} in PET AGE combobox in GetQuote Page")
    public void iSelectTheInPETAGEComboboxInGetQuotePage(String value) throws Exception {
        getQuotePage.petAgeSelect.selectValue(this.replaceConfigurationValues(value));
    }

    @And("i click on CHOOSE COVERAGE button")
    public void iClickOnCHOOSECOVERAGEButton() throws Exception {
        getQuotePage.chooseCoverageButton.click();
        Thread.sleep(5000);
    }

    @And("i clear the value in PET BREED combobox in GetQuote Page")
    public void iClearTheValueInPETBREEDComboboxInGetQuotePage() throws Exception {
        getQuotePage.petBreedTextBox.controlIsDisplayed(15);
        getQuotePage.petBreedTextBox.controlIsClickable();
        getQuotePage.petBreedTextBox.clear();
    }

    @And("^i check the Look Up Pet Form (is|isnt) in the view$")
    public void iCheckTheLookUpPetForm(String criteria) throws Exception{
        String lookUpPetFormStyle = getQuotePage.lookUpPetFormText.getTextAttribute("style");
        Logger.log(Level.INFO,lookUpPetFormStyle+" attribute value");

        if(criteria.equals("is")) {
            Assertions.assertEquals(lookUpPetFormStyle,"display: block;");
          } else if(criteria.equals("isnt")){
            Assertions.assertEquals(lookUpPetFormStyle,"display: none;");}
    }
    @And("^open the PPI web page: partner code valid with IsCertificate (False|True)$")
    public void openThePPIWebPagePartnerCodeValidIsCertificateFalse(String criteria) {
        Logger.log(Level.INFO, this.getClass().getName() + "> Go to: " + Configuration.WEB_URL);
        if(criteria.equals("False")) {
            Session.getInstance().getDriver().get(Configuration.WEB_URL + "?p=PetAllyTEST");
          } else if(criteria.equals("True")){
            Session.getInstance().getDriver().get(Configuration.WEB_URL + "?p=REUNITE");
        }
    }
    @And("open the PPI web page with partner code {string}")
    public void openThePPIWebPageWithPartnerCode(String partnerCode) {
        Logger.log(Level.INFO, this.getClass().getName() + "> Go to: " + Configuration.WEB_URL + "?p="+partnerCode);
        Session.getInstance().getDriver().get(Configuration.WEB_URL + "?p="+partnerCode);
    }
}