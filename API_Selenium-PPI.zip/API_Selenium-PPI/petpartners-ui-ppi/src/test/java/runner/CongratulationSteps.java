package runner;

import configuration.CommonValues;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import pages.ppi.CongratulationEnrollment;
import utils.Level;
import utils.Logger;

public class CongratulationSteps extends  BaseSteps{
    CongratulationEnrollment congratulationEnrollment = new CongratulationEnrollment();
    @Then("the congratulation page should be displayed")
    public void theCongratulationPageShouldBeDisplayed() throws Exception {
        Assertions.assertTrue(congratulationEnrollment.policyNumber.controlIsDisplayed(),"ERROR, the congratulation page is not displayed");
        Assertions.assertEquals("Congratulations on your enrollment!",congratulationEnrollment.messageCongratulation.getText(),"ERROR, the congratulation page is not displayed");
        Thread.sleep(5000);
    }

    @And("Portal Login button should be displayed")
    public void portalLoginButtonShouldBeDisplayed() {
        Assertions.assertTrue( congratulationEnrollment.portalLoginButton.controlIsDisplayed(),"ERROR! the portal login button is not displayed");
    }

    @And("click PortalLogin button in enrollment page")
    public void clickPortalLoginButtonInEnrollmentPage() throws Exception {
        congratulationEnrollment.portalLoginButton.click();
        Thread.sleep(5000);
    }

    @And("I get the policy number in Congratulation page on {}")
    public void iGetThePolicyNumberInCongratulationPageOnPolicyNumber(String variableKey) throws Exception {
        CommonValues.variables.put(variableKey,congratulationEnrollment.policyNumber.getText().replace("Policy ",""));
        Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(variableKey)+"] in ["+variableKey+"]");
    }
}
