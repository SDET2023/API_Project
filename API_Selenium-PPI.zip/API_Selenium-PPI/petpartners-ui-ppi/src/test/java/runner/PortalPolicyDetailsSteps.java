package runner;

import io.cucumber.java.en.And;
import pages.ppi.PortalPolicyDetailsPage;

public class PortalPolicyDetailsSteps {
    PortalPolicyDetailsPage portalPolicyDetailsPage = new PortalPolicyDetailsPage();

    @And("click on Continue button in Effective Date pop up window")
    public void clickOnContinueButtonInEffectiveDatePopUpWindow() throws Exception {
        portalPolicyDetailsPage.popupContinueButton.click();
        Thread.sleep(20000);
    }

    @And("Click on Change Coverage Options button under Pet Name")
    public void clickOnChangeCoverageOptionsButtonUnderPetName() throws Exception {
        Thread.sleep(2000);
        portalPolicyDetailsPage.changeCoverageOptions.click();
    }

    @And("click on Add Pet tab under Coverage header")
    public void clickOnAddPetTabUnderCoverageHeader() throws Exception {
        portalPolicyDetailsPage.addPetButton.controlIsDisplayed(5);
        portalPolicyDetailsPage.addPetButton.click();
    }
}
