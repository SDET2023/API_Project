package runner;

import io.cucumber.java.en.And;
import org.junit.jupiter.api.Assertions;
import pages.ppi.home.HomePage;

public class PortalSteps  extends BaseSteps{
    HomePage homePage= new HomePage();
    @And("verify policy documents")
    public void clickOnTheViewPolicyDocuments() throws Exception {
        homePage.viewPolicyDetailLink.click();
        Assertions.assertTrue(homePage.downloadAttachmentLabel.controlIsDisplayed(),"ERROR! the Download Attachment is not displayed");
    }

    @And("verify the coverage header")
    public void verifyTheCoverageHeader() {
        Assertions.assertTrue(homePage.coverageLabel.controlIsDisplayed(),"ERROR! the Coverage Label is not Displayed");
    }

    @And("verify the policy number: {} is in Policy Detail")
    public void verifyThePolicyNumberIsInPolicyDetail(String policyNumber) {
        Assertions.assertTrue(homePage.isPolicyNumberdisplayed(this.replaceConfigurationValues(policyNumber)),"ERROR! The Policy number is nor displayed : "+this.replaceConfigurationValues(policyNumber));
    }

    @And("click policy number: {} is in Policy Detail")
    public void clickPolicyNumberPolicyNumberIsInPolicyDetail(String policyNumber) throws Exception {
        homePage.clickOnPolicyNumber(this.replaceConfigurationValues(policyNumber));
    }
}
