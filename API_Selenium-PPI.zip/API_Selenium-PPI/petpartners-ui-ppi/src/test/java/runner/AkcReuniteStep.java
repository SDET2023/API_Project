package runner;

import io.cucumber.java.en.Then;
import pages.akc.AkcReunitePage;
import java.util.*;

import org.junit.jupiter.api.Assertions;

public class AkcReuniteStep extends BaseSteps{
    AkcReunitePage akcReunitePage = new AkcReunitePage();


    @Then("verify the next values should be displayed in Reunite Page")
    public void validateTextAkcReunite(List<String> listOftexts) throws Exception{
        for (String text : listOftexts) {
            Assertions.assertTrue( akcReunitePage.createTextValue(text).controlIsDisplayed(),"ERROR! Text: '"+text+"' url is not shown");
        }
}}
