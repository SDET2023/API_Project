package runner;

import configuration.CommonValues;
import configuration.Configuration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import pages.orca.common.LoadingSection;
import session.Session;
import utils.Level;
import utils.Logger;
import java.util.ArrayList;
import java.util.List;

public class BaseSteps {
    public List<String> queryResult= new ArrayList<>();
    protected LoadingSection loadingSection = new LoadingSection();
    public BaseSteps(){ }

    public String replaceConfigurationValues(String value){
        for (String key: CommonValues.variables.keySet()
        ) {
            value=value.replace(key,CommonValues.variables.get(key));
        }
        return value.replace(CommonValues.DEFAULT_USER, Configuration.USER)
                .replace(CommonValues.HELPER_FILES,CommonValues.getHelperFilesValue())
                .replace(CommonValues.DEFAULT_PWD,Configuration.PASSWORD);
    }

    public void scrollDown(){
        Logger.log(Level.INFO,this.getClass().getName()+"> scroll down");
        JavascriptExecutor js = (JavascriptExecutor) Session.getInstance().getDriver();
        js.executeScript("window.scrollBy(0,500)");
    }

    public void scrollUp(){
        Logger.log(Level.INFO,this.getClass().getName()+"> scroll up");
        JavascriptExecutor js = (JavascriptExecutor) Session.getInstance().getDriver();
        js.executeScript("window.scrollBy(0,-400)");
    }

    public void scrollDownUptoElement(String locatorValue) {
        Logger.log(Level.INFO, this.getClass().getName() + "> scroll down up to Given Pixel Value");
        JavascriptExecutor js = (JavascriptExecutor) Session.getInstance().getDriver();
        WebElement element = Session.getInstance().getDriver().findElement(By.xpath(locatorValue));
        js.executeScript("arguments[0].scrollIntoView(true);", element);
    }
}


