package runner.orca;

import configuration.CommonValues;
import configuration.Configuration;
import control.Checkbox;
import entities.orca.MCleadCustomerDetail;
import entities.orca.MCleadPetDetail;
import entities.orca.makeChanges.MakeChangesPetDetailsEntity;
import entities.orca.policy.PolicyMakechangeEntity;
import helper.LoginHelper;
import helpers.GetProperties;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.interactions.Actions;
import pages.orca.claim.ClaimDetails;
import pages.orca.claim.ClaimSearch;
import pages.orca.common.AlertSection;
import pages.orca.common.MenuSection;
import pages.orca.common.SubMenuSection;
import pages.orca.customer.CustomerDetailsPage;
import pages.orca.login.LoginPage;
import pages.orca.mclead.RegistrationMcleadPage;
import pages.orca.policy.PolicyChangesForNewPet;
import pages.orca.policy.PolicyDetailsPage;
import pages.akc.claims.ClaimPage;
import pages.orca.policy.PolicyMakeChangesPage;
import pages.orca.quote.QuoteDetailsPage;
import runner.BaseSteps;
import session.Session;
import utils.Level;
import utils.Logger;
import java.util.List;
import java.util.Map;

public class OrcaSteps extends BaseSteps {
    MenuSection menuSection = new MenuSection();
    PolicyDetailsPage policyDetailsPage= new PolicyDetailsPage();
    AlertSection alertSection= new AlertSection();
    LoginPage loginPage= new LoginPage();
    RegistrationMcleadPage registrationMcleadPage = new RegistrationMcleadPage();
    SubMenuSection subMenuSection= new SubMenuSection();
    ClaimSearch claimSearch = new ClaimSearch();
    ClaimDetails claimDetails = new ClaimDetails();
    ClaimPage claimPage = new ClaimPage();
    PolicyMakeChangesPage makeChangesPage = new PolicyMakeChangesPage();
    QuoteDetailsPage quoteDetailsPage = new QuoteDetailsPage();
    PolicyChangesForNewPet policyChangesForNewPet = new PolicyChangesForNewPet();
    CustomerDetailsPage customerDetailsPage = new CustomerDetailsPage();

    @And("active the policy number: {string}")
    public void activeThePolicyNumber(String policyNumber) throws Exception {
        menuSection.optionMenu.get("Claims").click();
        menuSection.searchPoliciesTextBox.clearSetText(this.replaceConfigurationValues(policyNumber));
        menuSection.goButton.click();
        policyDetailsPage.statusSelect.selectValue("Active");
        Thread.sleep(3000);
        policyDetailsPage.saveButton.click();
        Thread.sleep(5000);
        policyDetailsPage.tabOptionLabelsMap.get("Customer(s)").click();
        Thread.sleep(5000);

    }

    @And("verify the message alert")
    public void verifyTheMessageDialog(String expectedResult) throws Exception {
        String actualResult = alertSection.successfullyAlertLabel.getText();
        expectedResult=this.replaceConfigurationValues(expectedResult);
        Assertions.assertTrue(actualResult.contains(expectedResult),
                "ERROR the message is not successfully, actual: [" + actualResult + "] vs expected: [" + expectedResult + "]");
    }

    @And("I am logged in Orca PetPartners")
    public void iAmLoggedInOrcaPetPartners() throws Exception {

        if (GetProperties.getInstance().isEnabledOrcaMfa()){
            String cookie = new LoginHelper().buildCookieInfoUser(GetProperties.getInstance().getApiHost(),
                    GetProperties.getInstance().getUser(),
                    GetProperties.getInstance().getPassword());
            Logger.log(Level.INFO, this.getClass().getName() + "adding the cookie: [userInfo] : ["+cookie+"]");
            Session.getInstance().getDriver().manage().addCookie(new Cookie("userInfo",cookie));
            Session.getInstance().getDriver().navigate().refresh();
            Thread.sleep(2000);
        }else{
            loginPage.loginSubStep(Configuration.USER,Configuration.PASSWORD);
        }

    }

    @When("adding a registration to Mclead")
    public void addingARegistrationToMclead() throws Exception {
        menuSection.optionMenu.get("Mclead").click();
        subMenuSection.optionSubMenu.get("Add Registration").click();
    }

    @And("filling the Mclead - PetDetails Sections")
    public void fillingTheMcleadPetDetailsSections(MCleadPetDetail mCleadPetDetail) throws Exception {
        registrationMcleadPage.fillPetDetailSection(mCleadPetDetail);
    }

    @And("filling the Mclead - Customer Details")
    public void fillingTheMcleadCustomerDetails(MCleadCustomerDetail mCleadCustomerDetail) throws Exception {
        registrationMcleadPage.fillCustomerDetailSection(mCleadCustomerDetail);
    }

    @And("click on Add Registration button in Mclead Page")
    public void clickOnAddRegistrationButtonInMcleadPage() throws Exception {
        registrationMcleadPage.addRegistrationButton.click();
    }

    @DataTableType
    public MCleadPetDetail mCleadPetDetailEntry(Map<String,String> entry){
        MCleadPetDetail entity = new MCleadPetDetail();
        if (entry.containsKey("Registration No"))
         entity.setRegistrationNo(this.replaceConfigurationValues(entry.get("Registration No")));
        if (entry.containsKey("Registration Date"))
         entity.setRegistrationDate(this.replaceConfigurationValues(entry.get("Registration Date")));
        if (entry.containsKey("Date of Birth"))
         entity.setDateOfBirth(this.replaceConfigurationValues(entry.get("Date of Birth")));
        if (entry.containsKey("Color"))
         entity.setColor(this.replaceConfigurationValues(entry.get("Color")));
        if (entry.containsKey("Market Channel"))
         entity.setMarketChannel(this.replaceConfigurationValues(entry.get("Market Channel")));
        if (entry.containsKey("Partner"))
         entity.setPartner(this.replaceConfigurationValues(entry.get("Partner")));
        if (entry.containsKey("Pet Name"))
         entity.setPetName(this.replaceConfigurationValues(entry.get("Pet Name")));
        if (entry.containsKey("Species"))
         entity.setSpecies(this.replaceConfigurationValues(entry.get("Species")));
        if (entry.containsKey("Breed"))
         entity.setBreed(this.replaceConfigurationValues(entry.get("Breed")));
        if (entry.containsKey("Gender"))
         entity.setGender(this.replaceConfigurationValues(entry.get("Gender")));
         if (entry.containsKey("Sold Date"))
            entity.setSoldDate(this.replaceConfigurationValues(entry.get("Sold Date")));
        return entity;
    }

    @DataTableType
    public MCleadCustomerDetail mCleadCustomerDetailEntry(Map<String,String> entry){
        MCleadCustomerDetail entity = new MCleadCustomerDetail();
        entity.setFirstName(this.replaceConfigurationValues(entry.get("First Name")))
                .setMiddleName(this.replaceConfigurationValues(entry.get("Middle Name")))
                .setLastName(this.replaceConfigurationValues(entry.get("Last Name")))
                .setAddress1(this.replaceConfigurationValues(entry.get("Address 1")))
                .setAddress2(this.replaceConfigurationValues(entry.get("Address 2")))
                .setCity(this.replaceConfigurationValues(entry.get("City")))
                .setStateProvince(this.replaceConfigurationValues(entry.get("State/Province")))
                .setPostalCode(this.replaceConfigurationValues(entry.get("Postal Code")))
                .setEmail(this.replaceConfigurationValues(entry.get("Email")))
                .setPhone(this.replaceConfigurationValues(entry.get("Phone")))
                .setSendEmail(this.replaceConfigurationValues(entry.get("Send Email")));
        return entity;
    }

    @And("verify the customer {} is displayed")
    public void verifyTheCustomerDefaultUserIsDisplayed(String email) {
        Assertions.assertTrue(policyDetailsPage.emailCustomer(this.replaceConfigurationValues(email)),"ERROR ! email: "+this.replaceConfigurationValues(email)+ "is not displayed in customer tab");
    }

    @When("open the ORCA web page")
    public void openTheORCAWebPage() throws InterruptedException {
        Thread.sleep(10000);
        Session.getInstance().getDriver().get(GetProperties.getInstance().getUrlOrcaWeb());
    }

    @And("I click on get Quote button in McLead Details")
    public void clickOnGetQuoteInMcLeadDetails() throws Exception{
        registrationMcleadPage.getquoteMcLeadDetails.click();
    }

    @When("I search the claim: {}")
    public void iSearchTheClaim(String claimNumber) throws Exception {
        menuSection.optionMenu.get("Claims").click();
        subMenuSection.optionSubMenu.get("Search for a Claim").click();
        claimSearch.claimNoTxtBox.clearSetText(this.replaceConfigurationValues(claimNumber));
        claimSearch.runSearchButton.click();
    }

    @And("I click on Claim No: {} link")
    public void iClickOnClaimNoLink(String claimNumber) throws Exception {
        claimSearch.clickClaimResult(this.replaceConfigurationValues(claimNumber));
    }

    @And("click on [{}] tab in the bottom menu")
    public void clickOnTabInTheBottomMenu(String menuTabOption) throws Exception {
        Thread.sleep(2000);
        claimDetails.controlLinks.get(menuTabOption).controlIsDisplayed(5);
        claimDetails.controlLinks.get(menuTabOption).click();
    }

    @And("click on the [Claims] link")
    public void clickOnTheClaimsLink() throws Exception {
        claimDetails.claimsResultLink.click();
    }

    @Then("verify the invoice.pdf link is not empty")
    public void verifyTheInvoicePdfLinkIsNotEmpty() throws Exception {
        Assertions.assertFalse(claimDetails.getLinkForClaimPDF().isEmpty(), "ERROR, the link for the PDF is empty");
    }

    @And("I got the Claim number in {}")
    public void iGotTheClaimNumberIn(String variable) throws Exception {
        Thread.sleep(15000);
        CommonValues.variables.put(variable,claimPage.getClaimNumber());
        Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(variable)+"] in ["+variable+"]");
    }

    @Then("I click {string} dropdown")
    public void iClickDropdown(String options) throws Exception {
        Thread.sleep(2500);
        makeChangesPage.policyActionsButton.click();
    }

    @And("I select {string}")
    public void iSelect(String value) throws Exception {
        Thread.sleep(2500);
        makeChangesPage.changeEffectiveDateButton.click();

    }

    @And("I set new effective date")
    public void iSetNewEffectiveDate(DataTable dataTable) throws Exception {

        List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);
        for (Map<String, String> dataa : data) {
            makeChangesPage.newEffectiveDateButton.clear();
            makeChangesPage.newEffectiveDateButton.setText(this.replaceConfigurationValues(dataa.get("New Effective Date")));
        }
    }

    @Then("I set the notes for changes")
    public void iSetTheNotesForChanges() throws Exception {
        makeChangesPage.notesTextbox.setText("Test");

    }

    @And("click on [save] button on Change Effective page")
    public void clickOnSaveButtonOnChangeEffectivePage() throws Exception {
        makeChangesPage.saveButton.click();
    }

    @And("^click on (Active|Upcoming|Expired) on Policy Term on policy detail page$")
    public void clickOnActiveOnPolicyTerm(String value) throws Exception {
        Thread.sleep(2000);
        loadingSection.loadingSpinnerTableValueIcon.waitWhileControlDisappears(15);
        if (value.contains("Active")) {
            policyDetailsPage.activeLink.waitUntilControlIsDisplayed();
            policyDetailsPage.activeLink.controlIsClickable();
            policyDetailsPage.activeLink.click();
        } else if (value.contains("Upcoming")) {
            policyDetailsPage.upcomingLink.waitUntilControlIsDisplayed();
            policyDetailsPage.upcomingLink.controlIsClickable();
            policyDetailsPage.upcomingLink.click();
        } else {
            policyDetailsPage.expiredLink.waitUntilControlIsDisplayed();
            policyDetailsPage.expiredLink.controlIsClickable();
            policyDetailsPage.expiredLink.click();
        }
        Thread.sleep(5000);
    }

    @Then("I click Make Changes button")
    public void iClickMakeChangesButton() throws Exception {
        Thread.sleep(3000);
        makeChangesPage.makeChangeButton.click();
    }

    @Then("I select {string} option")
    public void iSelectMakeChangesOption(String option) throws Exception {
        Thread.sleep(2500);
        if (option.contains("Make Changes")) {
            Thread.sleep(2500);
            makeChangesPage.makeChangeOption.click();
        } else if (option.contains("Transfer Sale")) {
            makeChangesPage.transferSaleButton.click();
        }
    }

    @When("click on MakeChanges button in quote detail page")
    public void clickOnMakeChangesButtonInQuoteDetailPage() throws Exception {
        quoteDetailsPage.petTableMakeChangesButton.click();
    }

    @And("change pet details in make changes page")
    public void changePetDetailsInMakeChangesPage(MakeChangesPetDetailsEntity makeChangesPetEntity) throws Exception {
        this.makeChangesPage.fillPetDetailsInMakeChangesScreen(makeChangesPetEntity);
    }
    @DataTableType
    public MakeChangesPetDetailsEntity makeChangesPetDetailsEntity(Map<String, String> entry) {
        MakeChangesPetDetailsEntity entity = new MakeChangesPetDetailsEntity();
        entity.setMakeChangesPetName(this.replaceConfigurationValues(entry.get("CHG PETNAME")))
                .setMakeChangesPetDOB(this.replaceConfigurationValues(entry.get("CHG DOB")))
                .setMakeChangesPetGender(this.replaceConfigurationValues(entry.get("CHG GENDER")))
                .setMakeChangesPetSpecies(this.replaceConfigurationValues(entry.get("CHG SPECIES")))
                .setMakeChangesPetBreed(this.replaceConfigurationValues(entry.get("CHG BREED")));

        return entity;
    }

    @When("click Save button in make changes page")
    public void clickSaveButtonInMakeChangesPage() throws Exception {
        makeChangesPage.saveButtonMakeChangesPage.click();
        makeChangesPage.saveButtonMakeChangesPage.controlIsNotDisplayed(10);
        new Actions(Session.getInstance().getDriver()).moveByOffset(10, 200).click().perform();
        if (quoteDetailsPage.plusButton.controlIsDisplayed(5))
            quoteDetailsPage.plusButton.click();
    }

    @Then("verify updated pet details in Quote details page")
    public void verifyUpdatedPetDetailsInQuoteDetailsPage(List<String> expectedPetDetails) throws Exception {
        for (String sElement : expectedPetDetails) {
            Assertions.assertTrue(quoteDetailsPage.covPetDetailsTable.checkIfValueIsDisplayedInTable(sElement),
                    "ERROR: " + sElement + " is not displayed");
        }
    }

    @And("^I update the \\[(CompanionCare|AccidentCare)\\] checkboxes in MakeChanges Modal$")
    public void unselectTheCompanionCareCheckboxesInMakeChangesModal(String checkboxesType, Map<String, String> checkBoxesNames) throws Exception {
        Map<String, Checkbox> checkboxMap = checkboxesType.contains("CompanionCare") ?
                makeChangesPage.companionCareCheckBoxesMap :
                makeChangesPage.accidentCareCheckBoxesMap;

        for (String checkBoxName : checkBoxesNames.keySet()) {
            if (!checkboxMap.containsKey(checkBoxName))
                throw new Exception("ERROR: the checkbox: [" + checkBoxName + "] does not exist in MakeChanges Modal, please review it");
            checkboxMap.get(checkBoxName).actionCheckBox(checkBoxesNames.get(checkBoxName));
        }
    }

    @Then("verify updated coverage and product details in Quote details page")
    public void verifyUpdatedCoverageAndProductDetailsInQuoteDetailsPage(List<String> expectedCovProdDetails) throws Exception {
        for (String sElement : expectedCovProdDetails) {
            Assertions.assertTrue(quoteDetailsPage.coverageDetailsTable.checkIfValueIsDisplayedInTable(sElement),
                    "ERROR: " + sElement + " is not displayed");
        }
    }

    @Then("I click Add Pet button")
    public void iClickAddPetButton() throws Exception {
        Thread.sleep(2500);
        makeChangesPage.addPetButton.click();
    }

    @And("I select {string} option Under the Add pet")
    public void iSelectExistingPetOptionUnderTheAddPet(String value) throws Exception {
        if (value.contains("Existing Pet")) {
            Thread.sleep(3000);
            makeChangesPage.existingPetButton.click();
        } else if (value.contains("New Pet")) {
            makeChangesPage.newPetButton.click();
        }
    }

    @And("I set the pet information on Add coverage page")
    public void iSetThePetInformationOnAddCoveragePage(PolicyMakechangeEntity policyMakechangeEntity) throws Exception {
        if (!policyMakechangeEntity.getGender().isEmpty())
            policyChangesForNewPet.genderOfthePet.selectValueContainsOption(this.replaceConfigurationValues(policyMakechangeEntity.getGender()));
        if (!policyMakechangeEntity.getPetName().isEmpty())
            policyChangesForNewPet.petNameTextBox.setText(this.replaceConfigurationValues(policyMakechangeEntity.getPetName()));
        if (!policyMakechangeEntity.getSpecies().isEmpty())
            policyChangesForNewPet.speciesOfThePet.selectValueContainsOption(this.replaceConfigurationValues(policyMakechangeEntity.getSpecies()));
        if (!policyMakechangeEntity.getBreed().isEmpty())
            Thread.sleep(2000);
        policyChangesForNewPet.breedOfThePet.selectValueContainsOption(this.replaceConfigurationValues(policyMakechangeEntity.getBreed()));
    }

    @DataTableType
    public PolicyMakechangeEntity policyMakechangeEntity(Map<String, String> entry) {
        PolicyMakechangeEntity entity = new PolicyMakechangeEntity();
        entity.setPetName(this.replaceConfigurationValues(entry.get("ADD PETNAME")));
        entity.setDateOfBirth(this.replaceConfigurationValues(entry.get("ADD DOB")));
        entity.setGender(this.replaceConfigurationValues(entry.get("ADD GENDER")));
        entity.setSpecies(this.replaceConfigurationValues(entry.get("ADD SPECIES")));
        entity.setBreed(this.replaceConfigurationValues(entry.get("ADD BREED")));

        return entity;
    }

    @And("^click on \\[(Return to Policy|Save)\\] button in Quote Details Page$")
    public void clickOnReturnToPolicyButtonInQuoteDetailsPage(String controlName) throws Exception {
        if (controlName.contains("Save")){
            quoteDetailsPage.saveButton.controlIsDisplayed();
            quoteDetailsPage.saveButton.click();
        }else{
            quoteDetailsPage.returnToPolicyButton.controlIsDisplayed();
            quoteDetailsPage.returnToPolicyButton.click();
        }
    }

    @And("^click \\[(Submit for Approval|Discard Changes|Save|Approve Changes)\\] button on policy detail page$")
    public void clickSubmitForApprovalButtonOnPolicyDetailPage(String buttonName) throws Exception {
        policyDetailsPage.buttonsMap.get(buttonName).click();
    }

    @And("click on [{}] tab option on policy detail page")
    public void clickOnCoverageSTabOption(String tabOption) throws Exception {
        loadingSection.loadingSpinnerTableValueIcon.waitWhileControlDisappears(15);
        policyDetailsPage.tabOptionLabelsMap.get(tabOption).click();
    }

    @Then("verify updated pet details on policy details page")
    public void verifyUpdatedPetDetailsOnPolicyDetailsPage(List<String> expectedPetDetails) throws Exception {
        for (String sElement : expectedPetDetails) {
            Assertions.assertTrue(policyDetailsPage.petsTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(sElement)),
                    "ERROR: " + sElement + " is not displayed");
        }
    }

    @And("the status control should be {string} on Policy Detail Page")
    public void theControlShouldBeOnPolicyDetailPage(String expectedResult) throws Exception {
        policyDetailsPage.statusSelect.controlIsDisplayed(20);
        String actualResult = policyDetailsPage.statusSelect.getTextOptionSelected();
        Assertions.assertEquals(expectedResult, actualResult, "ERROR! the status values is  different, actual: " + actualResult + " vs expected: " + expectedResult);
    }

    @And("select the {string} option on Status on Policy Detail Page")
    public void selectTheOptionOnStatusOnPolicyDetailPage(String option) throws Exception {
        policyDetailsPage.statusSelect.selectValue(option);
        Thread.sleep(3000);
    }

    @And("click on [save] button on Policy Detail Page")
    public void clickOnButtonOnPolicyDetailPage() throws Exception {
        policyDetailsPage.saveButton.click();
        Thread.sleep(3000);
    }


    @And("click on view customer icon under Action")
    public void clickOnViewCustomerIconUnderAction() throws Exception {
        this.scrollDownUptoElement("//a[@title='View Customer']");
        policyDetailsPage.viewCustomerIconInActionsLink.waitUntilControlIsDisplayed();
        policyDetailsPage.viewCustomerIconInActionsLink.click();
    }
    @And("I click on the [{}] tab in the menu")
    public void iClickOnTabMenu(String tabOption) throws Exception {
        policyDetailsPage.tabOptionButtonMap.get(tabOption).click();
    }
    @And("I update below fields on customer details page")
    public void iUpdateBelowFieldsOnCustomerDetailsPage(DataTable table) throws Exception {
        List<Map<String, String>> rows = table.asMaps(String.class, String.class);
        for (Map<String, String> columns : rows) {
            customerDetailsPage.textBoxMap.get("FIRST NAME").clearSetText(this.replaceConfigurationValues(columns.get("FIRST NAME")));
            customerDetailsPage.textBoxMap.get("LAST NAME").clearSetText(this.replaceConfigurationValues(columns.get("LAST NAME")));
            customerDetailsPage.textBoxMap.get("PHONE NUMBER").clearSetTextJS(this.replaceConfigurationValues(columns.get("PHONE NUMBER")),"//input[@id='Customer_PhoneDay']");
            customerDetailsPage.textBoxMap.get("EMAIL ADDRESS").clearSetText(this.replaceConfigurationValues(columns.get("EMAIL ADDRESS")));
        }
    }

    @And("I add a new customer under Customer(s) tab")
    public void iAddNewCustomerUnderCustomerTab(DataTable table) throws Exception {
        List<Map<String, String>> rows = table.asMaps(String.class, String.class);
        this.scrollDownUptoElement("//a[@title='View Customer']");
        policyDetailsPage.addCustomerButton.click();
        policyDetailsPage.customerSearchLabel.controlIsDisplayed();
        policyDetailsPage.createNewCustomerButton.click();
        customerDetailsPage.firstNameTextBox.controlIsDisplayed();
        for (Map<String, String> columns : rows) {
            customerDetailsPage.textBoxMap.get("FIRST NAME").setText(this.replaceConfigurationValues(columns.get("FIRST NAME")));
            customerDetailsPage.textBoxMap.get("LAST NAME").setText(this.replaceConfigurationValues(columns.get("LAST NAME")));
            customerDetailsPage.textBoxMap.get("ADDRESS1").setText(this.replaceConfigurationValues(columns.get("ADDRESS1")));
            customerDetailsPage.textBoxMap.get("CITY").setText(this.replaceConfigurationValues(columns.get("CITY")));
            customerDetailsPage.stateDropdown.selectValue(this.replaceConfigurationValues(columns.get("STATE")));
            customerDetailsPage.textBoxMap.get("ZIPCODE").setText(this.replaceConfigurationValues(columns.get("ZIPCODE")));
            customerDetailsPage.textBoxMap.get("PHONE NUMBER").clearSetTextJS(this.replaceConfigurationValues(columns.get("PHONE NUMBER")),"//input[@id='Customer_PhoneDay']");
            customerDetailsPage.textBoxMap.get("EMAIL ADDRESS").setText(this.replaceConfigurationValues(columns.get("EMAIL ADDRESS")));
        }
        this.scrollDown();
        customerDetailsPage.popupSaveButton.click();
    }

    @And("I delete the newly added customer {} under Customer(s) tab")
    public void iDeleteNewlyAddedCustomerUnderCustomerTab(String name) throws Exception {
        this.scrollDownUptoElement("//a[@title='View Customer']");
        policyDetailsPage.iconDeleteButton.waitUntilControlIsDisplayed();
        policyDetailsPage.clickOnDeleteIcon(this.replaceConfigurationValues(name));
        policyDetailsPage.areYouSureLabel.waitUntilControlIsDisplayed();
        policyDetailsPage.yesButton.click();
    }

    @And("search the policy number: {string}")
    public void searchThePolicyNumber(String policyNumber) throws Exception {
        menuSection.searchPoliciesTextBox.clearSetText(this.replaceConfigurationValues(policyNumber));
        menuSection.goButton.click();
        Thread.sleep(5000);
    }

    @And("click on [save] button on customer details Page")
    public void clickOnSaveButtonOnCustomerDetailsPage() throws Exception {
        customerDetailsPage.saveButton.click();
    }
}
