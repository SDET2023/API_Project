package runner.orca;

import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import pages.orca.common.MenuSection;
import runner.BaseSteps;

public class TopSideSteps extends BaseSteps {
    MenuSection menuSection = new MenuSection();

    @When("I set {string} in Search Policies")
    public void iSetInSearchPolicies(String value) throws Exception {
        menuSection.searchPoliciesTextBox.clearSetText(this.replaceConfigurationValues(value));
    }

    @And("I click [Go] symbol button")
    public void iClickGoSymbolButton() throws Exception {
        menuSection.goButton.click();
    }
}
