package runner.akc;

import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import pages.akc.LoginPage;
import runner.BaseSteps;
import java.util.Map;

public class LoginStep extends BaseSteps {
    LoginPage loginPage = new LoginPage();

    @When("i login in akc login page")
    public void iLoginInAkcLoginPage(Map<String,String> credential) throws Exception {
        loginPage.login(this.replaceConfigurationValues(credential.get("user")),
                        this.replaceConfigurationValues(credential.get("pwd")));
        Thread.sleep(5000);
    }

    @And("click create account button on login page")
    public void clickCreateAccountButtonOnLoginPage() throws Exception {
        loginPage.createAccountButton.click();
    }
}
