package runner.akc;

import entities.akc.ClaimEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import pages.akc.MainPortalPage;
import pages.akc.claims.ClaimPage;
import runner.BaseSteps;
import java.util.Map;

public class CustomerPortal extends BaseSteps {
    MainPortalPage mainPortalPage = new MainPortalPage();
    ClaimPage claimPage = new ClaimPage();

    @When("I click on {} Button on the AKC Customer portal page")
    public void iClickOnButtonOnTheAKCCustomerPortalPage(String button) throws Exception {
        mainPortalPage.portalButton.get(button).click();
    }

    @And("I fill the claim detail section")
    public void iFillTheClaimDetailSection(ClaimEntity claimEntity) throws Exception {
        claimPage.fillClaim(claimEntity);
    }

    @DataTableType
    public ClaimEntity claimEntityEntry(Map<String,String> entry){
        ClaimEntity entity = new ClaimEntity();
        entity.setSelectPolicy(this.replaceConfigurationValues(entry.get("Select Policy")))
                .setDoesYourPetHaveAdditional(this.replaceConfigurationValues(entry.get("Does your pet have additional insurance")))
                .setInjuryOrIllness(this.replaceConfigurationValues(entry.get("injury or illness")))
                .setTellUsMoreAboutInjury(this.replaceConfigurationValues(entry.get("Tell us more about the injury or illness")))
                .setWhenDidYuFirstNoticeSignDate(this.replaceConfigurationValues(entry.get("When did you first notice signs")))
                .setTreatmentStartDate(this.replaceConfigurationValues(entry.get("Treatment Start Date")))
                .setUploadFile(this.replaceConfigurationValues(entry.get("Upload File")));
        return entity;

    }
}
