package runner.akc;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import pages.akc.policy.PolicyDetailPage;
import runner.BaseSteps;

public class PolicyDetailStep extends BaseSteps {
    PolicyDetailPage policyDetailPage = new PolicyDetailPage();

    @And("verify the Policy Details Label should be displayed in Portal")
    public void verifyThePolicyDetailsLabelShouldBeDisplayedInPortal() {
        Assertions.assertTrue(policyDetailPage.policyDetailLabel.controlIsDisplayed(),"ERROR> the Policy Detail Label is not displayed in Policy Detail");
    }

    @And("verify the Coverage Label should be displayed in Portal")
    public void verifyTheCoverageLabelShouldBeDisplayedInPortal() {
        Assertions.assertTrue(policyDetailPage.coverageLabel.controlIsDisplayed(),"ERROR> the Coverage Label is not displayed in Policy Detail");

    }

    @And("verify the Claims Label should be displayed in Portal")
    public void verifyTheClaimsLabelShouldBeDisplayedInPortal() {
        Assertions.assertTrue(policyDetailPage.claimsLabel.controlIsDisplayed(),"ERROR> the Claims Label is not displayed in Policy Detail");
    }

    @Then("verify the {string} is displayed in Portal")
    public void verifyTheIsDisplayedInPortal(String policyNumber) {
        Assertions.assertTrue(policyDetailPage.isPolicyNumberdisplayed(this.replaceConfigurationValues(policyNumber)),"ERROR> the Policy Number: ["+this.replaceConfigurationValues(policyNumber)+"] is not displayed in Policy Detail");
    }

    @And("verify the control in coverage section in Portal")
    public void verifyTheControlInCoverageSectionInPortal() {
        Assertions.assertTrue(policyDetailPage.viewPolicyDocumentsLink.controlIsDisplayed(),"ERROR> the viewPolicyDocuments Link is not displayed in coverage section- Policy Detail");
        Assertions.assertTrue(policyDetailPage.activeLabel.controlIsDisplayed(),"ERROR> the active Label is not displayed in coverage section- Policy Detail");
        Assertions.assertTrue(policyDetailPage.costLabel.controlIsDisplayed(),"ERROR> the cost Label is not displayed in coverage section- Policy Detail");
        Assertions.assertTrue(policyDetailPage.petNameLabel.controlIsDisplayed(),"ERROR> the petName Label is not displayed in coverage section- Policy Detail");
        Assertions.assertTrue(policyDetailPage.premiumLabel.controlIsDisplayed(),"ERROR> the premium Label is not displayed in coverage section- Policy Detail");
        Assertions.assertTrue(policyDetailPage.productLabel.controlIsDisplayed(),"ERROR> the product Label is not displayed in coverage section- Policy Detail");
        Assertions.assertTrue(policyDetailPage.showCoverageSummaryLink.controlIsDisplayed(),"ERROR> the showCoverageSummary Link is not displayed in coverage section- Policy Detail");
    }

    @And("click on View Policy Document button")
    public void clickOnViewPolicyDocumentButton() throws Exception {
        Thread.sleep(10000);
        policyDetailPage.viewPolicyDocumentsLink.click();
    }

    @And("verify the Download your attachments dialog is displayed")
    public void verifyTheDownloadYourAttachmentsDialogIsDisplayed() {
        Assertions.assertTrue(policyDetailPage.downloadAttachmentLabelDialog.controlIsDisplayed(),"ERROR> the dialog: [Download your attachments] is not displayed");

    }

    @And("close the Download your attachments dialog")
    public void closeTheDownloadYourAttachmentsDialog() throws Exception {
        policyDetailPage.closeDialogButton.click();
    }

    @And("click on Continue button in Effective Date pop up window")
    public void clickOnContinueButtonInEffectiveDatePopUpWindow() throws Exception {
        policyDetailPage.popupContinueButton.click();
        Thread.sleep(20000);
    }

    @And("Click on Change Coverage Options button under Pet Name")
    public void clickOnChangeCoverageOptionsButtonUnderPetName() throws Exception {
        Thread.sleep(5000);
        policyDetailPage.changeCoverageOptions.controlIsDisplayed();
        policyDetailPage.changeCoverageOptions.click();
    }

    @And("click on Add Pet tab under Coverage header")
    public void clickOnAddPetTabUnderCoverageHeader() throws Exception {
        policyDetailPage.addPetButton.controlIsDisplayed(15);
        policyDetailPage.addPetButton.controlIsClickable();
        policyDetailPage.addPetButton.click();
    }
}
