package runner.akc;

import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;

import pages.akc.policy.PortalCongratulationOnYourEnrollmentPage;


public class PortalCongratulationOnYourEnrollmentSteps{
    PortalCongratulationOnYourEnrollmentPage portalCongOnYourEnrollment = new PortalCongratulationOnYourEnrollmentPage();

    @Then("verify updated coverage options {string},{string},{string},{string} in Congratulation on your enrollment page")
    public void verifyUpdatedCoverageOptionsInCongratulationOnYourEnrollmentPage(String sDeductible, String sCoinsurance, String sAnnual, String sBreeding) throws Exception {
        Assertions.assertTrue(portalCongOnYourEnrollment.chgCovDeductible.getText().contains(sDeductible),
                "ERROR: "+sDeductible+ " is not displayed");
        Assertions.assertTrue(portalCongOnYourEnrollment.chgCovCoinsurance.getText().contains(sCoinsurance),
                "ERROR: "+sCoinsurance+ " is not displayed");
        Assertions.assertTrue(portalCongOnYourEnrollment.chgCovAnnual.getText().contains(sAnnual),
                "ERROR: "+sAnnual+ " is not displayed");
        Assertions.assertTrue(portalCongOnYourEnrollment.chgCovBreeding.getText().contains(sBreeding),
                "ERROR: "+sBreeding+ " is not displayed");
    }

    @Then("verify added pet details {string},{string},{string},{string},{string} in Congratulation on your enrollment page")
    public void verifyAddedPetDetailsInCongratulationOnYourEnrollmentPage( String sPetBreed, String sDeductible, String sCoinsurance, String sAnnual, String sBreeding) throws Exception {
        Assertions.assertTrue(portalCongOnYourEnrollment.addPetBreed.getText().contains(sPetBreed),
                "ERROR: "+sPetBreed+ " is not displayed");
        Assertions.assertTrue(portalCongOnYourEnrollment.addPetDeductible.getText().contains(sDeductible),
                "ERROR: "+sDeductible+ " is not displayed");
        Assertions.assertTrue(portalCongOnYourEnrollment.addPetCoinsurance.getText().contains(sCoinsurance),
                "ERROR: "+sCoinsurance+ " is not displayed");
        Assertions.assertTrue(portalCongOnYourEnrollment.addPetAnnual.getText().contains(sAnnual),
                "ERROR: "+sAnnual+ " is not displayed");
        Assertions.assertTrue(portalCongOnYourEnrollment.addPetBreeding.getText().contains(sBreeding),
                "ERROR: "+sBreeding+ " is not displayed");
    }

}
