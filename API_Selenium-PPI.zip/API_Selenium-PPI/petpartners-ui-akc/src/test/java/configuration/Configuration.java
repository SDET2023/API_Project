package configuration;

import helpers.GetProperties;

public class Configuration {
    public static final String WEB_URL= GetProperties.getInstance().getUrlWeb();
    public static final String USER=GetProperties.getInstance().getUser();
    public static final String PASSWORD=GetProperties.getInstance().getPassword();


}
