package runner;

import entities.akc.AddPetYourPetsQuoteEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import pages.pawsome.policy.AddPetYourPetsQuotePage;

import java.util.Map;

public class PortalYourPetsQuotePageSteps extends BaseSteps{
    AddPetYourPetsQuotePage addPetYourPetsQuotePage = new AddPetYourPetsQuotePage();

    @And("enter details in Your Pets Quote Page")
    public void enterDetailsInYourPetsQuotePage(AddPetYourPetsQuoteEntity addPetYourPetsQuoteEntity) throws Exception {
        this.addPetYourPetsQuotePage.fillGetQuote(addPetYourPetsQuoteEntity);
    }

    @DataTableType
    public AddPetYourPetsQuoteEntity addPetYourPetsQuote(Map<String,String> entry){
        AddPetYourPetsQuoteEntity entity= new AddPetYourPetsQuoteEntity();
        entity.setPetName(replaceConfigurationValues(entry.get("PET NAME")))
                .setPetType(this.replaceConfigurationValues(entry.get("PET TYPE")))
                .setPetBreed(this.replaceConfigurationValues(entry.get("PET BREED")))
                .setPetAge(this.replaceConfigurationValues(entry.get("PET AGE")))
                .setHasYourPetEverBeenDiagnosed(this.replaceConfigurationValues(entry.get("HAS YOUR PET EVER BEEN DIAGNOSED")));
        return entity;
    }
}