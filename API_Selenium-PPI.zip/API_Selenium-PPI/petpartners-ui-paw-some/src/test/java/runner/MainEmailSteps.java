package runner;


import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import pages.ppi.yopEmailPages.MainEmailPage;
import session.Session;

public class MainEmailSteps extends BaseSteps {
    MainEmailPage mainEmailPage = new MainEmailPage();

    @Then("^Open your email in order to verify the (Quote Email|Welcome Email) from petpartners using \"(.*)\"$")
    public void openYourEmailInOrderToVerifyTheEmailFromPetpartners(String label,String email) throws Exception {
        mainEmailPage.emailNameTextBox.setText(this.replaceConfigurationValues(email));
        Thread.sleep(15000);
        mainEmailPage.goButton.controlIsClickable();
        mainEmailPage.goButton.click();
        mainEmailPage.refreshButton.click();
        Thread.sleep(2000);
        Session.getInstance().getDriver().switchTo().frame("ifinbox");
        Assertions.assertTrue(mainEmailPage.emailSubjectLabel.controlIsDisplayed(),"ERROR! the email was not sent");
    }
    @Then("Open your YOPemail using {string}")
    public void openYourYOPemailUsing(String email) throws Exception {
        Thread.sleep(2000);
        mainEmailPage.emailNameTextBox.setText(this.replaceConfigurationValues(email));
        mainEmailPage.goButton.click();
        mainEmailPage.refreshButton.click();
        Thread.sleep(2000);
    }

    @And("check the PortalLogin button is displayed in the email")
    public void checkThePortalLoginButtonIsDisplayedInTheEmail() {

        Session.getInstance().getDriver().navigate().refresh();
        Session.getInstance().getDriver().switchTo().frame("ifmail");
        Assertions.assertTrue(mainEmailPage.portalLoginButton.controlIsDisplayed(),"ERROR! the portal login button is not displayed in the email");
    }

    @Then("verify the subject email")
    public void verifyTheSubjectEmail(String expectedResult) throws Exception {
        Session.getInstance().getDriver().switchTo().frame("ifmail");
        String actualResult=mainEmailPage.emailSubjectDetailLabel.getText();
        Assertions.assertEquals(this.replaceConfigurationValues(expectedResult),actualResult,"ERROR! the subject the email is wrong");
    }

    @And("click on Portal Login in email")
    public void clickOnPortalLoginInEmail() throws Exception {
        mainEmailPage.portalLoginButton.click();
    }

}
