package runner;

import configuration.CommonValues;
import configuration.Configuration;
import org.openqa.selenium.JavascriptExecutor;
import session.Session;
import utils.Level;
import utils.Logger;

public class BaseSteps {

    public BaseSteps(){

    }

    public String replaceConfigurationValues(String value){
        for (String key: CommonValues.variables.keySet()
        ) {
            value=value.replace(key,CommonValues.variables.get(key));
        }
        return value.replace(CommonValues.DEFAULT_USER, Configuration.USER)
                .replace(CommonValues.DEFAULT_PWD,Configuration.PASSWORD);
    }

    public void scrollDown(){
        Logger.log(Level.INFO,this.getClass().getName()+"> scroll down");
        JavascriptExecutor js = (JavascriptExecutor) Session.getInstance().getDriver();
        js.executeScript("window.scrollBy(0,500)");
    }

    public void scrollUp(){
        Logger.log(Level.INFO,this.getClass().getName()+"> scroll up");
        JavascriptExecutor js = (JavascriptExecutor) Session.getInstance().getDriver();
        js.executeScript("window.scrollBy(0,-400)");
    }
}


