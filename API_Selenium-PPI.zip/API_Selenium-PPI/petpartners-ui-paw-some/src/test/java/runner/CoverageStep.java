package runner;

import entities.pawsome.CoverageEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import pages.pawsome.CoveragePage;


import java.util.List;
import java.util.Map;

public class CoverageStep extends BaseSteps {
    CoveragePage coveragePage = new CoveragePage();

    @Then("select {string} plan detail in pet coverage page")
    public void selectPlanDetailInPetCoveragePage(String option) throws Exception {
        coveragePage.selectPlanDetail(option.toLowerCase());
    }

    @And("verify the expected result for the controls")
    public void verifyTheExpectedResultForTheControls(Map<String, String> expectedResultControl) throws Exception {
        String message = "";
        Boolean areEqual = true;
        for (String control : expectedResultControl.keySet()) {
            String actualResult = coveragePage.selectMap.get(control).getTextOptionDisable();
            String expectedResult = expectedResultControl.get(control);
            if (!actualResult.equals(expectedResult)) {
                areEqual = false;
                message = message + "\nactual result: " + actualResult + " [vs] expected result: " + expectedResult;
            }
        }

        Assertions.assertTrue(areEqual, "ERROR!!" + message);
    }

    @Then("verify the available upgrades should be displayed")
    public void verifyTheAvailableUpgradesShouldBeDisplayed(List<String> expectedControlDisplayed) {
        for (String control : expectedControlDisplayed) {
            Assertions.assertTrue(coveragePage.radioButtonMap.get(control).controlIsDisplayed(), "ERROR the control: [" + control + "] is not displayed ");
        }
    }

    @And("click on {string} option on available upgrades")
    public void clickOnOptionOnAvailableUpgrades(String availableUpgradeOption) throws Exception {
        coveragePage.radioButtonMap.get(availableUpgradeOption).click();

    }

    @And("click on {string} link in Policy Overview Section")
    public void clickOnLinkInPolicyOverviewSection(String emailQuoteLink) throws Exception {
        coveragePage.emailQuoteLink.click();
    }

    @And("click on {string} button on email quote dialog")
    public void clickOnButtonOnEmailQuoteDialog(String submitButton) throws Exception {
        coveragePage.submitButton.click();
    }

    @Then("the message should be displayed")
    public void theMessageShouldBeDisplayed(String expectedResult) throws Exception {
        Thread.sleep(5000);
        String actualResult = coveragePage.messageDialog.getText();
        Assertions.assertEquals(expectedResult, actualResult, "Error ! the message is wrong");
    }

    @And("click close button on dialog message")
    public void clickCloseButtonOnDialogMessage() throws Exception {
        coveragePage.closeButton.click();
    }

    @And("click on [Activate initial 30 day offer only] Button on Select Pet Coverage Page")
    public void clickOnActivateInitialDayOfferOnlyButtonOnSelectPetCoveragePage() throws Exception {
        coveragePage.activateInitial30DayOnlyButton.click();
        Thread.sleep(5000);
    }

    @Then("the Select Pet Coverage should be displayed")
    public void theSelectPetCoverageShouldBeDisplayed() {
        Assertions.assertTrue(coveragePage.customizeYourPlanLabel.controlIsDisplayed(), "ERROR! the Select Pet Coverage Page is not displayed");
    }

    @And("i verify the policy overview")
    public void verifyDataPolicyOverview(Map<String, String> expectedResult) throws Exception {

        if (expectedResult.containsKey("PET BREE"))
            Assertions.assertTrue(coveragePage.getBreedLabel(this.replaceConfigurationValues(expectedResult.get("PET BREED"))).controlIsDisplayed(),
                    "ERROR the Pet Breed value is wrong, it is not displaying:" + this.replaceConfigurationValues(expectedResult.get("PET BREED")));
        if (expectedResult.containsKey("PET AGE"))
            Assertions.assertTrue(coveragePage.getPetAgeLabel(this.replaceConfigurationValues(expectedResult.get("PET AGE"))).controlIsDisplayed(),
                    "ERROR the Pet Age value is wrong, it is not displaying:" + this.replaceConfigurationValues(expectedResult.get("PET AGE")));
        if (expectedResult.containsKey("PET NAME"))
            Assertions.assertTrue(coveragePage.getNamePetLabel(this.replaceConfigurationValues(expectedResult.get("PET NAME"))).controlIsDisplayed(),
                    "ERROR the Pet Name value is wrong, it is not displaying:" + this.replaceConfigurationValues(expectedResult.get("PET NAME")));


    }

    @And("i click on EDIT PET link on coverage page")
    public void iClickOnEDITPETLinkOnCoveragePage() throws Exception {
        coveragePage.editPetLink.click();
        Thread.sleep(10000);
    }

    @And("i verify the price monthly total is ${string}")
    public void iVerifyThePriceMonthlyTotalIs(String expectedResult) throws Exception {
        String actualResult = coveragePage.priceMonthLabel.getText();
        System.out.println("PRICEEEE " + actualResult);
        Assertions.assertTrue(actualResult.contains(this.replaceConfigurationValues(expectedResult)), "the price monthly total is wrong, expected: [" + this.replaceConfigurationValues(expectedResult) + "] vs actual [" + actualResult + "]");
    }

    @And("choose coverage type and select options")
    public void fillCoverageDetails(CoverageEntity coverageEntity) throws Exception {
        this.coveragePage.fillCoverageOption(coverageEntity);
    }

    @DataTableType
    public CoverageEntity coverageEntity(Map<String, String> entry) {
        CoverageEntity entity = new CoverageEntity();
        entity.setPlanDetail(this.replaceConfigurationValues(entry.get("COVERAGE TYPE")))
                .setDeductible(this.replaceConfigurationValues(entry.get("DEDUCTIBLE")))
                .setCoinsurance(this.replaceConfigurationValues(entry.get("COINSURANCE")))
                .setAnnualLimit(this.replaceConfigurationValues(entry.get("ANNUAL LIMIT")));
        return entity;
    }

    @And("scrollUp window")
    public void scrollUpWindow() {
        this.scrollUp();
    }

    @And("click on activateDayAndContinueCustomPlan on Select Pet Coverage Page")
    public void clickOnActivateDayAndContinueCustomPlanOnSelectPetCoveragePage() throws Exception {
        coveragePage.activateCertAndContinueCustomPlan.click();
        Thread.sleep(3000);
    }

    @And("click on activateDayAndEnrollInAnnualPlan on Select Pet Coverage Page")
    public void clickOnActivateDayAndEnrollInAnnualPlanOnSelectPetCoveragePage() throws Exception {
        coveragePage.activateAnnualPlan.click();
        Thread.sleep(2000);
    }
}
