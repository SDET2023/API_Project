package runner;


import entities.pawsome.CompleteEnrollmentEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import pages.pawsome.CompleteYourEnrollmentPage;


import java.util.List;
import java.util.Map;

public class CompleteYourEnrollmentStep extends BaseSteps {
    CompleteYourEnrollmentPage completeYourEnrollmentPage = new CompleteYourEnrollmentPage();

    @Then("verify the next control are pre-populated")
    public void verifyTheNextControlArePrePopulated(List<String> controls) throws Exception {
        for (String controlName : controls) {
            if (!completeYourEnrollmentPage.controls.containsKey(controlName))
                throw new Exception("ERROR The control: [" + controlName + "] is not displayed in the page");
            Assertions.assertTrue(!completeYourEnrollmentPage.controls.get(controlName).getTextAttribute("value").isEmpty(), "ERROR the control is not pre populated: control: " + controlName);
        }

    }

    @And("fill the Complete Your Enrollment Page")
    public void fillTheCompleteYourEnrollmentPage(CompleteEnrollmentEntity completeEnrollmentEntity) throws Exception {
        completeYourEnrollmentPage.fillCompleteYourEnrollmentComplete(completeEnrollmentEntity);
    }

    @DataTableType
    public CompleteEnrollmentEntity completeEnrollmentEntry(Map<String, String> entry) {
        CompleteEnrollmentEntity entity = new CompleteEnrollmentEntity();

        if (entry.containsKey("FIRST NAME"))
            entity.setFirstName(this.replaceConfigurationValues(entry.get("FIRST NAME")));
        if (entry.containsKey("LAST NAME"))
            entity.setLastName(this.replaceConfigurationValues(entry.get("LAST NAME")));
        if (entry.containsKey("ADDRESS"))
            entity.setAddress(this.replaceConfigurationValues(entry.get("ADDRESS")));
        if (entry.containsKey("APT, SUITE, ETC."))
            entity.setAptSuiteEtc(this.replaceConfigurationValues(entry.get("APT, SUITE, ETC.")));
        if (entry.containsKey("PHONE NUMBER"))
            entity.setPhoneNumber(this.replaceConfigurationValues(entry.get("PHONE NUMBER")));
        if (entry.containsKey("NAME ON CARD"))
            entity.setNameOnCard(this.replaceConfigurationValues(entry.get("NAME ON CARD")));
        if (entry.containsKey("CARD NUMBER"))
            entity.setCardNumber(this.replaceConfigurationValues(entry.get("CARD NUMBER")));
        if (entry.containsKey("EXPIRES MM"))
            entity.setExpiresMM(this.replaceConfigurationValues(entry.get("EXPIRES MM")));
        if (entry.containsKey("EXPIRES YYYY"))
            entity.setExpiresYYYY(this.replaceConfigurationValues(entry.get("EXPIRES YYYY")));
        if (entry.containsKey("EXPIRES CVC"))
            entity.setExpiresCVC(this.replaceConfigurationValues(entry.get("EXPIRES CVC")));

        if (entry.containsKey("CITY"))
            entity.setCity(this.replaceConfigurationValues(entry.get("CITY")));
        if (entry.containsKey("STATE"))
            entity.setState(this.replaceConfigurationValues(entry.get("STATE")));
        if (entry.containsKey("ZIP CODE"))
            entity.setZipCode(this.replaceConfigurationValues(entry.get("ZIP CODE")));
        if (entry.containsKey("EMAIL ADDRESS"))
            entity.setEmailAddress(this.replaceConfigurationValues(entry.get("EMAIL ADDRESS")));
        if (entry.containsKey("Group Code"))
            entity.setGroupCode(this.replaceConfigurationValues(entry.get("Group Code")));
        if (entry.containsKey("IS USING DIFFERENT BILLING"))
            entity.setUsingDifferentBilling(Boolean.parseBoolean(this.replaceConfigurationValues(entry.get("IS USING DIFFERENT BILLING"))));
        if (entry.containsKey("DIFFERENT ADDRESS"))
            entity.setDifferentAddress(this.replaceConfigurationValues(entry.get("DIFFERENT ADDRESS")));
        if (entry.containsKey("DIFFERENT APT SUITE"))
            entity.setDifferentAptSuiteEtc(this.replaceConfigurationValues(entry.get("DIFFERENT APT SUITE")));
        if (entry.containsKey("DIFFERENT CITY"))
            entity.setDifferentCity(this.replaceConfigurationValues(entry.get("DIFFERENT CITY")));
        if (entry.containsKey("DIFFERENT STATE"))
            entity.setDifferentState(this.replaceConfigurationValues(entry.get("DIFFERENT STATE")));
        if (entry.containsKey("DIFFERENT ZIPCODE"))
            entity.setDifferentZipCode(this.replaceConfigurationValues(entry.get("DIFFERENT ZIPCODE")));

        return entity;
    }

    @Then("the Complete your enrollment page should be open")
    public void theCompleteYourEnrollmentPageShouldBeOpen() {
         Assertions.assertTrue(completeYourEnrollmentPage.completeYourEnrollmentLabel.controlIsDisplayed(),"ERROR > The Complete Enrollment Page is not displayed");
    }

    @And("click on Enroll Now button")
    public void clickOnEnrollNowButton() throws Exception {
        completeYourEnrollmentPage.enrollNowButton.click();
    }

    @And("the policy overview total should be {}")
    public void thePolicyOverviewTotalShouldBe(String expectedResult) throws Exception {
        Assertions.assertTrue(completeYourEnrollmentPage.policyOverviewCostLabel.getText().contains(expectedResult),
                "ERROR the cost for the policy should be : "+expectedResult+ "but it is "+completeYourEnrollmentPage.policyOverviewCostLabel.getText());
    }

    @And("select the checkin option in Complete your enrollment page")
    public void selectTheCheckinOptionInCompleteYourEnrollmentPage() throws Exception {
        completeYourEnrollmentPage.iAgreeThatByCheckingOption.click();
        if (completeYourEnrollmentPage.byCheckingBoxOption.controlIsDisplayed(10))
           completeYourEnrollmentPage.byCheckingBoxOption.click();
    }
    @And("click on {string} link in complete your enrollment page")
    public void clickOnLinkInCompleteYourEnrollmentPage(String lnkName) throws Exception {
        Thread.sleep(5000);
        if (lnkName.equals("Edit Plan Details"))
            completeYourEnrollmentPage.editPlanDetailsLink.click();
        else if (lnkName.equals("Remove Plan"))
            completeYourEnrollmentPage.removePlanLink.click();
        else if (lnkName.equals("Show Term Details"))
            completeYourEnrollmentPage.showTermDetailsLink.click();
    }

    @And("Click {string} button in Remove Plan confirmation popup")
    public void clickButtonInRemovePlanConfirmationPopup(String sYesNo) throws Exception {
        if (sYesNo.equals("Yes"))
            completeYourEnrollmentPage.removePlanYesButton.click();
        else
            completeYourEnrollmentPage.removePlanNoButton.click();
    }

    @Then("Verify {string} is displayed in complete your enrollment page")
    public void verifyIsDisplayedInCompleteYourEnrollmentPage(String sExpectedResult) throws Exception {
        Assertions.assertTrue(completeYourEnrollmentPage.cartIsEmptyLabel.getText().contains(sExpectedResult),
                "ERROR: "+sExpectedResult+ " is not displayed");
    }

    @And("verify values {string},{string},{string},{string} in Selected Term Details")
    public void verifyValuesInSelectedTermDetails(String sDeductible, String sCoinsurance, String sIncident, String sAnnual) throws Exception {
        Assertions.assertTrue(completeYourEnrollmentPage.showTermDeductible.getText().contains(sDeductible),
                "ERROR: "+sDeductible+ " is not displayed");
        Assertions.assertTrue(completeYourEnrollmentPage.showTermCoinsurance.getText().contains(sCoinsurance),
                "ERROR: "+sCoinsurance+ " is not displayed");
        Assertions.assertTrue(completeYourEnrollmentPage.showTermIncident.getText().contains(sIncident),
                "ERROR: "+sIncident+ " is not displayed");
        Assertions.assertTrue(completeYourEnrollmentPage.showTermAnnual.getText().contains(sAnnual),
                "ERROR: "+sAnnual+ " is not displayed");

    }

    @And("Click Hide Term Details button and verify")
    public void clickHideTermDetailsButtonAndVerify() throws Exception {
        completeYourEnrollmentPage.showTermDetailsLink.click();
    }

    @And("I complete enrollment process on akc page")
    public void iCompleteEnrollmentProcessOnakcPage(CompleteEnrollmentEntity completeEnrollmentEntity) throws Exception {
        completeYourEnrollmentPage.fillCompleteYourEnrollmentComplete(completeEnrollmentEntity);
        Thread.sleep(2000);

    }
}
